
#include <afxwin.h>

class CMainWindow;

class CGridCtrl;


// macros pour simplier le remplissage des grilles by JG
// macro pour remplissage sans parametre %
#define MAKE_ITEM(r, c, f, t)	{Item.row= r; Item.col= c; Item.nFormat= f; Item.strText.Format(t);}
// macro pour remplissage avec 1 parametre %
#define MAKE_ITEM_EX(r, c, f, t, p)	{Item.row= r; Item.col= c; Item.nFormat= f; Item.strText.Format(t, p);}

void Fill_Grid_Equipes(CGridCtrl *);
void Dump_Grid_Equipes(CGridCtrl *);

void Fill_Grid_Joueurs(CGridCtrl *);
void Dump_Grid_Joueurs(CGridCtrl *);

void Fill_Grid_Scores(CGridCtrl *, int t);
void Dump_Grid_Scores(CGridCtrl *, int t);

void Fill_Grid_Bilan(CGridCtrl *);

void Fill_Grid_Classement(CGridCtrl *);

void Reset_grid_texts(CGridCtrl * grid);

/*
Classe de dialogue de configuration
*/

class CInitDlg : public CDialog
{
public:	CString field1;         // champs de saisie
		CString field2;
		CString field3;
		int contexte;		// contexte initial
		int choix;			// choix en retour

		CInitDlg(int id);			// constructeur

		BOOL OnInitDialog();		// methodes
		void DoDataExchange(CDataExchange* ddx);
		virtual void OnRadioButton1();
		virtual void OnRadioButton2();
		virtual void OnRadioButton3();

		DECLARE_MESSAGE_MAP()   // table de messages
};


/*
Classe de dialogue de saisie
*/

class CDlg : public CDialog
{
public:	CString field1;         // champs de saisie
		int contexte;		// contexte de saisie

		CDlg(int id);			// constructeur

		BOOL OnInitDialog();		// methodes
		void DoDataExchange(CDataExchange* ddx);

		DECLARE_MESSAGE_MAP()   // table de messages
};


/*
Classe CEquipesDlg
*/

class CEquipesDlg : public CDialog
{
protected:
	CGridCtrl * Grid_Equipes;

	CMainWindow * ParentWnd;

public:
	CEquipesDlg(int resId, CWnd *parent);
	virtual ~CEquipesDlg();

	virtual BOOL OnInitDialog();
	virtual void OnApply();
	virtual void OnOK();
	virtual void OnCancel();
	void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
};


/*
Classe CJoueursDlg
*/

class CJoueursDlg : public CDialog
{
protected:
	CGridCtrl * Grid_Joueurs;

	CMainWindow * ParentWnd;

public:
	CJoueursDlg(int resId, CWnd *parent);
	virtual ~CJoueursDlg();

	virtual BOOL OnInitDialog();
	virtual void OnApply();
	virtual void OnOK();
	virtual void OnCancel();
	void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
};


/*
Classe CScoressDlg
*/

class CScoresDlg : public CDialog
{
protected:
	CGridCtrl * Grid_Scores;

	CMainWindow * ParentWnd;

	int tr;		// tour auquel s'applique les scores

public:
	CScoresDlg(int resId, CWnd *parent, int t);
	virtual ~CScoresDlg();

	virtual BOOL OnInitDialog();
	virtual void OnApply();
	virtual void OnOK();
	virtual void OnCancel();
	void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
};


/*
Classe CBilanDlg
*/

class CBilanDlg : public CDialog
{
protected:
	CGridCtrl * Grid_Bilan;

	CMainWindow * ParentWnd;

public:
	CBilanDlg(int resId, CWnd *parent);
	virtual ~CBilanDlg();

	virtual BOOL OnInitDialog();
	virtual void OnApply();
	virtual void OnOK();
	virtual void OnCancel();
	void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
};


/*
Classe CClassementDlg
*/

class CClassementDlg : public CDialog
{
protected:
	CGridCtrl * Grid_Classement;

	CMainWindow * ParentWnd;

public:
	CClassementDlg(int resId, CWnd *parent);
	virtual ~CClassementDlg();

	virtual BOOL OnInitDialog();
	virtual void OnApply();
	virtual void OnOK();
	virtual void OnCancel();
	void DoDataExchange(CDataExchange* pDX);

	DECLARE_MESSAGE_MAP()
};