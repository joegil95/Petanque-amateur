
// MFC header
#include <afxwin.h>

#include "Petanque.h"

#include "GridCtrl\GridCtrl.h"


Petanque * ajout_joueur(Petanque * tournoi);
Petanque * retrait_joueur(Petanque * tournoi, int n);

Petanque * ajout_equipe(Petanque * tournoi);
Petanque * retrait_equipe(Petanque * tournoi, int n);


// Classe CMainWindow derivee de CFrameWnd
class CMainWindow : public CFrameWnd
	{
	public:	
			CMenu * menu;

			CToolBar * toolbar;
			CStatusBar* statusbar;

			CString name;		// nom du tournoi

			CGridCtrl * Grid_Equipesptr;
			CGridCtrl * Grid_Joueursptr;
			CGridCtrl * Grid_Scoresptr;
			CGridCtrl * Grid_Bilanptr;
			CGridCtrl * Grid_Classementptr;

			bool Equipes_edit;
			bool Joueurs_edit;			
			
   			CMainWindow();
   			~CMainWindow();

			afx_msg void OnPaint();
			afx_msg void OnNew();
			afx_msg void OnSave();
			afx_msg void OnRestore();

			afx_msg void OnJoueurs_Liste();
			afx_msg void OnJoueurs_Ajout();
			afx_msg void OnJoueurs_Retrait();
			afx_msg void OnJoueurs_Lock();
			afx_msg void OnJoueurs_Unlock();

			afx_msg void OnEquipes_Liste();
			afx_msg void OnEquipes_Ajout();
			afx_msg void OnEquipes_Retrait();
			afx_msg void OnEquipes_Lock();
			afx_msg void OnEquipes_Unlock();
			afx_msg void OnEquipes_Melange();

			afx_msg void OnTours_Next();
			afx_msg void OnTours_Scores();
			afx_msg void OnTours_ScoresOld();

			afx_msg void OnResults_Bilan();
			afx_msg void OnResults_Classement();

			afx_msg void OnAbout();
			afx_msg void OnDoc();
			afx_msg void OnClose();
			afx_msg void OnQuit();

			DECLARE_MESSAGE_MAP()
	};

// Classe CTheApp:

class CTheApp : public CWinApp
	{
	public:	virtual BOOL InitInstance();
   			virtual int ExitInstance();
	};

