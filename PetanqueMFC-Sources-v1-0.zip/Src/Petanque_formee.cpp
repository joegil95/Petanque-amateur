/*
@(#) JG 2026

A compiler en VC++

Attention: d�sactiver unicode pour les noms de fichiers
*/


#include "Petanque.h"

extern Petanque * tournoi;
extern bool start;


Petanque * ajout_equipe(Petanque * tournoi)
	{
	unsigned nb=1, nbtr=1;

	Equipe * equipes= new Equipe[tournoi->nbteams+2];		// equipe 0 inutilisee
	
	// recuperer les equipes
	for (int i= 0 ; i <= tournoi->nbteams ; i++)
		{
		equipes[i].numero= tournoi->liste[i]->numero;
		strcpy(equipes[i].joueurs[0], tournoi->liste[i]->joueurs[0]);
		strcpy(equipes[i].joueurs[1], tournoi->liste[i]->joueurs[1]);
		strcpy(equipes[i].joueurs[2], tournoi->liste[i]->joueurs[2]);
		}
				
	nb= tournoi->nbteams+1;
	nbtr= tournoi->nbtours;

	delete tournoi;

	// recreer un tournoi complet
	tournoi= new Petanque(nbtr, nb);		// equipes formees

	// recopier les joueurs
	for (int i= 0 ; i < tournoi->nbteams ; i++)		// attention car nbteams++
		{
		tournoi->liste[i]->numero= equipes[i].numero;
		strcpy(tournoi->liste[i]->joueurs[0], equipes[i].joueurs[0]);
		strcpy(tournoi->liste[i]->joueurs[1], equipes[i].joueurs[1]);
		strcpy(tournoi->liste[i]->joueurs[2], equipes[i].joueurs[2]);
		}

	delete[] equipes;

	return tournoi;
	}


Petanque * retrait_equipe(Petanque * tournoi, int n)
	{
	unsigned nb=1, nbtr=1;

	if ((n > 0) && (n <= tournoi->nbteams))
		{
		Equipe * equipes= new Equipe[tournoi->nbteams+1];		// equipe 0 inutilisee
	
		// recuperer les equipes
		for (int i= 0 ; i <= tournoi->nbteams ; i++)
			{
			equipes[i].numero= tournoi->liste[i]->numero;
			strcpy(equipes[i].joueurs[0], tournoi->liste[i]->joueurs[0]);
			strcpy(equipes[i].joueurs[1], tournoi->liste[i]->joueurs[1]);
			strcpy(equipes[i].joueurs[2], tournoi->liste[i]->joueurs[2]);
			}
				
		nb= tournoi->nbteams-1;
		nbtr= tournoi->nbtours;

		delete tournoi;

		// recreer un tournoi complet
		tournoi= new Petanque(nbtr, nb);		// equipes formees

		// recopier les equipes sauf No n
		int j= 0;
		for (int i= 0 ; i <= tournoi->nbteams+1 ; i++)		// attention car nbplayers++
			{
			if (i != n)
				{
				tournoi->liste[j]->numero= j;
							
				strcpy(tournoi->liste[j]->joueurs[0], equipes[i].joueurs[0]);
				strcpy(tournoi->liste[j]->joueurs[1], equipes[i].joueurs[1]);
				strcpy(tournoi->liste[j]->joueurs[2], equipes[i].joueurs[2]);
				j++;
				}
			}

		delete[] equipes;
		}

	return tournoi;
	}


void jeu_forme()
	{
	unsigned nb=1, nbtr=1;
	int tr= 0, tour= 0;
	char cmd[100]= " ";
	char tag= 'n';
	String stg1, stg2, stg3;

	cout << "Il est conseille d'avoir un nombre pair d'equipes, et a defaut un nombre pair de tours." << endl << endl;

	cout << "Combien d'equipes ? ";
	cin >> nb;

	cout << "Combien de tours ? ";
	cin >> nbtr;

	if ((nb < 4) || (nbtr >= nb))
		{
		cout << "Nombre d'equipes insuffisant ou nombre de tours trop eleve !" << endl;
		getch();
		return;
		}

	if (nbtr > 10)
		{
		cout << "Nombre de tours trop eleve (maximum 10) !" << endl;
		getch();
		return;
		}

	if (nb % 2)		// nb impair d'equipes 
		{
		if (nbtr % 2)		// et de tours
			{
			cout << "Attention !" << endl;
			cout << "Avec un nombre impair d'equipes et de tours il est tres difficile d'avoir le meme nombre de matches pour tous." << endl;
			cout << "Vous pourrez faire un tour complementaire au besoin pour rattraper au mieux..." << endl;
			cout << "Voulez-vous continuer (o/n) ? ";
			tag= getch();
			if (tag == 'n') return;
			cout << endl;
			}
		else
			{
			cout << "Attention !" << endl;
			cout << "Avec un nombre impair d'equipes il y a une equipe passive a chaque tour." << endl;
			cout << "Vous pourrez faire un tour complementaire pour equilibrer le nombre de matches..." << endl << endl;
			}
		}

	cout << "Creation du tournoi pour " << nb << " equipes formees, sur " << nbtr << " tours" << endl;
	tournoi= new Petanque(nbtr, nb);

	fflush(stdin);

	do
		{
		cout << endl << "Entrer une commande (? pour aide) et penser a enregistrer (f) :";
		gets(cmd);

		if (cmd[0] == '?')		// help
			{
			cout << "e %u = saisir equipe No u" << endl;
			cout << "l= lister les equipes" << endl;
			cout << "t %d = faire tirage tour No d ou t c pour tirage tour complementaire" << endl;
			cout << "p %d %u = saisir les points d'une partie du tour No d equipe No u" << endl;
			cout << "b = bilan des scores de toutes les equipes sur tous les tours" << endl;
			cout << "f= sauvegarder les donnees dans les fichiers" << endl;
			cout << "r= restaurer les donnees depuis les fichiers" << endl;
			cout << "q = quitter" << endl;
			}

		if ((cmd[0] == 'e') && (cmd[1] == ' '))
			{
			unsigned n= 0;
			sscanf(cmd, "e %u", &n);
			if ((n > 0) && (n <= tournoi->nbteams))
				{
				tag= 'o';
				if (strcmp(tournoi->liste[n]->joueurs[0], "") != 0)
					{
					cout << "Modifier cette equipe (o/n) ?" << endl;
					tag= getch();
					fflush(stdin);
				}
				if (tag == 'o') 
					{
					cout << "J 1: "; gets(stg1);
					cout << "J 2: "; gets(stg2);
					cout << "J 3: "; gets(stg3);								
					tournoi->liste[n]->definir(n, stg1, stg2, stg3);
					tournoi->liste[n]->afficher(true, true);
					}
				else cout << "Abandon..." << endl;
				}
			else cout << "Erreur..." << endl;
			}

		if (cmd[0] == 'l')
			{
			cout << "Liste des equipes:" << endl;
			for (int k= 1 ; k <= tournoi->nbteams ; k++)
				tournoi->liste[k]->afficher(true, true);
			}

		if (cmd[0] == 'a')
			{
			cout << "Liste actuelle des equipes:" << endl;
			for (int k= 1 ; k <= tournoi->nbteams ; k++)
				tournoi->liste[k]->afficher(true, true);
			
			if (start)
				{
				cout << "Tournoi en cours. Impossible d'ajouter une equipe !" << endl;
				tag= 'n';
				}
			else
				{
				cout << "Voulez-vous vraiment ajouter une equipe supplementaire No " << tournoi->nbteams+1 << " (o/n) ?" << endl;
				tag= getch();
				fflush(stdin);
				}

			if (tag == 'o') 
				{
				// recreer un tournoi modifie
				tournoi= ajout_equipe(tournoi);

				// saisir nouvelle equipe
				cout << "J 1: "; gets(stg1);
				cout << "J 2: "; gets(stg2);
				cout << "J 3: "; gets(stg3);				
				tournoi->liste[tournoi->nbteams]->definir(tournoi->nbteams, stg1,stg2, stg3);
				tournoi->liste[tournoi->nbteams]->afficher(true, true);

				cout << endl;
				cout << "Nouvelle liste des equipes:" << endl;
				for (int k= 1 ; k <= tournoi->nbteams ; k++)
					tournoi->liste[k]->afficher(true, true);

				int sav= tournoi->sauvegarde_forme(tour);
				if (sav == 0) 
					cout << "Fichiers sauvegardes automatiquement !" << endl;				
				else
					cout << "Probleme de sauvegarde !" << endl;
				}
			else
				cout << "Abandon..." << endl;
			}


		if (cmd[0] == 's')
			{
			cout << "Liste actuelle des equipes:" << endl;
			for (int k= 1 ; k <= tournoi->nbteams ; k++)
				tournoi->liste[k]->afficher(true, true);

			if (start)
				{
				cout << "Tournoi en cours. Impossible de supprimer une equipe !" << endl;
				tag= 'n';
				}
			else if ((tournoi->nbteams <= 4) || (tournoi->nbtours >= tournoi->nbteams-1))
				{
				cout << "Impossible de supprimer une equipe (nombre insuffisant) !" << endl;
				tag= 'n';
				}
			else
				{
				cout << "Voulez-vous vraiment supprimer une equipe (o/n) ?" << endl;
				tag= getch();
				}

			if (tag == 'o') 
				{
				int n= 0;

				cout << "Numero de l'equipe a supprimer : ";
				cin >> n;

				if ((n > 0) && (n <= tournoi->nbteams))
					{
					// recreer un tournoi modifie
					retrait_equipe(tournoi, n);
				
					cout << endl;
					cout << "Nouvelle liste des equipes:" << endl;
					for (int k= 1 ; k <= tournoi->nbteams ; k++)
						tournoi->liste[k]->afficher(true, true);

					int sav= tournoi->sauvegarde_forme(tour);
					if (sav == 0)
						cout << "Fichiers sauvegardes automatiquement !" << endl;					
					else
						cout << "Probleme de sauvegarde !" << endl;
					}
				else
					cout << "Numero errone !" << endl;
				}
			else
				cout << "Abandon..." << endl;
			}

		if ((cmd[0] == 't') && (cmd[1] == ' '))
			{
			tr= 0;
			sscanf(cmd, "t %d", &tr);

			if (tr == 0) 
				{
				char x= 0;
				sscanf(cmd, "t %c", &x);
				if ((x == 'c') && (tour == tournoi->nbtours))	// t c = tirage complementaire (nb impair d'equipes)
					{					
					tour++;
					int res= tournoi->tirage_comp();
					if (res == 0)
						{
						// sauvegarde automatique des fichiers
						int sav= tournoi->sauvegarde_forme(tour);
						if (sav == 0)
							cout << "Fichiers sauvegardes automatiquement" << endl;
						else
							cout << "Probleme de sauvegarde !" << endl;

						cout << "Tour " << tour << endl;
						for (int k= 0 ; k < (tournoi->nbtours+1)/2 ; k++)
							tournoi->matches[tournoi->nbtours][k]->show();
						}
					else
						cout << "Probleme de tirage !!!" << endl;
					}
				}
			else
				{
				if (tr > tournoi->nbtours) cout << "Erreur..." << endl;
				else if (tr != tour+1) cout << "Erreur..." << endl;
				else 
					{
					start= true;		// tournoi demarre

					tour= tr;
					int res= tournoi->tirage(tour, false);					
					if (res == 0)
						{
						// inverser l'ordre des matches afin de mettre l'eventuelle equipe inactive en dernier
						// pas besoin de recopie en profondeur
						int nb = (tournoi->nbteams-1)/2;

						Partieptr * parties = new Partieptr[nb+1];

						for (int m = nb; m >= 0; m--)
							parties[m] = tournoi->matches[tour-1][m];
						for (int m= nb ; m >= 0 ; m--)
							tournoi->matches[tour-1][m]= parties[nb-m];

						delete[] parties;

						// sauvegarde automatique des fichiers
						int sav= tournoi->sauvegarde_forme(tour);
						if (sav == 0)
							cout << endl << "Fichiers sauvegardes automatiquement" << endl;
						else
							cout << "Probleme de sauvegarde !" << endl;

						cout << endl;
						cout << "Tour " << tour << endl;
						for (int k= 0 ; k <= (tournoi->nbteams-1)/2 ; k++)
							tournoi->matches[tour-1][k]->show();
						}
					else
						cout << "Probleme de tirage !!!" << endl;
					}
				}
			}

		if ((cmd[0] == 'p') && (cmd[1] == ' '))
			{
			int tx= 0;
			unsigned n= 0;
			unsigned s1= 0, s2= 0;

			sscanf(cmd, "p %d %u", &tx, &n);

			if ((tx == 0) || (n == 0)) cout << "Erreur..." << endl;
			else if (tx > tournoi->nbtours+1) cout << "Erreur..." << endl;
			else if (n > tournoi->nbteams) cout << "Erreur..." << endl;
			else
				{
				cout << "Nb de points de l'equipe " << n << " = ";
				fflush(stdin);
				cin >> s1;		
				cout << "Nb de points de l'equipe adverse = "; 
				fflush(stdin);
				cin >> s2;
				fflush(stdin);

				int match= tournoi->setscore(tx, n, s1, s2);
				if (match >= 0) tournoi->matches[tx-1][match]->show();
				}				
			}

		if (cmd[0] == 'b')		// bilan
			{
			cout << "Bilan actuel du tournoi:" << endl;
			cout << "Tour: " << tour << endl;
			tournoi->bilan_forme();
			}

		if (cmd[0] == 'c')		// classement partiel ou final
			{
			int sav= tournoi->sauvegarde_forme(tour);
			if (sav == 0)
				cout << "Fichiers sauvegardes automatiquement !" << endl;
			else
				cout << "Probleme de sauvegarde !" << endl;

			cout << "Tour: " << tour << endl;
			cout << "Realisation du classement" << endl;
						
			tournoi->classement_forme();
			}

		if (cmd[0] == 'f')		// sauvegarde fichiers
			{
			int sav= tournoi->sauvegarde_forme(tour);
			if (sav == 0)
				cout << "Fichiers sauvegardes !" << endl;
			else
				cout << "Erreur de sauvegarde !" << endl;
			}

		if (cmd[0] == 'r')		// restauration
			{
			tag= 'o';

			if (start)
				{				
				cout << "Etes-vous sur de vouloir ecraser le tournoi en cours (o/n) ?" << endl;
				tag= getch();
				}

			if (tag == 'o')
				{
				int tst= tournoi->restauration_test_forme();
				if (tst != 0)
					{
					cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
					cout << "Restauration impossible" << endl;
					}
				else
					{
					nb= tournoi->nbteams;
					nbtr= tournoi->nbtours;

					delete tournoi;						// tout detruire

					// recreer un tournoi complet
					tournoi= new Petanque(nbtr, nb);		// equipes formees

					int tmp= tournoi->restauration_forme(tour);	// le nouveau tour sera fonction de ce qui a ete sauvegarde
					if (tmp >= 0) 
						{
						tour= tmp;
						cout << "Fichiers restaures, Tour " << tour << endl;
											
						if (tour != 0) start= true; 
						else start= false;
						}
					else 
						cout << "Erreur de restauration" << endl;
					}
				}
			}

		if (cmd[0] == 'q')		// quitter
			{
			cout << "Sur de vouloir quitter ??? Confirmer par x" << endl;	// confirmation ?
			cin >> cmd[0];
			if (cmd[0] == 'x') cmd[0]= 'q';	
			else cmd[0]= ' ';
			}
		}
	while (cmd[0] != 'q');		// quit

	cout << endl << "FIN !" << endl;
	}

