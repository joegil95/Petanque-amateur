/*
@(#) JG 2026

A compiler en VC++

Attention: d�sactiver unicode pour les noms de fichiers
*/

#include <conio.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h>
#include <time.h>

#include <iostream>

typedef char String[50];

// permet l'integration du code console en mode MFC
void gets(char * stg);

using namespace std;

class Joueur
	{
	public:
		unsigned numero;		// numero du joueur
		String nom;				// nom du joueur
		String obs;				// observation eventuelle
		int * points;			// nombre de points gagnes par le joueur a chaque tour
		int * contre;			// nombre de points perdus par le joueur a chaque tour

	public:
		Joueur();
		Joueur(unsigned num, unsigned nbtrs);
		~Joueur();

		void saisir(unsigned n);
		void definir(unsigned n, char * joueur, char * nota);
		void afficher(bool lf);
	};

typedef Joueur * Joueurptr;

class Equipe
	{
	public:
		unsigned numero;		// numero equipe
		String joueurs[3];		// noms des joueurs		
		bool elimin;			// equipe en jeu ou eliminee

	public:
		Equipe();
		Equipe(unsigned num);

		void saisir(unsigned n);
		void definir(unsigned n,  char * joueur1, char * joueur2, char * joueur3);
		void definir(unsigned n,  char * jjj);
		void afficher(bool shownum, bool lf);
	};


typedef Equipe * Equipeptr;

class Petanque;

class Partie
	{
	public: 
		Petanque * tournoi;
		
		unsigned num1, num2;	// numeros des equipes qui s'affrontent
		unsigned score1, score2;	// scores de la partie

	public:
		Partie();
		Partie(Petanque * tnoi, unsigned n1, unsigned n2);

		void show();
	};

typedef Partie * Partieptr;


class Petanque
	{
	public:
		char mode;			// F= forme, M= melee
		char pref;			// preference D= doublettes, T= triplettes en mode melee

		unsigned nbtours;
		unsigned nbteams;
		unsigned nbplayers;
		
		Joueurptr * personnes;
		Equipeptr * liste;
		Partieptr ** matches;
		bool * done;

	public:
		Petanque(unsigned nbtrs);					// tournoi eliminatoire nbtms = 2 ^ nbtrs
		Petanque(unsigned nbtrs, unsigned nbtms);					// parties en equipes formees
		Petanque(unsigned nbtrs, unsigned nbtms, unsigned nbplys, char prefce);			// parties a la melee
		~Petanque();
		
		void melange();
		int tirage(int t, bool automatic);
		int get_compteams(unsigned * tab);
		int tirage_comp();
		int tirage_elimin(int t);
		int setscore(int t, unsigned n, unsigned s1, unsigned s2);

		void bilan_forme();
		int getnext_classement_forme(bool init= false);
		void classement_forme();
		int sauvegarde_forme(int tour);
		int restauration_test_forme();
		int restauration_forme(int tr);
		
		void bilan_melee();
		int getnext_classement_melee(bool init= false);
		void classement_melee();
		int get_equipes_melee(int tour, Equipe ** oldequipes);
		int sauvegarde_melee(int tour);
		int restauration_test_melee();
		int restauration_melee(int tr);

		int sauvegarde_elimin(int tour);
		int restauration_test_elimin();
		int restauration_elimin(int tr);
	};


void remove_files();

int create_conso(Petanque * tournoi, int t);

unsigned power2(unsigned n);

unsigned nb_equipes(unsigned nbjoueurs, char preference);

void jeu_forme();

void jeu_melee();