/*
@(#) JG 2026

A compiler en VC++

Attention: d�sactiver unicode pour les noms de fichiers
*/


#include "Petanque.h"

extern Petanque * tournoi;
extern bool start;


// determination du nb d'equipes selon le nb de joueurs (melee)
// preference= 'D' pour favoriser les doublettes
// preference= 'T' pour favoriser les triplettes
// retourne le nb d'equipes a creer selon preference
unsigned nb_equipes(unsigned nbjoueurs, char preference)
	{
	unsigned n1, n2, nbe= 0;

	// n1 = nb minimal (pair) d'equipes, en favorisant les triplettes
	if (nbjoueurs % 6 == 0) n1= (nbjoueurs / 6) * 2;		// n'est pas equivalent � nbjr / 3 !
	else n1= (nbjoueurs / 6 + 1) * 2;

	// n2 = nb maximal (pair) d'equipes, en favorisant les doublettes
	n2= (nbjoueurs / 4) * 2;		// n'est pas equivalent � nbjr / 2 !

	/*
	cout << "Le nombre (pair) d'equipes doit etre compris entre: ";
	cout << n1 << " (maximum de triplettes) et " << n2 << " (maximum de doublettes)." << endl;
	cout << "Il y aura potentiellement des doublettes et des triplettes..." << endl;

	if (nbjoueurs % 4 == 0) cout << "Avec " << nbjoueurs / 2 << " equipes il n'y aura que des doublettes." << endl;
	if (nbjoueurs % 6 == 0) cout << "Avec " << nbjoueurs / 3 << " equipes il n'y aura que des triplettes." << endl;

	while(1)
		{
		cout << "Choisir le nombre (pair) d'equipes entre ces valeurs: ";
		cin >> nbe;

		if ((nbe >=  n1) && (nbe <= n2) && (nbe % 2 == 0)) break;
		else cout << "Choix non valide !" << endl;
		}
	fflush(stdin);
	*/

	if (preference == 'D') nbe= n2;
	else nbe= n1;

	return nbe;
	}


Petanque * ajout_joueur(Petanque * tournoi)
	{
	unsigned nb=1, nbtr=1, nbjr= 1;
	char prefce;

	Joueur * joueurs= new Joueur[tournoi->nbplayers+2];		// joueur 0 inutilise
	
	// recuperer les joueurs
	for (int i= 0 ; i <= tournoi->nbplayers ; i++)
		{
		joueurs[i].numero= tournoi->personnes[i]->numero;
		strcpy(joueurs[i].nom, tournoi->personnes[i]->nom);
		}
				
	nbjr= tournoi->nbplayers+1;
	nb= nb_equipes(nbjr, tournoi->pref);
	nbtr= tournoi->nbtours;
	prefce= tournoi->pref;

	delete tournoi;

	// recreer un tournoi complet
	tournoi= new Petanque(nbtr, nb, nbjr, prefce);		// equipes melees

	// recopier les joueurs
	for (int i= 0 ; i < tournoi->nbplayers ; i++)		// attention car nbplayers++
		{
		tournoi->personnes[i]->numero = joueurs[i].numero;
		strcpy(tournoi->personnes[i]->nom, joueurs[i].nom);
		}

	delete[] joueurs;

	return tournoi;
	}


Petanque * retrait_joueur(Petanque * tournoi, int n)
	{
	unsigned nb=1, nbtr=1, nbjr= 1;
	char prefce;

	if ((n > 0) && (n <= tournoi->nbplayers))
		{
		Joueur * joueurs= new Joueur[tournoi->nbplayers+1];		// joueur 0 inutilise
	
		// recuperer les joueurs
		for (int i= 0 ; i <= tournoi->nbplayers ; i++)
			{
			joueurs[i].numero= tournoi->personnes[i]->numero;
			strcpy(joueurs[i].nom, tournoi->personnes[i]->nom);
			}
				
		nbjr= tournoi->nbplayers-1;
		nb= nb_equipes(nbjr, tournoi->pref);
		nbtr= tournoi->nbtours;
		prefce= tournoi->pref;

		delete tournoi;

		// recreer un tournoi complet
		tournoi= new Petanque(nbtr, nb, nbjr, prefce);		// equipes melees

		// recopier les joueurs sauf No n
		int j= 0;
		for (int i= 0 ; i <= tournoi->nbplayers+1 ; i++)		// attention car nbplayers++
			{
			if (i != n)
				{
				tournoi->personnes[j]->numero = j;
				strcpy(tournoi->personnes[j]->nom, joueurs[i].nom);
				j++;
				}
			}

		delete[] joueurs;
		}

	return tournoi;
	}


void jeu_melee()
	{
	FILE * fin;
	char buffer[1000];
	unsigned nb=1, nbtr=1, nbjr=1;
	int tr= 0, tour= 0;
	char cmd[100]= " ";
	char tag= 'n', prefce;
	String stg= "";

	cout << "Combien de joueurs ? ";
	cin >> nbjr; cout << endl;

	if (nbjr < 8)
		{
		cout << "Nombre de joueurs insuffisant !" << endl;
		getch();
		return;
		}

	cout << "Voulez-vous un maximum de doublettes (d) ou de triplettes (t) ? ";
	cin >> tag;

	if (tag == 'd') prefce='D';
	else prefce='T';

	nb= nb_equipes(nbjr, prefce);		// nb pair d'equipes selon preference	
	cout << "Nombre d'equipes = " << nb << endl << endl;

	cout << "Combien de tours ? ";
	cin >> nbtr;

	if (nbtr > 10)
		{
		cout << "Nombre de tours trop eleve (maximum 10) !" << endl;
		getch();
		return;
		}

	if (nbtr >= nb)
		{
		cout << "Nombre de tours trop eleve pour ce nombre d'equipes !" << endl;
		getch();
		return;
		}

	cout << "Creation du tournoi pour " << nbjr << " joueurs (" << nb << " equipes), sur " << nbtr << " tours" << endl;
	tournoi= new Petanque(nbtr, nb, nbjr, prefce);

	fflush(stdin);

	do
		{
		cout << endl << "Entrer une commande (? pour aide) et penser a enregistrer (f) :";
		gets(cmd);

		if (cmd[0] == '?')		// help
			{			
			cout << "j %u = saisir joueur No u" << endl;
			cout << "l= lister les joueurs" << endl;
			cout << "a= ajouter un joueur en plus du nombre prevu (avant demarrage)" << endl;
			cout << "s= supprimer un joueur de la liste (avant demarrage)" << endl;
			cout << "v= voir les equipes du tour" << endl;
			cout << "t %d = faire tirage tour No d" << endl;
			cout << "m= melanger les joueurs et reformer les equipes du tour (seulement en cas de besoin)" << endl;
			cout << "p %d %u = saisir le score d'une partie du tour No d, equipe No u" << endl;
			cout << "b = bilan des scores de tous les joueurs sur tous les tours" << endl;
			cout << "c = classement des joueurs" << endl;
			cout << "f= sauvegarder les donnees dans les fichiers" << endl;
			cout << "r= restaurer les donnees depuis les fichiers" << endl;
			cout << "q = quitter" << endl;
			}

		if ((cmd[0] == 'j') && (cmd[1] == ' '))
			{
			unsigned n= 0;
			sscanf(cmd, "j %u", &n);
			if ((n > 0) && (n <= tournoi->nbplayers))
				{
				tag= 'o';
				if (strcmp(tournoi->personnes[n]->nom, "") != 0)
					{
					cout << "Modifier ce joueur (o/n) ?" << endl;
					tag= getch();
					fflush(stdin);
				}
				if (tag == 'o') 
					{
					cout << "J " << n <<": "; gets(stg);
					tournoi->personnes[n]->definir(n, stg, "");
					tournoi->personnes[n]->afficher(true);
					}
				else cout << "Abandon..." << endl;
				}
			else cout << "Erreur..." << endl;
			}

		if (cmd[0] == 'l')
			{
			cout << "Liste des joueurs:" << endl;
			for (int k= 1 ; k <= tournoi->nbplayers ; k++)
				tournoi->personnes[k]->afficher(true);
			}

		if (cmd[0] == 'a')
			{
			cout << "Liste actuelle des joueurs:" << endl;
			for (int k= 1 ; k <= tournoi->nbplayers ; k++)
				tournoi->personnes[k]->afficher(true);
			
			if (start)
				{
				cout << "Tournoi en cours. Impossible d'ajouter un joueur !" << endl;
				tag= 'n';
				}
			else
				{
				cout << "Voulez-vous vraiment ajouter un joueur supplementaire No " << tournoi->nbplayers+1 << " (o/n) ?" << endl;
				tag= getch();
				fflush(stdin);
				}

			if (tag == 'o') 
				{
				// recreer un tournoi modifie
				tournoi= ajout_joueur(tournoi);

				// saisir nouveau joueur
				cout << "J " << tournoi->nbplayers << ": "; gets(stg);
				tournoi->personnes[tournoi->nbplayers]->definir(tournoi->nbplayers, stg, "");
				tournoi->personnes[tournoi->nbplayers]->afficher(true);

				cout << endl;
				cout << "Nouvelle liste des joueurs:" << endl;
				for (int k= 1 ; k <= tournoi->nbplayers ; k++)
					tournoi->personnes[k]->afficher(true);

				int sav= tournoi->sauvegarde_melee(tour);
				if (sav == 0)
					cout << "Fichiers sauvegardes automatiquement !" << endl;				
				else
					cout << "Probleme de sauvegarde !" << endl;
				}
			else
				cout << "Abandon..." << endl;
			}

		if (cmd[0] == 's')
			{
			cout << "Liste actuelle des joueurs:" << endl;
			for (int k= 1 ; k <= tournoi->nbplayers ; k++)
				tournoi->personnes[k]->afficher(true);

			if (start)
				{
				cout << "Tournoi en cours. Impossible de supprimer un joueur !" << endl;
				tag= 'n';
				}
			else if (tournoi->nbplayers <= 8)
				{
				cout << "Impossible de supprimer un joueur (nombre insuffisant) !" << endl;
				tag= 'n';
				}
			else
				{
				cout << "Voulez-vous vraiment supprimer un joueur (o/n) ?" << endl;
				tag= getch();
				}

			if (tag == 'o') 
				{
				int n= 0;

				cout << "Numero du joueur a supprimer : ";
				cin >> n;

				if ((n > 0) && (n <= tournoi->nbplayers))
					{
					// recreer un tournoi modifie
					tournoi= retrait_joueur(tournoi, n);
				
					cout << endl;
					cout << "Nouvelle liste des joueurs:" << endl;
					for (int k= 1 ; k <= tournoi->nbplayers ; k++)
						tournoi->personnes[k]->afficher(true);

					int sav= tournoi->sauvegarde_melee(tour);
					if (sav == 0)
						cout << "Fichiers sauvegardes automatiquement !" << endl;				
					else
						cout << "Probleme de sauvegarde !" << endl;
					}
				else
					cout << "Numero errone !" << endl;
				}
			else
				cout << "Abandon..." << endl;
			}

		if (cmd[0] == 'v')
			{
			cout << "Liste des equipes:" << endl;
			for (int k= 1 ; k <= tournoi->nbteams ; k++)
				tournoi->liste[k]->afficher(true, true);
			}

		if ((cmd[0] == 't') && (cmd[1] == ' '))
			{
			tr= 0;
			sscanf(cmd, "t %d", &tr);
					
			if (tr > tournoi->nbtours) cout << "Erreur..." << endl;
			else if (tr != tour+1) cout << "Erreur..." << endl;
			else 				
				{
				cout << "Le tour actuel doit etre termine avant de passer au suivant" << endl;
				cout << "Etes vous sur de vouloir continuer (o/n) ?" << endl;
				tag= getch();
				if (tag == 'o') 
					{
					start= true;	// tournoi demarre

					// sauvegarde forcee de l'ancien tour pour memoriser les anciennes equipes
					int sav= tournoi->sauvegarde_melee(tour);
					if (sav != 0)
						cout << "Probleme de sauvegarde !" << endl;

					tour= tr;

					cout << "Voulez-vous melanger les equipes pour ce nouveau tour  (o/n) ?" << endl;
					tag= getch();
					if (tag == 'o') 
						{
						cout << "Tirage des equipes a la melee:" << endl;
						tournoi->melange();		
						cout << "Equipes constituees" << endl;
						}

					int res= tournoi->tirage(tour, true);		
					if (res == 0)
						{
						// sauvegarde forcee du nouveau tour (et des nouvelles equipes si melange)
						int sav= tournoi->sauvegarde_melee(tour);
						if (sav == 0)
							cout << endl << "Fichiers sauvegardes automatiquement" << endl;
						else
							cout << "Probleme de sauvegarde !" << endl;

						cout << "Tour " << tour << endl;
						for (int k= 0 ; k <= (tournoi->nbteams-1)/2 ; k++)
							tournoi->matches[tour-1][k]->show();
						}
					else
						cout << "Probleme de tirage !!!" << endl;
					}
				else
					cout << "Abandon..." << endl;
				}
			}

		if (cmd[0] == 'm')
			{
			cout << "Le melange des equipes est normalement deja fait automatiquement" << endl;
			cout << "A eviter si des scores de ce tour ont deja ete enregistres !" << endl;
			cout << "Etes vous sur de vouloir remelanger les equipes (o/n) ?" << endl;

			tag= getch();
			if (tag == 'o') 
				{
				cout << "Tirage des equipes a la melee:" << endl;
				tournoi->melange();	
				cout << "Equipes constituees" << endl;
				}
			else
				cout << "Abandon..." << endl;
			}

		if ((cmd[0] == 'p') && (cmd[1] == ' '))
			{
			unsigned n= 0;
			unsigned s1= 0, s2= 0;

			sscanf(cmd, "p %d %u", &tr, &n);

			if ((tr == 0) || (n == 0)) cout << "Erreur..." << endl;
			else if (tr != tour) cout << "Tour non valide ou cloture..." << endl;
			else if (n > tournoi->nbteams) cout << "Erreur..." << endl;
			else
				{
				cout << "Nb de points de l'equipe " << n << " = ";
				fflush(stdin);
				cin >> s1;		
				cout << "Nb de points de l'equipe adverse = "; 
				fflush(stdin);
				cin >> s2;
				fflush(stdin);

				int match= tournoi->setscore(tr, n, s1, s2);
				if (match >= 0) tournoi->matches[tr-1][match]->show();
				}
			}

		if (cmd[0] == 'b')		// bilan
			{
			cout << "Bilan actuel du tournoi:" << endl;
			cout << "Tour: " << tour << endl;
			tournoi->bilan_melee();
			}

		if (cmd[0] == 'c')		// classement partiel ou final
			{
			int sav= tournoi->sauvegarde_melee(tour);
			if (sav == 0)
				cout << "Fichiers sauvegardes automatiquement !" << endl;
			else
				cout << "Probleme de sauvegarde !" << endl;

			cout << "Tour: " << tour << endl;
			cout << "Realisation du classement" << endl;
			tournoi->classement_melee();
			}

		if (cmd[0] == 'f')		// sauvegarde fichiers
			{
			int sav= tournoi->sauvegarde_melee(tour);
			if (sav == 0)
				cout << "Fichiers sauvegardes !" << endl;
			else
				cout << "Erreur de sauvegarde !" << endl;
			}

		if (cmd[0] == 'r')		// restauration
			{
			tag= 'o';

			if (start)
				{				
				cout << "Etes-vous sur de vouloir ecraser le tournoi en cours (o/n) ?" << endl;
				tag= getch();
				}

			if (tag == 'o')
				{
				int tst= tournoi->restauration_test_melee();
				if (tst != 0)
					{
					cout << "Erreur fichiers equipes / joueurs (mode ou parametres incorrects)" << endl;
					cout << "Restauration impossible" << endl;
					}
				else
					{
					nbjr= tournoi->nbplayers;
					nb= tournoi->nbteams;
					nbtr= tournoi->nbtours;
					prefce= tournoi->pref;

					delete tournoi;						// tout detruire

					// recreer un tournoi complet
					tournoi= new Petanque(nbtr, nb, nbjr, prefce);		// equipes melees

					int tmp= tournoi->restauration_melee(tour);	// le nouveau tour sera fonction de ce qui a ete sauvegarde
					if (tmp >= 0) 
						{
						tour= tmp;
						cout << "Fichiers restaures, Tour " << tour << endl;
											
						if (tour != 0) start= true; 
						else start= false;
						}
					else 
						cout << "Erreur de restauration" << endl;
					}				
				}		
			}

		if (cmd[0] == 'q')		// quitter
			{
			cout << "Sur de vouloir quitter ??? Confirmer par x" << endl;	// confirmation ?
			cin >> cmd[0];
			if (cmd[0] == 'x') cmd[0]= 'q';	
			else cmd[0]= ' ';
			}
		}
	while (cmd[0] != 'q');		// quit

	cout << endl << "FIN !" << endl;

	}
