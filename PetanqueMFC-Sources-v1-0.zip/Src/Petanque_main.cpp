/*
@(#) JG 2026

A compiler en VC++

Attention: d�sactiver unicode pour les noms de fichiers
*/


#include "Petanque.h"


Petanque * tournoi= NULL;
bool start= false;


void main()
	{
	int choice= 0;
	char answer= 'n';

	cout << "Gestionnaire de tournois de petanque en doublettes / triplettes" << endl << endl;

	cout << "Attention: deux joueurs ne doivent pas porter exactement le meme nom !" << endl << endl;

	cout << "Voulez-vous supprimer tous les fichiers anterieurs avant de demarrer un nouveau tournoi (o/n) ? ";
	cin >> answer; cout << endl;
	if (answer == 'o') remove_files();

	do	
		{
		cout << "Equipes formees (1) ou a la melee (2) ? ";
		cin >> choice;
		}
	while ((choice != 1) && (choice != 2));
	cout << endl;

	if (choice == 1) jeu_forme();
	else jeu_melee();

	if (tournoi != NULL) delete tournoi;

	getch();
	}

