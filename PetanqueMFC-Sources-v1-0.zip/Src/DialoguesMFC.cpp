
#include "DialoguesMFC.h"

#include "PetanqueMFC.rh"

#include "PetanqueMFC.h"

extern Petanque * tournoi;
extern bool start;
extern int tour;


// boites de dialogue modales

// NB:	Dans le fichier rc, le controle associe � la grille dit avoir le type special "MFCGridCtrl":
//      CONTROL "NOM", IDG_GRID, "MFCGridCtrl", WS_CHILD | WS_VISIBLE, x, y, dx, dy
//      l'identifiant IDG_GRID etant declare dans le fichier rh

// NB:	Si dans le fichier rc, la boite de dialogue a pour style WS_THICKFRAME au lieu de DS_MODALFRAME
//		alors elle peut etre resizee par l'utilisateur

// NB:	Attention si la zone attribuee a la liste dans le fichier rc ne permet pas de voir entierement
//		les dernieres cellules (en bas ou � droite) lors d'un scroll, il y a plantage lors du remplissage
//		de ces cellules...


void Reset_grid_texts(CGridCtrl * grid)
{
	GV_ITEM Item;
	
	for (int col = 2; col < grid->GetColumnCount(); col++)
	{
		for (int row = 1; row < grid->GetRowCount(); row++)
		{
			grid->SetItemState(row, col, 0);

			Item.mask= GVIF_TEXT | GVIF_FORMAT;		// reset de ces deux attributs
			Item.row = row;
			Item.col = col;
			Item.nFormat = 0;
			Item.strText.Format(_T(""));
			grid->SetItem(&Item);
		}
	}

	grid->SetEditable(TRUE);
}


/*
Classe de dialogue de configuration
*/

CInitDlg::CInitDlg(int id) : CDialog(id)
{
	field1 = "";
	field2 = "";
	contexte = 0;
	choix = 1;
}

BOOL CInitDlg::OnInitDialog()
{
	field1 = "";		// champ de saisie n�1
	field2 = "";		// champ de saisie n�2
	choix = 1;
	CheckRadioButton(IDC_RB1, IDC_RB3, IDC_RB1);

	SetDlgItemText(IDC_TEXT1, "Nombre d'�quipes :");
	SetDlgItemText(IDC_TEXT2, "Nombre de tours :");	
	SetDlgItemText(IDC_TEXT3, "Nom du tournoi :");	

	SetDlgItemText(IDC_RB1, "Equipes Form�es");
	SetDlgItemText(IDC_RB2, "Equipes M�l�es");
	SetDlgItemText(IDC_RB3, "Equipes en mode Eliminatoire");

	CDialog::OnInitDialog();	// appel methode de base

	return TRUE;
}

void CInitDlg::DoDataExchange(CDataExchange* ddx)
{
	int button;

	CDialog::DoDataExchange(ddx);    // appel de la methode de base
									 // echanges DDX lors de l'ouverture et de la fermeture par OK

	// champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{

	}

	// champ TRUE en sortie
	if (ddx->m_bSaveAndValidate == TRUE)
	{
		DDX_Text(ddx, IDC_FIELD1, field1);
		DDX_Text(ddx, IDC_FIELD2, field2);
		DDX_Text(ddx, IDC_FIELD3, field3);

		button = GetCheckedRadioButton(IDC_RB1, IDC_RB3);
		switch (button)
		{
		case IDC_RB1: choix = 1; break;
		case IDC_RB2: choix = 2; break;
		case IDC_RB3: choix = 3; break;
		}
	}
}


void CInitDlg::OnRadioButton1()		// Clic sur un bouton radio
{
	SetDlgItemText(IDC_TEXT1, "Nombre d'�quipes :");
}


void CInitDlg::OnRadioButton2()		// Clic sur un bouton radio
{
	SetDlgItemText(IDC_TEXT1, "Nombre de joueurs :");
}

void CInitDlg::OnRadioButton3()		// Clic sur un bouton radio
{
	SetDlgItemText(IDC_TEXT1, "Nombre d'�quipes :");
}

BEGIN_MESSAGE_MAP(CInitDlg, CDialog)
	ON_BN_CLICKED(IDC_RB1, OnRadioButton1)
	ON_BN_CLICKED(IDC_RB2, OnRadioButton2)
	ON_BN_CLICKED(IDC_RB3, OnRadioButton3)
END_MESSAGE_MAP()


/*
Classe de dialogue de saisie
*/

CDlg::CDlg(int id) : CDialog(id)
{
	field1 = "";
	contexte = 0;
}

BOOL CDlg::OnInitDialog()
{
	field1 = "";		// champ de saisie n�1

	if (contexte == 1)		// anciens scores
	{
		SetDlgItemText(IDC_TEXT1, "Tour � visualiser :");
	}

	if (contexte == 2)		// suppression de joueur
	{
		SetDlgItemText(IDC_TEXT1, "Joueur � supprimer N� :");
	}

	if (contexte == 3)		// suppression d'�quipe
	{
		SetDlgItemText(IDC_TEXT1, "Equipe � supprimer N� :");

	}

	GetDlgItem(IDC_FIELD1)->SetFocus();		// Focus au champ de saisie

	CDialog::OnInitDialog();	// appel methode de base

	return FALSE;		// sinon Windows remet le focus sur le premier contr�le de la boite !
}

void CDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx);    // appel de la methode de base
									 // echanges DDX lors de l'ouverture et de la fermeture par OK

	// champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{

	}

	// champ TRUE en sortie
	if (ddx->m_bSaveAndValidate == TRUE)
	{
		DDX_Text(ddx, IDC_FIELD1, field1);
	}
}

BEGIN_MESSAGE_MAP(CDlg, CDialog)
END_MESSAGE_MAP()


/*
Classe CEquipesDlg
*/

CEquipesDlg::CEquipesDlg(int resId, CWnd *parent) : CDialog(resId, parent)
{
	ParentWnd = (CMainWindow *) parent;

	// recuperation du Grid pour DoDataExchange()
	Grid_Equipes = new CGridCtrl;
	ParentWnd->Grid_Equipesptr = Grid_Equipes;
}

CEquipesDlg::~CEquipesDlg()
{
}

BOOL CEquipesDlg::OnInitDialog()
{
	// appelle methode de base qui appelle DoDataExchange() via UpdateData()
	CDialog::OnInitDialog();	

	// raz de la grille
	Reset_grid_texts(Grid_Equipes);

	Grid_Equipes->SetBkColor(::GetSysColor(COLOR_3DFACE));

	// remplissage de la grille a partir des equipes du tournoi
	Fill_Grid_Equipes(Grid_Equipes);

	// si verrouillage ou tournoi demarr�, on ne peut plus modifier les equipes
	Grid_Equipes->SetEditable(ParentWnd->Equipes_edit);	
	if (start) Grid_Equipes->SetEditable(FALSE);

	Grid_Equipes->SetFocusCell(0, 0);
	
	CRect rect;
	Grid_Equipes->GetWindowRect(&rect);		// dimensions de la grille

	rect.InflateRect(0, 0, 50, 120);
	this->MoveWindow(rect);		// dimensionnement de la boite en fonction de la grille

	// empeche reapparition de la scroll bar apres resize !
	Grid_Equipes->ShowScrollBar(SB_BOTH, FALSE);

	Grid_Equipes->Invalidate();		// force rafraichissement

	return TRUE;
}

// methode appelee lors du clic sur Appliquer
void CEquipesDlg::OnApply()
{
	// transfere le contenu de la grille dans les equipes du tournoi
	// et actualise l'affichage
	Dump_Grid_Equipes(Grid_Equipes);
	Fill_Grid_Equipes(Grid_Equipes);

	Grid_Equipes->Invalidate();
}

// methode appelee lors de la sortie par OK ou CR
void CEquipesDlg::OnOK()
{
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDOK);
}

// methode appelee lors de la sortie par CANCEL ou ESC
// attention car par defaut ESC ferme la boite et entraine la perte des donnees !
void CEquipesDlg::OnCancel()
{
	// ne rien faire bloque la sortie de boite par ESC

	/*
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDCANCEL);
	*/
}


// methode appelee � l'ouverture et lors de la fermeture de la boite par OK
void CEquipesDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx); // Appel de la methode de base

	// champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{
		// il est apparemment trop tard a ce stade pour modifier la grille !
	}

	DDX_GridControl(ddx, IDG_EQUIPES_GRID, *Grid_Equipes);
	
	// champ TRUE en sortie
	if (ddx->m_bSaveAndValidate == TRUE)
	{
		// transfere le contenu de la grille dans les equipes du tournoi
		Dump_Grid_Equipes(Grid_Equipes);
	}
}


BEGIN_MESSAGE_MAP(CEquipesDlg, CDialog)
	ON_BN_CLICKED(IDB_APPLY1, OnApply)
END_MESSAGE_MAP()

/*
Gestion de la grille equipes
*/

void Fill_Grid_Equipes(CGridCtrl * grid)
{
	if (tournoi == NULL) return;

	// parametres generaux
	// grid->SetEditable(TRUE);
	grid->EnableDragAndDrop(FALSE);
	grid->SetColumnResize(FALSE);
	grid->SetRowResize(FALSE);

	grid->SetRowCount(tournoi->nbteams + 1);
	grid->SetColumnCount(5);
	grid->SetFixedRowCount(1);
	grid->SetFixedColumnCount(2);

	grid->ShowScrollBar(SB_BOTH, FALSE);

	// remplissage de la grille
	// la numerotation des lignes / colonnes commence � 0

	GV_ITEM Item;
	Item.mask = GVIF_TEXT | GVIF_FORMAT;

	MAKE_ITEM(0, 0, DT_LEFT | DT_WORDBREAK, _T("EQUIPES"));
	grid->SetItem(&Item);

	MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Num�ro"));
	grid->SetItem(&Item);

	for (int col = 2; col < grid->GetColumnCount(); col++)
	{
		MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("Joueur %d"), Item.col - 1);
		grid->SetItem(&Item);
	}

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		MAKE_ITEM_EX(row, 0, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T("Equipe %d"), row);
		grid->SetItem(&Item);

		MAKE_ITEM_EX(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T("%d"), row);
		grid->SetItem(&Item);
	}

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		for (int col = 2; col < grid->GetColumnCount(); col++)
		{
			MAKE_ITEM(row, col, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T(tournoi->liste[row]->joueurs[col-2]));
			grid->SetItem(&Item);
		}
	}

	// Resize automatiquement les cases en fonction de leur contenu !
	// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
	grid->AutoSize();	

	int widthEquipes= grid->GetColumnWidth(0);
	int widthNumero= grid->GetColumnWidth(1);
	int widthNames= grid->GetColumnWidth(3) + 10;

	// Resize manuel des colonnes
	grid->SetColumnWidth(0, max(widthEquipes, 80));
	grid->SetColumnWidth(1, max(widthNumero, 51));

	for (int col = 2; col < grid->GetColumnCount(); col++)
	{
		grid->SetColumnWidth(col, max(widthNames, 100));	
	}
}


void Dump_Grid_Equipes(CGridCtrl * grid)
{
	CString num, stg1, stg2, stg3;

	if (tournoi == NULL) return;

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		num = grid->GetItemText(row, 1);

		stg1 = grid->GetItemText(row, 2);
		stg2 = grid->GetItemText(row, 3);
		stg3 = grid->GetItemText(row, 4);

		if (stg1.GetLength() > 16) stg1.Truncate(16);		// Tronque les noms trop longs
		if (stg2.GetLength() > 16) stg2.Truncate(16);
		if (stg3.GetLength() > 16) stg3.Truncate(16);

		if (stg1 == "") stg1= "?";

		tournoi->liste[row]->definir(atoi(num), 
			(char *) stg1.GetString(), (char *) stg2.GetString(), (char *) stg3.GetString());		
	}	
}


/*
Classe CJoueursDlg
*/

CJoueursDlg::CJoueursDlg(int resId, CWnd *parent) : CDialog(resId, parent)
{
	ParentWnd = (CMainWindow *) parent;

	// recuperation du Grid pour DoDataExchange()
	Grid_Joueurs = new CGridCtrl;
	ParentWnd->Grid_Joueursptr = Grid_Joueurs;
}

CJoueursDlg::~CJoueursDlg()
{
}

BOOL CJoueursDlg::OnInitDialog()
{
	// appelle methode de base qui appelle DoDataExchange() via UpdateData()
	CDialog::OnInitDialog();

	// raz de la grille
	Reset_grid_texts(Grid_Joueurs);

	Grid_Joueurs->SetBkColor(::GetSysColor(COLOR_3DFACE));

	// remplissage de la grille a partir des Joueurs du tournoi
	Fill_Grid_Joueurs(Grid_Joueurs);

	// si verrouillage ou tournoi demarre, on ne peut plus modifier les Joueurs
	Grid_Joueurs->SetEditable(ParentWnd->Joueurs_edit);
	if (start) Grid_Joueurs->SetEditable(FALSE);

	Grid_Joueurs->SetFocusCell(0, 0);

	CRect rect;
	Grid_Joueurs->GetWindowRect(&rect);		// dimensions de la grille

	rect.InflateRect(0, 0, 50, 120);
	this->MoveWindow(rect);		// dimensionnement de la boite en fonction de la grille

	// empeche reapparition de la scroll bar apres resize !
	Grid_Joueurs->ShowScrollBar(SB_BOTH, FALSE);

	Grid_Joueurs->Invalidate();		// force rafraichissement

	return TRUE;
}

// methode appelee lors du clic sur Appliquer
void CJoueursDlg::OnApply()
{
	// transfere le contenu de la grille dans les Joueurs du tournoi
	// et actualise l'affichage
	Dump_Grid_Joueurs(Grid_Joueurs);
	Fill_Grid_Joueurs(Grid_Joueurs);

	Grid_Joueurs->Invalidate();
}

// methode appelee lors de la sortie par OK ou CR
void CJoueursDlg::OnOK()
{
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);	

	EndDialog(IDOK);
}

// methode appelee lors de la sortie par CANCEL ou ESC
// attention car par defaut ESC ferme la boite et entraine la perte des donnees !
void CJoueursDlg::OnCancel()
{
	// ne rien faire bloque la sortie de boite par ESC

	/*
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDCANCEL);
	*/
}


// methode appelee � l'ouverture et lors de la fermeture de la boite par OK
void CJoueursDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx); // Appel de la methode de base

								  // champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{
		// il est apparemment trop tard a ce stade pour modifier la grille !
	}

	DDX_GridControl(ddx, IDG_JOUEURS_GRID, *Grid_Joueurs);

	// champ TRUE en sortie
	if (ddx->m_bSaveAndValidate == TRUE)
	{
		// transfere le contenu de la grille dans les Joueurs du tournoi
		Dump_Grid_Joueurs(Grid_Joueurs);
	}
}


BEGIN_MESSAGE_MAP(CJoueursDlg, CDialog)
	ON_BN_CLICKED(IDB_APPLY2, OnApply)
END_MESSAGE_MAP()


/*
Gestion de la grille joueurs
*/

void Fill_Grid_Joueurs(CGridCtrl * grid)
{
	if (tournoi == NULL) return;

	// parametres generaux
	// grid->SetEditable(TRUE);
	grid->EnableDragAndDrop(FALSE);
	grid->SetColumnResize(FALSE);
	grid->SetRowResize(FALSE);

	grid->SetRowCount(tournoi->nbplayers + 1);
	grid->SetColumnCount(4);
	grid->SetFixedRowCount(1);
	grid->SetFixedColumnCount(2);

	grid->ShowScrollBar(SB_BOTH, FALSE);

	// remplissage de la grille
	// la numerotation des lignes / colonnes commence � 0

	GV_ITEM Item;
	Item.mask = GVIF_TEXT | GVIF_FORMAT;

	MAKE_ITEM(0, 0, DT_LEFT | DT_WORDBREAK, _T("JOUEURS"));
	grid->SetItem(&Item);

	MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Num�ro"));
	grid->SetItem(&Item);
	
	MAKE_ITEM(0, 2, DT_CENTER | DT_WORDBREAK, _T("Nom"));
	grid->SetItem(&Item);
	
	MAKE_ITEM(0, 3, DT_CENTER | DT_WORDBREAK, _T("Observations"));
	grid->SetItem(&Item);

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		MAKE_ITEM_EX(row, 0, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T("Joueur %d"), row);
		grid->SetItem(&Item);

		MAKE_ITEM_EX(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T("%d"), row);
		grid->SetItem(&Item);

		MAKE_ITEM(row, 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T(tournoi->personnes[row]->nom));
		grid->SetItem(&Item);

		MAKE_ITEM(row, 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
			_T(tournoi->personnes[row]->obs));
		grid->SetItem(&Item);
	}

	// Resize automatiquement les cases en fonction de leur contenu !
	// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
	grid->AutoSize();	

	int widthJoueur= grid->GetColumnWidth(0);
	int widthNumero= grid->GetColumnWidth(1);
	int widthName= grid->GetColumnWidth(2) * 2;
	int widthObs= grid->GetColumnWidth(3) * 2;

	// Resize manuel des colonnes
	grid->SetColumnWidth(0, max(widthJoueur, 80));
	grid->SetColumnWidth(1, max(widthNumero, 51));
	grid->SetColumnWidth(2, max(widthName, 130));
	grid->SetColumnWidth(3, max(widthObs, 170));
}


void Dump_Grid_Joueurs(CGridCtrl * grid)
{
	CString num, stg, obs;

	if (tournoi == NULL) return;

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		num = grid->GetItemText(row, 1);
		stg = grid->GetItemText(row, 2);
		obs = grid->GetItemText(row, 3);

		if (stg.GetLength() > 16) stg.Truncate(16);		// raccourcit les champs trop longs
		if (obs.GetLength() > 20) obs.Truncate(20);

		if (stg == "") stg= "?";

		tournoi->personnes[row]->definir(atoi(num), (char *) stg.GetString(), (char *) obs.GetString());
	}
}


/*
Classe CScoresDlg
*/

CScoresDlg::CScoresDlg(int resId, CWnd *parent, int t) : CDialog(resId, parent)
{
	ParentWnd = (CMainWindow *)parent;

	// recuperation du Grid pour DoDataExchange()
	Grid_Scores = new CGridCtrl;
	((CMainWindow *) parent)->Grid_Scoresptr = Grid_Scores;

	tr = t;		// tour auquel s'appliquent les scores
}

CScoresDlg::~CScoresDlg()
{
}

BOOL CScoresDlg::OnInitDialog()
{
	// appelle methode de base qui appelle DoDataExchange() via UpdateData()
	CDialog::OnInitDialog();

	// raz de la grille
	Reset_grid_texts(Grid_Scores);

	Grid_Scores->SetBkColor(::GetSysColor(COLOR_3DFACE));

	// remplissage de la grille a partir des equipes du tournoi
	Fill_Grid_Scores(Grid_Scores, tr);

	Grid_Scores->SetFocusCell(0, 0);

	CRect rect;
	Grid_Scores->GetWindowRect(&rect);		// dimensions de la grille

	rect.InflateRect(0, 0, 50, 120);
	this->MoveWindow(rect);			// dimensionnement de la boite en fonction de la grille

	// empeche reapparition de la scroll bar apres resize !
	Grid_Scores->ShowScrollBar(SB_BOTH, FALSE);

	Grid_Scores->Invalidate();		// force rafraichissement

	return TRUE;
}

// methode appelee lors du clic sur Appliquer
void CScoresDlg::OnApply()
{
	// transfere le contenu de la grille dans les equipes du tournoi
	// et actualise l'affichage
	Dump_Grid_Scores(Grid_Scores, tr);
	Fill_Grid_Scores(Grid_Scores, tr);

	Grid_Scores->Invalidate();
}

// methode appelee lors de la sortie par OK ou CR
void CScoresDlg::OnOK()
{
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDOK);
}

// methode appelee lors de la sortie par CANCEL ou ESC
// attention car par defaut ESC ferme la boite et entraine la perte des donnees !
void CScoresDlg::OnCancel()
{
	// ne rien faire bloque la sortie de boite par ESC

	/*
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDCANCEL);
	*/
}


// methode appelee � l'ouverture et lors de la fermeture de la boite par OK
void CScoresDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx); // Appel de la methode de base

	// champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{
		// il est apparemment trop tard a ce stade pour modifier la grille !
	}

	DDX_GridControl(ddx, IDG_SCORES_GRID, *Grid_Scores);

	// champ TRUE en sortie
	if (ddx->m_bSaveAndValidate == TRUE)
	{
		// transfere le contenu de la grille dans les equipes du tournoi
		Dump_Grid_Scores(Grid_Scores, tr);
	}
}


BEGIN_MESSAGE_MAP(CScoresDlg, CDialog)
	ON_BN_CLICKED(IDB_APPLY3, OnApply)
END_MESSAGE_MAP()


/*
Gestion de la grille matches / scores
*/

void Fill_Grid_Scores(CGridCtrl * grid, int t)
{
	if (tournoi == NULL) return;

	// parametres generaux
	grid->SetEditable(TRUE);
	grid->EnableDragAndDrop(FALSE);
	grid->SetColumnResize(FALSE);
	grid->SetRowResize(FALSE);

	if (tournoi->nbteams % 2) grid->SetRowCount(tournoi->nbteams + 2);
	else grid->SetRowCount(tournoi->nbteams + 1);
	grid->SetColumnCount(4);
	grid->SetFixedRowCount(1);
	if (t == tournoi->nbtours + 1)		// tour compl�mentaire
		grid->SetFixedColumnCount(2);
	else								// tour normal
		grid->SetFixedColumnCount(3);

	grid->ShowScrollBar(SB_BOTH, FALSE);

	// remplissage de la grille
	// la numerotation des lignes / colonnes commence � 0

	GV_ITEM Item;
	Item.mask = GVIF_TEXT | GVIF_FORMAT;

	MAKE_ITEM_EX(0, 0, DT_LEFT | DT_WORDBREAK, _T("TOUR N� %d"), t);
	grid->SetItem(&Item);

	MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Equipes"));
	grid->SetItem(&Item);

	MAKE_ITEM(0, 2, DT_CENTER | DT_WORDBREAK, _T("Num�ros"));
	grid->SetItem(&Item);

	MAKE_ITEM(0, 3, DT_CENTER | DT_WORDBREAK, _T("Scores"));
	grid->SetItem(&Item);

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		if (tournoi->matches[t - 1][(row - 1) / 2] == NULL)		// cas du tour complementaire incomplet
			continue;

		if (row % 2)
		{
			MAKE_ITEM_EX(row, 0, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("Partie %d  \\"), ((row - 1) / 2) + 1);
			grid->SetItem(&Item);
		}
		else
		{
			MAKE_ITEM_EX(row, 0, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("Partie %d  /"), ((row - 1) / 2) + 1);
			grid->SetItem(&Item);
		}

		char stg[200];

		if (row % 2)
		{
			unsigned n1 = tournoi->matches[t - 1][(row - 1) / 2]->num1;
			strcpy(stg, tournoi->liste[n1]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[n1]->joueurs[1]);
			if (strcmp(tournoi->liste[n1]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[n1]->joueurs[2]);
		}
		else
		{
			unsigned n2 = tournoi->matches[t - 1][(row - 1) / 2]->num2;
			strcpy(stg, tournoi->liste[n2]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[n2]->joueurs[1]);
			if (strcmp(tournoi->liste[n2]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[n2]->joueurs[2]);
		}

		MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T(stg));
		grid->SetItem(&Item);

		if (row % 2)
		{
			MAKE_ITEM_EX(row, 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%u"), tournoi->matches[t - 1][(row - 1) / 2]->num1);
			grid->SetItem(&Item);
		}
		else
		{
			MAKE_ITEM_EX(row, 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%u"), tournoi->matches[t - 1][(row - 1) / 2]->num2);
			grid->SetItem(&Item);
		}

		if (row % 2)
		{
			MAKE_ITEM_EX(row, 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%u"), tournoi->matches[t - 1][(row - 1) / 2]->score1);
			grid->SetItem(&Item);
		}
		else
		{
			MAKE_ITEM_EX(row, 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%u"), tournoi->matches[t - 1][(row - 1) / 2]->score2);
			grid->SetItem(&Item);
		}
	}

	// verrouille les scores des �quipes qui ne jouent pas si nb impair ou tirage complementaire
	if (tournoi->nbteams % 2)
	{
		for (int row = 1; row < grid->GetRowCount(); row++)
		{
			if (tournoi->matches[t - 1][(row - 1) / 2] == NULL)		// cas du tour complementaire incomplet
			{
				grid->SetItemState(row, 3, grid->GetItemState(row, 3) | GVIS_READONLY);
			}
			else
			{
				if (row % 2)
				{ 
					if (tournoi->matches[t - 1][(row - 1) / 2]->num1 == 0)
					{
						grid->SetItemState(row, 3, grid->GetItemState(row, 3) | GVIS_READONLY);
						if (t <= tournoi->nbtours)		// tour normal => verrouiller les 2 scores
							grid->SetItemState(row+1, 3, grid->GetItemState(row+1, 3) | GVIS_READONLY);

					}
				}
				else
				{
					if (tournoi->matches[t - 1][(row - 1) / 2]->num2 == 0)
					{				
					grid->SetItemState(row, 3, grid->GetItemState(row, 3) | GVIS_READONLY);
					if (t <= tournoi->nbtours)		// tour normal => verrouiller les 2 scores
						grid->SetItemState(row-1, 3, grid->GetItemState(row-1, 3) | GVIS_READONLY);
					}
				}
			}
		}
	}


	// Resize automatiquement les cases en fonction de leur contenu !
	// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
	grid->AutoSize();	

	int widthParties= grid->GetColumnWidth(0);
	int widthEquipes= (grid->GetColumnWidth(1) * 3) / 2;
	int widthNumeros= grid->GetColumnWidth(2);
	int widthScores= grid->GetColumnWidth(3);

	// Resize manuel des colonnes
	grid->SetColumnWidth(0, max(widthParties, 70));
	grid->SetColumnWidth(1, max(widthEquipes, 220));
	grid->SetColumnWidth(2, max(widthNumeros, 71));
	grid->SetColumnWidth(3, max(widthScores, 70));
}


void Dump_Grid_Scores(CGridCtrl * grid, int t)
{
	CString num1, num2, sco1, sco2;
	unsigned n1 = 0, n2 = 0;

	if (tournoi == NULL) return;

	for (int row = 1; row < grid->GetRowCount(); row++)
	{
		if (row % 2)	// traiter les lignes 2 par 2
		{
			num1 = grid->GetItemText(row, 2);
			sco1 = grid->GetItemText(row, 3);
			num2 = grid->GetItemText(row + 1, 2);
			sco2 = grid->GetItemText(row + 1, 3);

			n1 = atoi(num1);
			n2 = atoi(num2);

			if (t == tournoi->nbtours + 1)		// tour complementaire
			{
				if ((n1 != 0) || (n2 != 0))			// enregistrer les matches saisis
				{
					tournoi->matches[t - 1][row / 2]->num1 = n1;
					tournoi->matches[t - 1][row / 2]->num2 = n2;
				}
			}

			// si n1 et n2 sont non nuls, ces 2 instructions sont a priori �quivalentes !
			if (n1 != 0)
				tournoi->setscore(t, n1, atoi(sco1), atoi(sco2));
			if (n2 != 0)
				tournoi->setscore(t, n2, atoi(sco2), atoi(sco1));
		}
	}
}


/*
Classe CBilanDlg
*/

CBilanDlg::CBilanDlg(int resId, CWnd *parent) : CDialog(resId, parent)
{
	ParentWnd = (CMainWindow *)parent;

	// recuperation du Grid pour DoDataExchange()
	Grid_Bilan = new CGridCtrl;
	((CMainWindow *) parent)->Grid_Bilanptr = Grid_Bilan;
}

CBilanDlg::~CBilanDlg()
{
}

BOOL CBilanDlg::OnInitDialog()
{
	// appelle methode de base qui appelle DoDataExchange() via UpdateData()
	CDialog::OnInitDialog();

	// raz de la grille
	Reset_grid_texts(Grid_Bilan);

	Grid_Bilan->SetBkColor(::GetSysColor(COLOR_3DFACE));

	// remplissage de la grille a partir des equipes du tournoi
	Fill_Grid_Bilan(Grid_Bilan);

	Grid_Bilan->SetFocusCell(0, 0);

	CRect rect;
	Grid_Bilan->GetWindowRect(&rect);		// dimensions de la grille

	rect.InflateRect(0, 0, 50, 120);
	this->MoveWindow(rect);			// dimensionnement de la boite en fonction de la grille

	Grid_Bilan->Invalidate();		// force rafraichissement

	return TRUE;
}

// methode appelee lors du clic sur Appliquer
void CBilanDlg::OnApply()
{
	
}

// methode appelee lors de la sortie par OK ou CR
void CBilanDlg::OnOK()
{
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDOK);
}

// methode appelee lors de la sortie par CANCEL ou ESC
// attention car par defaut ESC ferme la boite et entraine la perte des donnees !
void CBilanDlg::OnCancel()
{	
	EndDialog(IDCANCEL);	
}


// methode appelee � l'ouverture et lors de la fermeture de la boite par OK
void CBilanDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx); // Appel de la methode de base

								  // champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{
		// il est apparemment trop tard a ce stade pour modifier la grille !
	}

	DDX_GridControl(ddx, IDG_BILAN_GRID, *Grid_Bilan);
}


BEGIN_MESSAGE_MAP(CBilanDlg, CDialog)
	
END_MESSAGE_MAP()


/*
Gestion de la grille Bilan
*/

void Fill_Grid_Bilan(CGridCtrl * grid)
{
	int col1, col2, col3;

	if (tournoi == NULL) return;

	// parametres generaux
	grid->SetEditable(FALSE);
	grid->EnableDragAndDrop(FALSE);
	grid->SetColumnResize(FALSE);
	grid->SetRowResize(FALSE);

	if (tournoi->mode == 'M')
	{
		grid->SetRowCount(tournoi->nbplayers + 1);
		grid->SetColumnCount(6 + 2 * tournoi->nbtours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);
		
		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Nom"));
		grid->SetItem(&Item);

		col1 = 2;
		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;
		for (int col = col2; col < col2 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;
		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		for (int row = 1; row < grid->GetRowCount(); row++)
		{
			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, 
				_T("%d"), tournoi->personnes[row]->numero);
			grid->SetItem(&Item);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T(tournoi->personnes[row]->nom));
			grid->SetItem(&Item);

			col1 = 1;
			for (int t = 1; t <= tournoi->nbtours; t++)
			{				
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
				}
				else
				{
					if (tournoi->personnes[row]->points[t-1] != -1)
					{
						MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, 
							_T("%d"), tournoi->personnes[row]->points[t-1]);
						grid->SetItem(&Item);
						total += tournoi->personnes[row]->points[t-1];
						parties++;
						if (tournoi->personnes[row]->points[t-1] > tournoi->personnes[row]->contre[t-1]) gagnees++;
					}
					else
					{
						MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
						grid->SetItem(&Item);
					}
				}				
			}

			col2 = col1 + tournoi->nbtours;
			for (int t = 1; t <= tournoi->nbtours; t++)
			{				
				if (!tournoi->done[t-1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
				}
				else
				{
					if (tournoi->personnes[row]->points[t-1] != -1)
					{
						MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, 
							_T("%d"), -tournoi->personnes[row]->contre[t-1]);
						grid->SetItem(&Item);
						perdu += tournoi->personnes[row]->contre[t-1];
					}
					else
					{
						MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
						grid->SetItem(&Item);
					}
				}				
			}

			col3 = col2 + tournoi->nbtours + 1;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthJoueur= grid->GetColumnWidth(1) * 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tournoi->nbtours + 2);
		int widthContre= grid->GetColumnWidth(2 * tournoi->nbtours + 3);
		int widthParties= grid->GetColumnWidth(2 * tournoi->nbtours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tournoi->nbtours + 5);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthJoueur, 100));
		for (int t = 1; t <= tournoi->nbtours; t++)
		{
			grid->SetColumnWidth(1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(tournoi->nbtours + 1 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tournoi->nbtours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 5, max(widthGagnees, 50));	
	}

	if (tournoi->mode == 'F')
	{
		unsigned tours= tournoi->nbtours;
		if (tournoi->nbteams % 2) tours++;

		grid->SetRowCount(tournoi->nbteams + 1);
		grid->SetColumnCount(6 + 2 * tours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Noms"));
		grid->SetItem(&Item);

		col1 = 2;

		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;

		if (tournoi->nbteams % 2)
		{
			MAKE_ITEM(0, col2, DT_CENTER | DT_WORDBREAK, _T("T C"));
			grid->SetItem(&Item);
			col2++;
		}

		for (int col = col2 ; col < col2 + tournoi->nbtours ; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;

		if (tournoi->nbteams % 2)
		{
			MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("T C"));
			grid->SetItem(&Item);
			col3++;
		}

		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		for (int row = 1 ; row < grid->GetRowCount() ; row++)
		{
			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%d"), tournoi->liste[row]->numero);
			grid->SetItem(&Item);

			char stg[200];
			strcpy(stg, tournoi->liste[row]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[row]->joueurs[1]);
			if (strcmp(tournoi->liste[row]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[row]->joueurs[2]);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T(stg));
			grid->SetItem(&Item);

			col1 = 1;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				int comp = 0;

				if (!tournoi->done[t-1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < (tournoi->nbteams + 1) / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t-1][j] == NULL)
					{
						if (t < tournoi->nbtours)
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						continue;
					}

					if (tournoi->matches[t-1][j]->num1 == row)
					{
						s1 = tournoi->matches[t-1][j]->score1;
						s2 = tournoi->matches[t-1][j]->score2;
					}

					if (tournoi->matches[t-1][j]->num2 == row)
					{
						s1 = tournoi->matches[t-1][j]->score2;
						s2 = tournoi->matches[t-1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s1 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), s1);
							grid->SetItem(&Item);
						}

						total += s1;
						if (s1 + s2 > 0) parties++;
						if (s1 > s2) gagnees++;
						comp = 1;
					}
				}

				if ((t == tournoi->nbtours) && (comp == 0))		// equipe sans tour complementaire
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
					grid->SetItem(&Item);
				}
			}

			col2 = col1 + tournoi->nbtours;
			if (tournoi->nbteams % 2) col2++;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				int comp = 0;

				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < (tournoi->nbteams + 1) / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
					{
						if (t < tournoi->nbtours)
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						continue;
					}

					if (tournoi->matches[t - 1][j]->num1 == row)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == row)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s2 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), -s2);
							grid->SetItem(&Item);
						}

						perdu += s2;
						comp = 1;
					}
				}

				if ((t == tournoi->nbtours) && (comp == 0))		// equipe sans tour complementaire
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
					grid->SetItem(&Item);
				}				
			}

			col3 = col2 + tournoi->nbtours + 1;
			if (tournoi->nbteams % 2) col3++;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthEquipes= (grid->GetColumnWidth(1) * 3) / 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tours + 2);
		int widthContre= grid->GetColumnWidth(2 * tours + 3);
		int widthParties= grid->GetColumnWidth(2 * tours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tours + 5);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthEquipes, 200));
		for (int t = 1; t <= tours; t++)
		{
			grid->SetColumnWidth(col1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(col2 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tours + 5, max(widthGagnees, 50));
	}

	if (tournoi->mode == 'E')
	{
		unsigned tours= tournoi->nbtours;
		
		grid->SetRowCount(tournoi->nbteams + 1);
		grid->SetColumnCount(6 + 2 * tours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Noms"));
		grid->SetItem(&Item);

		col1 = 2;

		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;

		for (int col = col2 ; col < col2 + tournoi->nbtours ; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;

		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		for (int row = 1 ; row < grid->GetRowCount() ; row++)
		{
			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%d"), tournoi->liste[row]->numero);
			grid->SetItem(&Item);

			char stg[200];
			strcpy(stg, tournoi->liste[row]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[row]->joueurs[1]);
			if (strcmp(tournoi->liste[row]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[row]->joueurs[2]);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T(stg));
			grid->SetItem(&Item);

			col1 = 1;

			for (int t = 1; t <= tournoi->nbtours; t++)
			{
				if (!tournoi->done[t-1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < tournoi->nbteams / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t-1][j] == NULL)
						continue;

					if (tournoi->matches[t-1][j]->num1 == row)
					{
						s1 = tournoi->matches[t-1][j]->score1;
						s2 = tournoi->matches[t-1][j]->score2;
					}

					if (tournoi->matches[t-1][j]->num2 == row)
					{
						s1 = tournoi->matches[t-1][j]->score2;
						s2 = tournoi->matches[t-1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s1 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), s1);
							grid->SetItem(&Item);
						}

						total += s1;
						if (s1 + s2 > 0) parties++;
						if (s1 > s2) gagnees++;			
					}
				}
			}

			col2 = col1 + tournoi->nbtours;

			for (int t = 1; t <= tournoi->nbtours; t++)
			{
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < tournoi->nbteams / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
						continue;

					if (tournoi->matches[t - 1][j]->num1 == row)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == row)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s2 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), -s2);
							grid->SetItem(&Item);
						}

						perdu += s2;
					}
				}
			}

			col3 = col2 + tournoi->nbtours + 1;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthEquipes= (grid->GetColumnWidth(1) * 3) / 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tours + 2);
		int widthContre= grid->GetColumnWidth(2 * tours + 3);
		int widthParties= grid->GetColumnWidth(2 * tours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tours + 5);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthEquipes, 200));
		for (int t = 1; t <= tours; t++)
		{
			grid->SetColumnWidth(col1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(col2 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tours + 5, max(widthGagnees, 50));
	}
}


/*
Classe CClassementDlg
*/

CClassementDlg::CClassementDlg(int resId, CWnd *parent) : CDialog(resId, parent)
{
	ParentWnd = (CMainWindow *)parent;

	// recuperation du Grid pour DoDataExchange()
	Grid_Classement = new CGridCtrl;
	((CMainWindow *) parent)->Grid_Bilanptr = Grid_Classement;
}

CClassementDlg::~CClassementDlg()
{
}

BOOL CClassementDlg::OnInitDialog()
{
	// appelle methode de base qui appelle DoDataExchange() via UpdateData()
	CDialog::OnInitDialog();

	SetWindowText(_T("Classement actuel du tournoi"));

	// raz de la grille
	Reset_grid_texts(Grid_Classement);

	Grid_Classement->SetBkColor(::GetSysColor(COLOR_3DFACE));

	// remplissage de la grille a partir des equipes du tournoi
	Fill_Grid_Classement(Grid_Classement);

	Grid_Classement->SetFocusCell(0, 0);

	CRect rect;
	Grid_Classement->GetWindowRect(&rect);		// dimensions de la grille

	rect.InflateRect(0, 0, 50, 120);
	this->MoveWindow(rect);			// dimensionnement de la boite en fonction de la grille

	Grid_Classement->Invalidate();		// force rafraichissement

	return TRUE;
}

// methode appelee lors du clic sur Appliquer
void CClassementDlg::OnApply()
{

}

// methode appelee lors de la sortie par OK ou CR
void CClassementDlg::OnOK()
{
	// entraine appel de DoDataExchange() en sortie
	UpdateData(TRUE);

	EndDialog(IDOK);
}

// methode appelee lors de la sortie par CANCEL ou ESC
// attention car par defaut ESC ferme la boite et entraine la perte des donnees !
void CClassementDlg::OnCancel()
{
	EndDialog(IDCANCEL);
}


// methode appelee � l'ouverture et lors de la fermeture de la boite par OK
void CClassementDlg::DoDataExchange(CDataExchange* ddx)
{
	CDialog::DoDataExchange(ddx); // Appel de la methode de base

								  // champ FALSE en entr�e
	if (ddx->m_bSaveAndValidate == FALSE)
	{
		// il est apparemment trop tard a ce stade pour modifier la grille !
	}

	DDX_GridControl(ddx, IDG_BILAN_GRID, *Grid_Classement);
}


BEGIN_MESSAGE_MAP(CClassementDlg, CDialog)

END_MESSAGE_MAP()


/*
Gestion de la grille Classement
*/

void Fill_Grid_Classement(CGridCtrl * grid)
{
	int col1, col2, col3;
	unsigned rang, oldrang, oldgagnees, oldtotal, oldperdu;

	if (tournoi == NULL) return;

	// parametres generaux
	grid->SetEditable(FALSE);
	grid->EnableDragAndDrop(FALSE);
	grid->SetColumnResize(FALSE);
	grid->SetRowResize(FALSE);

	if (tournoi->mode == 'M')
	{
		grid->SetRowCount(tournoi->nbplayers + 1);
		grid->SetColumnCount(7 + 2 * tournoi->nbtours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Nom"));
		grid->SetItem(&Item);

		col1 = 2;
		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;
		for (int col = col2; col < col2 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;
		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 4, DT_CENTER | DT_WORDBREAK, _T("RANG"));
		grid->SetItem(&Item);

		// initialisation du moteur de classement
		tournoi->getnext_classement_melee(true);

		oldrang= 1;	oldgagnees= 0; oldtotal= 0; oldperdu= 0;

		for (int row = 1; row < grid->GetRowCount(); row++)
		{
			// recherche du meilleur joueur non encore class�
			int next= tournoi->getnext_classement_melee();

			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%d"), tournoi->personnes[next]->numero);
			grid->SetItem(&Item);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T(tournoi->personnes[next]->nom));
			grid->SetItem(&Item);

			// recalcul et affichage des scores
			col1 = 1;

			for (int t = 1; t <= tournoi->nbtours; t++)
			{
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
				}
				else
				{
					if (tournoi->personnes[next]->points[t - 1] != -1)
					{
						MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
							_T("%d"), tournoi->personnes[next]->points[t - 1]);
						grid->SetItem(&Item);
						total += tournoi->personnes[next]->points[t - 1];
						parties++;
						if (tournoi->personnes[next]->points[t - 1] > tournoi->personnes[next]->contre[t - 1]) gagnees++;
					}
					else
					{
						MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
						grid->SetItem(&Item);
					}
				}
			}

			col2 = col1 + tournoi->nbtours;

			for (int t = 1; t <= tournoi->nbtours; t++)
			{
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
				}
				else
				{
					if (tournoi->personnes[next]->points[t - 1] != -1)
					{
						MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
							_T("%d"), -tournoi->personnes[next]->contre[t - 1]);
						grid->SetItem(&Item);
						perdu += tournoi->personnes[next]->contre[t - 1];
					}
					else
					{
						MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
						grid->SetItem(&Item);
					}
				}
			}

			col3 = col2 + tournoi->nbtours + 1;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);

			unsigned rang= row;
			if ((oldgagnees == gagnees) && (oldtotal == total) && (oldperdu == perdu))	// ex-aequo
				rang= oldrang;
			
			MAKE_ITEM_EX(row, col3 + 4, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), rang);
			grid->SetItem(&Item);

			oldgagnees= gagnees;
			oldtotal= total;
			oldperdu= perdu;
			oldrang= rang;
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthJoueur= grid->GetColumnWidth(1) * 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tournoi->nbtours + 2);
		int widthContre= grid->GetColumnWidth(2 * tournoi->nbtours + 3);
		int widthParties= grid->GetColumnWidth(2 * tournoi->nbtours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tournoi->nbtours + 5);
		int widthRang= grid->GetColumnWidth(2 * tournoi->nbtours + 6);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthJoueur, 100));
		for (int t = 1; t <= tournoi->nbtours; t++)
		{
			grid->SetColumnWidth(1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(tournoi->nbtours + 1 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tournoi->nbtours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 5, max(widthGagnees, 50));
		grid->SetColumnWidth(2 * tournoi->nbtours + 6, max(widthRang, 40));		
	}

	if (tournoi->mode == 'F')
	{
		unsigned tours= tournoi->nbtours;
		if (tournoi->nbteams % 2) tours++;

		grid->SetRowCount(tournoi->nbteams + 1);
		grid->SetColumnCount(7 + 2 * tours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Noms"));
		grid->SetItem(&Item);

		col1 = 2;

		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;

		if (tournoi->nbteams % 2)
		{
			MAKE_ITEM(0, col2, DT_CENTER | DT_WORDBREAK, _T("T C"));
			grid->SetItem(&Item);
			col2++;
		}

		for (int col = col2; col < col2 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;

		if (tournoi->nbteams % 2)
		{
			MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("T C"));
			grid->SetItem(&Item);
			col3++;
		}

		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 4, DT_CENTER | DT_WORDBREAK, _T("RANG"));
		grid->SetItem(&Item);

		// initialisation du moteur de classement
		tournoi->getnext_classement_forme(true);

		oldrang= 1;	oldgagnees= 0; oldtotal= 0; oldperdu= 0;

		for (int row = 1; row < grid->GetRowCount(); row++)
		{			
			// recherche de la meilleure equipe non encore class�e
			int next= tournoi->getnext_classement_forme();

			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%d"), tournoi->liste[next]->numero);
			grid->SetItem(&Item);

			char stg[200];
			strcpy(stg, tournoi->liste[next]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[next]->joueurs[1]);
			if (strcmp(tournoi->liste[next]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[next]->joueurs[2]);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T(stg));
			grid->SetItem(&Item);

			// recalcul et affichage des scores
			col1 = 1;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				int comp = 0;

				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}
				
				for (int j = 0; j < (tournoi->nbteams + 1) / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
					{
						if (t < tournoi->nbtours)
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						continue;
					}

					if (tournoi->matches[t - 1][j]->num1 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s1 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), s1);
							grid->SetItem(&Item);
						}

						total += s1;
						if (s1 + s2 > 0) parties++;
						if (s1 > s2) gagnees++;
						comp = 1;
					}
				}

				if ((t == tournoi->nbtours) && (comp == 0))		// equipe sans tour complementaire
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
					grid->SetItem(&Item);
				}
			}

			col2 = col1 + tournoi->nbtours;
			if (tournoi->nbteams % 2) col2++;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				int comp = 0;

				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < (tournoi->nbteams + 1) / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
					{
						if (t < tournoi->nbtours)
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						continue;
					}

					if (tournoi->matches[t - 1][j]->num1 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s2 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), -s2);
							grid->SetItem(&Item);
						}

						perdu += s2;
						comp = 1;
					}
				}

				if ((t == tournoi->nbtours) && (comp == 0))		// equipe sans tour complementaire
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
					grid->SetItem(&Item);
				}
			}

			col3 = col2 + tournoi->nbtours + 1;
			if (tournoi->nbteams % 2) col3++;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);

			unsigned rang= row;
			if ((oldgagnees == gagnees) && (oldtotal == total) && (oldperdu == perdu))	// ex-aequo
				rang= oldrang;

			MAKE_ITEM_EX(row, col3 + 4, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), rang);
			grid->SetItem(&Item);

			oldgagnees= gagnees;
			oldtotal= total;
			oldperdu= perdu;
			oldrang= rang;
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthEquipes= (grid->GetColumnWidth(1) * 3) / 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tours + 2);
		int widthContre= grid->GetColumnWidth(2 * tours + 3);
		int widthParties= grid->GetColumnWidth(2 * tours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tours + 5);
		int widthRang= grid->GetColumnWidth(2 * tours + 6);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthEquipes, 200));
		for (int t = 1; t <= tours; t++)
		{
			grid->SetColumnWidth(col1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(col2 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tours + 5, max(widthGagnees, 50));
		grid->SetColumnWidth(2 * tours + 6, max(widthRang, 40));		
	}

	if (tournoi->mode == 'E')
	{
		unsigned tours= tournoi->nbtours;

		grid->SetRowCount(tournoi->nbteams + 1);
		grid->SetColumnCount(7 + 2 * tours);
		grid->SetFixedRowCount(1);
		grid->SetFixedColumnCount(2);

		grid->ShowScrollBar(SB_VERT, FALSE);
		grid->ShowScrollBar(SB_HORZ, TRUE);

		// remplissage de la grille
		// la numerotation des lignes / colonnes commence � 0

		GV_ITEM Item;
		Item.mask = GVIF_TEXT | GVIF_FORMAT;

		MAKE_ITEM(0, 0, DT_CENTER | DT_WORDBREAK, _T("N�"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, 1, DT_CENTER | DT_WORDBREAK, _T("Noms"));
		grid->SetItem(&Item);

		col1 = 2;

		for (int col = col1; col < col1 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col1 + 1);
			grid->SetItem(&Item);
		}

		col2 = col1 + tournoi->nbtours;

		for (int col = col2; col < col2 + tournoi->nbtours; col++)
		{
			MAKE_ITEM_EX(0, col, DT_CENTER | DT_WORDBREAK, _T("T %d"), Item.col - col2 + 1);
			grid->SetItem(&Item);
		}

		col3 = col2 + tournoi->nbtours;

		MAKE_ITEM(0, col3, DT_CENTER | DT_WORDBREAK, _T("Total"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 1, DT_CENTER | DT_WORDBREAK, _T("Contre"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 2, DT_CENTER | DT_WORDBREAK, _T("Parties"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 3, DT_CENTER | DT_WORDBREAK, _T("Gagn�es"));
		grid->SetItem(&Item);

		MAKE_ITEM(0, col3 + 4, DT_CENTER | DT_WORDBREAK, _T("RANG"));
		grid->SetItem(&Item);

		// initialisation du moteur de classement
		tournoi->getnext_classement_forme(true);

		oldrang= 1;	oldgagnees= 0; oldtotal= 0; oldperdu= 0;

		for (int row = 1; row < grid->GetRowCount(); row++)
		{			
			// recherche de la meilleure equipe non encore class�e
			int next= tournoi->getnext_classement_forme();

			unsigned total = 0, perdu = 0, parties = 0, gagnees = 0;

			MAKE_ITEM_EX(row, 0, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
				_T("%d"), tournoi->liste[next]->numero);
			grid->SetItem(&Item);

			char stg[200];
			strcpy(stg, tournoi->liste[next]->joueurs[0]); strcat(stg, "_");
			strcat(stg, tournoi->liste[next]->joueurs[1]);
			if (strcmp(tournoi->liste[next]->joueurs[2], "") != 0) strcat(stg, "_");
			strcat(stg, tournoi->liste[next]->joueurs[2]);

			MAKE_ITEM(row, 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T(stg));
			grid->SetItem(&Item);

			// recalcul et affichage des scores
			col1 = 1;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}
				
				for (int j = 0; j < tournoi->nbteams / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
						continue;

					if (tournoi->matches[t - 1][j]->num1 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s1 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col1 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), s1);
							grid->SetItem(&Item);
						}

						total += s1;
						if (s1 + s2 > 0) parties++;
						if (s1 > s2) gagnees++;
					}
				}
			}

			col2 = col1 + tournoi->nbtours;

			for (int t = 1; t <= tournoi->nbtours + 1; t++)
			{
				if (!tournoi->done[t - 1])
				{
					MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("-"));
					grid->SetItem(&Item);
					continue;
				}

				for (int j = 0; j < tournoi->nbteams / 2; j++)
				{
					int s1 = -1, s2 = -1;

					if (tournoi->matches[t - 1][j] == NULL)
						continue;

					if (tournoi->matches[t - 1][j]->num1 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score1;
						s2 = tournoi->matches[t - 1][j]->score2;
					}

					if (tournoi->matches[t - 1][j]->num2 == next)
					{
						s1 = tournoi->matches[t - 1][j]->score2;
						s2 = tournoi->matches[t - 1][j]->score1;
					}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s2 >= 0)
					{
						if ((s1 == 0) && (s2 == 0))
						{
							MAKE_ITEM(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("#"));
							grid->SetItem(&Item);
						}
						else
						{
							MAKE_ITEM_EX(row, col2 + t, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX,
								_T("%d"), -s2);
							grid->SetItem(&Item);
						}

						perdu += s2;
					}
				}
			}

			col3 = col2 + tournoi->nbtours + 1;

			MAKE_ITEM_EX(row, col3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), total);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 1, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%d"), -perdu);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 2, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), parties);
			grid->SetItem(&Item);

			MAKE_ITEM_EX(row, col3 + 3, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), gagnees);
			grid->SetItem(&Item);

			unsigned rang= row;
			if ((oldgagnees == gagnees) && (oldtotal == total) && (oldperdu == perdu))	// ex-aequo
				rang= oldrang;

			MAKE_ITEM_EX(row, col3 + 4, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_END_ELLIPSIS | DT_NOPREFIX, _T("%u"), rang);
			grid->SetItem(&Item);

			oldgagnees= gagnees;
			oldtotal= total;
			oldperdu= perdu;
			oldrang= rang;
		}

		// Resize automatiquement les cases en fonction de leur contenu !
		// Utile sous Windows 11 qui g�re les boites de dialogue a sa sauce
		grid->AutoSize();	

		int widthNumeros= grid->GetColumnWidth(0);
		int widthEquipes= (grid->GetColumnWidth(1) * 3) / 2;
		int widthTours= grid->GetColumnWidth(3);
		int widthTotal= grid->GetColumnWidth(2 * tours + 2);
		int widthContre= grid->GetColumnWidth(2 * tours + 3);
		int widthParties= grid->GetColumnWidth(2 * tours + 4);
		int widthGagnees= grid->GetColumnWidth(2 * tours + 5);
		int widthRang= grid->GetColumnWidth(2 * tours + 6);

		// Resize manuel des colonnes
		grid->SetColumnWidth(0, max(widthNumeros, 31));
		grid->SetColumnWidth(1, max(widthEquipes, 200));
		for (int t = 1; t <= tours; t++)
		{
			grid->SetColumnWidth(col1 + t, max(widthTours, 40));	
			grid->SetColumnWidth(col2 + t, max(widthTours, 40));
		}
		grid->SetColumnWidth(2 * tours + 2, max(widthTotal, 50));
		grid->SetColumnWidth(2 * tours + 3, max(widthContre, 50));
		grid->SetColumnWidth(2 * tours + 4, max(widthParties, 50));
		grid->SetColumnWidth(2 * tours + 5, max(widthGagnees, 50));
		grid->SetColumnWidth(2 * tours + 6, max(widthRang, 40));		
	}

}

