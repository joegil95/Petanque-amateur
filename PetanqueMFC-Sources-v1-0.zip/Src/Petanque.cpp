/*
@(#) JG 2026

A compiler en VC++

Attention: d�sactiver unicode pour les noms de fichiers
*/

#include <windows.h>

#include <tchar.h>

#include "Petanque.h"

Joueur::Joueur()
	{
	numero= 0;
	strcpy(nom, "");
	strcpy(obs, "");
	points= NULL;
	contre= NULL;
	}

Joueur::Joueur(unsigned num, unsigned nbtrs)
	{
	numero= num;
	strcpy(nom, "");
	strcpy(obs, "");
	points= new int[nbtrs+1];
	contre= new int[nbtrs+1];

	for (int i= 0 ; i <= nbtrs ; i++)
		{ 	
		points[i]= -1;		// partie non jouee
		contre[i]= -1;
		}
	}

void Joueur::saisir(unsigned n)
	{
	numero= n;
	cout << "J " << n <<": "; gets(nom);

	/// remplacer les espaces a cause de sscanf() ulterieurs
	// remplacer les - a cause des separataurs par defaut
	for (int i= 0 ; i < strlen(nom); i++)
		{
		if (nom[i] == ' ') nom[i]= '-';
		if (nom[i] == '_') nom[i]= '-';
		}

	afficher(true);
	}

void Joueur::definir(unsigned n, char * joueur, char * nota)
	{
	numero= n;
	strcpy(nom, joueur);
	strcpy(obs, nota);

	// remplacer les espaces a cause de sscanf() ulterieurs
	// remplacer les - a cause des separataurs par defaut
	for (int i= 0 ; i < strlen(nom); i++)
		{
		if (nom[i] == ' ') nom[i]= '-';
		if (nom[i] == '_') nom[i]= '-';
		}
	}

void Joueur::afficher(bool lf= false)
	{
	cout << "J " << numero << " (";
	cout << nom;
	cout << ")";
	if (lf) cout << endl;
	}

Joueur::~Joueur()
	{
	delete [] points;
	delete [] contre;
	}

Equipe::Equipe()
	{
	numero= 0;
	for (int i= 0 ; i < 3 ; i++)
		strcpy(joueurs[i], "");
	elimin= false;
	}

Equipe::Equipe(unsigned num)
	{
	numero= num;
	for (int i= 0 ; i < 3 ; i++)
		strcpy(joueurs[i], "");
	elimin= false;
	}

void Equipe::saisir(unsigned n)
	{
	numero= n;

	for (int i= 0 ; i < 3 ; i++)
		{
		cout << "J " << i+1 <<": "; gets(joueurs[i]);

		// remplacer les espaces a cause de sscanf() ulterieurs
		// remplacer les _ a cause des separateurs par defaut
		for (int j= 0 ; j < strlen(joueurs[i]); j++)
			{
			if (joueurs[i][j] == ' ') joueurs[i][j]= '-';
			if (joueurs[i][j] == '_') joueurs[i][j]= '-';
			}
		}

	afficher(true, true);
	}

void Equipe::definir(unsigned n, char * joueur1, char * joueur2, char * joueur3)
	{
	numero= n;

	if (joueur1) strcpy(joueurs[0], joueur1);
	if (joueur2) strcpy(joueurs[1], joueur2);
	if (joueur3) strcpy(joueurs[2], joueur3);

	// remplacer les espaces a cause de sscanf() ulterieurs
	// remplacer les _ a cause des separateurs par defaut
	for (int j= 0 ; j < strlen(joueur1); j++)
		{
		if (joueurs[0][j] == ' ') joueurs[0][j]= '-';
		if (joueurs[0][j] == '_') joueurs[0][j]= '-';
		}
	for (int j= 0 ; j < strlen(joueur2); j++)
		{
		if (joueurs[1][j] == ' ') joueurs[1][j]= '-';
		if (joueurs[1][j] == '_') joueurs[1][j]= '-';
		}
	for (int j= 0 ; j < strlen(joueur3); j++)
		{
		if (joueurs[2][j] == ' ') joueurs[2][j]= '-';
		if (joueurs[2][j] == '_') joueurs[2][j]= '-';
		}
	}

void Equipe::definir(unsigned n,  char * jjj)		/// 2 ou 3 joueurs separes par des _
	{
	char stg[200]= "";
	char * usptr1, * usptr2;

	numero= n;
	strcpy(joueurs[0], "");
	strcpy(joueurs[1], "");
	strcpy(joueurs[2], "");

	if (joueurs == NULL) return;

	strcpy(stg, jjj);
	usptr1= strchr(stg, '_');
	if (usptr1 != NULL) *usptr1= 0;
	strcpy(joueurs[0], stg);

	usptr2= strchr(usptr1+1, '_');
	if (usptr2 != NULL) *usptr2= 0;
	if (usptr1 != NULL) strcpy(joueurs[1], usptr1+1);

	if (usptr2 != NULL)strcpy(joueurs[2], usptr2+1);
	}

void Equipe::afficher(bool shownum, bool lf)
	{
	if (shownum) cout << "Equ " << numero << " ";

	cout << "(";
	for (int i= 0 ; i < 3 ; i++)
		{
		cout << joueurs[i];
		if ((i < 2) && (strcmp(joueurs[i+1], "") != 0)) cout << "_";
		}
	cout << ")";
	if (lf) cout << endl;
	}


Partie::Partie()
	{
	tournoi= NULL;
	
	num1= 0;
	num2= 0;
	score1= 0;
	score2= 0;
	}

Partie::Partie(Petanque * tnoi, unsigned n1, unsigned n2)
	{
	tournoi= tnoi;
	
	num1= n1;
	num2= n2;
	score1= 0;
	score2= 0;
	}

void Partie::show()
	{
	tournoi->liste[num1]->afficher(true, false);
	cout << " vs " ;
	tournoi->liste[num2]->afficher(true, false);
	
	cout << " = (" << score1 << " , " << score2 << ")" << endl;
	}


/*
bool operator==(Partie const & m1, Partie const & m2)		// surcharge operateur == entre matches
	{
	if ((m1.num1 == m2.num1) && (m1.num2 == m2.num2)) return true;	
	if ((m1.num1 == m2.num2) && (m1.num2 == m2.num1)) return true;	

	return false;
	}
*/


// jeu eliminatoire
Petanque::Petanque(unsigned nbtrs)
	{
	mode= 'E';
	pref= ' ';			// inutilise dans ce cas
	nbtours= nbtrs;
	nbteams= power2(nbtrs);
	nbplayers= 0;			// inutilise dans ce cas

	personnes= NULL;	// inutilise dans ce cas car equipes fixes

	liste= new Equipeptr[nbteams+1];		// equipe 0 inutilisee
	for (int i= 0 ; i < nbteams+1 ; i++)
		liste[i]= new Equipe(i);

	matches= new Partieptr * [nbtours+1];		// pas de tour complementaire dans ce cas mais gare au destructeur !
	for (int j= 0 ; j <= nbtours ; j++)
		{
		matches[j]= new Partieptr[(nbteams+1)/2];
		for (int k= 0 ; k < (nbteams+1)/2 ; k++)
			matches[j][k]= NULL;			// creer les partie necessaires lors du tirage
		}

	done= new bool[nbtours+1];	// tirages faits ?
	for (int j= 0 ; j <= nbtours ; j++)
		done[j]= false;
	}

// jeu en equipes formees
Petanque::Petanque(unsigned nbtrs, unsigned nbtms)
	{
	mode= 'F';
	pref= ' ';			// inutilise dans ce cas
	nbtours= nbtrs;
	nbteams= nbtms;
	nbplayers= 0;		// inutilise dans ce cas

	personnes= NULL;	// inutilise dans ce cas car equipes fixes

	liste= new Equipeptr[nbteams+1];		// equipe 0 inutilisee
	for (int i= 0 ; i < nbteams+1 ; i++)
		liste[i]= new Equipe(i);

	matches= new Partieptr * [nbtours+1];		// prevoir tour complementaire si besoin
	for (int j= 0 ; j <= nbtours ; j++)
		{
		matches[j]= new Partieptr[(nbteams+1)/2];
		for (int k= 0 ; k < (nbteams+1)/2 ; k++)
			matches[j][k]= NULL;			// creer les partie lors du tirage
		}

	done= new bool[nbtours+1];	// tirages faits ?
	for (int j= 0 ; j <= nbtours ; j++)
		done[j]= false;
	}

// jeu a la melee
Petanque::Petanque(unsigned nbtrs, unsigned nbtms, unsigned nbplys, char prefce)
	{
	mode= 'M';
	pref= prefce;
	nbtours= nbtrs;
	nbteams= nbtms;
	nbplayers= nbplys;

	personnes= new Joueurptr[nbplayers+1];		// joueur 0 inutilise
	for (int i= 0 ; i < nbplayers+1 ; i++)
		personnes[i]= new Joueur(i, nbtrs);

	liste= new Equipeptr[nbteams+1];		// equipe 0 inutilisee
	for (int i= 0 ; i < nbteams+1 ; i++)
		liste[i]= new Equipe(i);

	matches= new Partieptr * [nbtours+1];		// pas de tour complementaire dans ce cas mais gare au destructeur !
	for (int j= 0 ; j <= nbtours ; j++)
		{
		matches[j]= new Partieptr[(nbteams+1)/2];
		for (int k= 0 ; k < (nbteams+1)/2 ; k++)
			matches[j][k]= NULL;			// creer les partie lors du tirage ou de la restauration
		}

	done= new bool[nbtours+1];	// tirages faits ?
	for (int j= 0 ; j <= nbtours ; j++)
		done[j]= false;
	}

// destructeur commun
Petanque::~Petanque()
	{
	delete[] done;

	for (int j= 0 ; j <= nbtours ; j++)
		{
		for (int k= 0 ; k < (nbteams+1)/2 ; k++)
			if (matches[j][k] != NULL) delete matches[j][k];
		delete matches[j];
		}
	delete[] matches;

	for (int i= 0 ; i < nbteams+1 ; i++)
		delete liste[i];
	delete[] liste;

	if (personnes != NULL)			// parties a la melee
		{
		for (int i= 0 ; i < nbplayers+1 ; i++)
			delete personnes[i];
		delete[] personnes;
		}
	}

// constitution des equipes a la melee
void Petanque::melange()
	{
	int r, index= 0;
	unsigned j= 0, mem= 0, reste= 0;
	char tag= 'n';

	int * used= new int[nbplayers+1];
	for (int i= 0 ; i <= nbplayers ; i++)
		used[i]= 0;

	srand(time(NULL));

	index= nbteams;					// nb de doublettes de base
	reste= nbplayers - 2 * nbteams;		// nb de joueurs a repartir en triplettes
	
	for (int a= nbplayers ; a > reste ; a--)		// constitution des doublettes de base
		{
		int val= 0;

		r= rand() % a + 1;		// r= valeur entre 1 et a qui diminue

		for (j= 1 ; j <= nbplayers ; j++)	
			{
			if (! used[j]) val++;		// recherche la r ieme case non utilisee
			if (val == r) break;
			}
		used[j]= 1;
		
		if (mem != 0)		// attendre 2 choix de joueurs pour creer une equipe
			{
			liste[index]->definir(index, personnes[mem]->nom, personnes[j]->nom, "");
			index--;
			mem= 0;
			}
		else 		
			mem= j;
		}

	for (r= 1 ; r <= reste ; r++)
		{
		for (j= 1 ; j <= nbplayers ; j++)	
			{
			if (! used[j]) break;		// 1er joueur residuel
			}
		used[j]= 1;

		// triplettes ds equipes 1 a reste
		liste[r]->definir(r, liste[r]->joueurs[0], liste[r]->joueurs[1], personnes[j]->nom);
		}

	delete[] used;	
	}

// tirage des matches pour le tour t en mode forme ou melee
// si automatic= true, choix automatique de l'equipe passive si besoin
// retourne 0 si ok et < 0 si erreur
int Petanque::tirage(int t, bool automatic)
	{
	int r, passes= 0;
	unsigned j= 0, mem= 0, passive= 0;
	
	if (t > nbtours) return -1;

	if ((t > 1) && (! done[t-2])) 
		{
		cout << "Erreur de tour" << endl;

		return -1;
		}
	if (done[t-1])	// tirage deja fait => affichage
		{
		cout << "Attention, tirage " << t << " deja fait !" << endl;
		for (int k= 0 ; k <= (nbteams-1)/2 ; k++)
			matches[t-1][k]->show();

		return -2;
		}

	if (! automatic)
	if ((t > 1) && (nbteams % 2))
		{
		cout << endl;
		cout << "Equipes passives actuelles : ";
		for (int u= 1 ; u < t ; u++)
			{
			cout << matches[u-1][0]->num1 << " , ";
			}
		cout << endl;

		cout << "Voulez-vous choisir l'equipe passive de ce tour ?" << endl;
		cout << "De preference une equipe (perdante) qui a fini de jouer le tour precedent..." << endl;
		cout << "Entrez le numero de l'equipe et 0 sinon: ";
		scanf("%u", &passive);
		if (passive > nbteams) passive= 0;
		}

	do
		{
		passes= 0; j= 0 ; mem= 0;

		cout << ".";

		int * used= new int[nbteams+1];
		for (int i= 0 ; i <= nbteams ; i++)
			used[i]= 0;

		if ((nbteams % 2) && (passive != 0)) 
			{
			used[passive]= 1;		// equipe ecartee du tirage
			}

		if (t == 1) srand(time(NULL));

		for (int a= nbteams ; a > nbteams % 2  ; a--)
			{
			int val= 0;

			if (passive != 0) 
				r= rand() % (a-1) + 1;	// r= valeur entre 1 et a-1 qui diminue
			else
				r= rand() % a + 1;		// r= valeur entre 1 et a qui diminue

			for (j= 1 ; j <= nbteams ; j++)	
				{
				if (! used[j]) val++;		// recherche la r ieme case non utilisee
				if (val == r) break;
				}
			used[j]= 1;

			passes++;		
			if (passes % 2)			// toujours attendre 2 tirages pour creer une partie
				mem= j;
			else 
				{
				matches[t-1][a/2]= new Partie(this, j, mem);
				//	matches[t-1][a/2]->show();
				}
			}
	
		if (nbteams % 2)				// si nb d'equipes impair => 1 equipe ne joue pas 		
			{							// on l'associe � l'equipe 0 dans le match 0
			if (passive != 0) 
				{
				matches[t-1][0]= new Partie(this, passive, 0);		// l'equipe designee passive ne joue pas ce tour
				//	matches[t-1][0]->show();
				}
			else
				{
				for (j= 1 ; j <= nbteams  ; j++)
					{
					if (! used[j]) break;		// l'equipe j ne joue pas ce tour		
					}

				matches[t-1][0]= new Partie(this, j, 0);
				//	matches[t-1][0]->show();
				}
			}

		delete[] used;

		// verfier qu'un tirage n'existe pas deja dans un tour precedent sinon recommencer le tirage
		bool doublon= false;

		if (t > 1)
			{
			for (int u= 1 ; u < t ; u++)
				{
				for (int a= 0 ; a < (nbteams+1)/2 ; a++)
					{
					for (int b= 0 ; b < (nbteams+1)/2  ; b++)
						{
						if ((matches[t-1][a]->num1 == matches[u-1][b]->num1)	
							&& (matches[t-1][a]->num2 == matches[u-1][b]->num2))
							{
							doublon= true;
							break;
							}
						if ((matches[t-1][a]->num1 == matches[u-1][b]->num2)	
							&& (matches[t-1][a]->num2 == matches[u-1][b]->num1))
							{
							doublon= true;
							break;
							}
						}
					if (doublon) break;
					}

				if (doublon) break;
				}
			}

		if (doublon) 
			{
			done[t-1]= false;

			for (int a= 0 ; a < (nbteams+1)/2 ; a++)
				delete matches[t-1][a];
			}
		else done[t-1]= true;

		}
	while (! done[t-1]);

	return 0;	// OK
	}


// recuperation des equipes passives
// retourne la liste des equipes passives ayant un match de retard
// dans le tableau tab[] a fournir, de taille suffisante
// retourne le nb d'equipes trouvees
int Petanque::get_compteams(unsigned * tab)
	{
	int n= 0;

	if (nbteams % 2)			// n'a de sens que si nb d'equipes impair !
		{
		for (int u= 1 ; u <= nbtours ; u++)
			{
			if (matches[u-1][(nbteams-1)/2]->num2 == 0)
				{
				tab[u-1]= matches[u-1][(nbteams-1)/2]->num1;		// 1 equipe passive par tour (match en dernier dans la liste)
				n++;
				}
			}
		cout << endl;

		return n;
		}
	else
		{
		return 0;
		}
	}

// tirage tour complementaire si nb impair d'equipes formees
// retourne 0 si ok et < 0 si erreur
int Petanque::tirage_comp()			
	{
	if (nbteams % 2 == 0)
		{
		cout << "Erreur..." << endl;
		return -1;
		}

	if (! done[nbtours-1])		// tous les tirages normaux doivent etre deja faits
		{
		cout << "Erreur..." << endl;
		return -2;
		}

	if (done[nbtours])
		{
		cout << "Attention, tirage complementaire deja fait !" << endl;

		for (int k= 0 ; k < (nbtours+1)/2 ; k++)
			if (matches[nbtours][k] != NULL) matches[nbtours][k]->show();

		return -3;
		}

	cout << endl;
	cout << "Equipes passives ayant un match de retard : ";

	unsigned * tab= new unsigned[nbtours+1];
	int np= get_compteams(tab);
	for (int u= 0 ; u < np ; u++)
		{
		cout << tab[u] << " , ";		// 1 equipe passive par tour
		}
	cout << endl;

	int n1= 0, n2= 0;

	for (int k= 0 ; k < (nbtours+1)/2 ; k++)
		{
		cout << "Match complementaire " << k+1 << " :" << endl;

		do
			{
			// mettre n1 et n2 = 0 si plus de match a proposer
			// mettre n1 ou n2 = 0 pour match bidon concernant une equipe toute seule
			cout << "Entrer les numeros des deux equipes separes par une virgule (0,0 sinon) :";
			scanf("%d,%d", &n1, &n2);

			if ((n1 >= 0) && (n1 <= nbteams) && (n2 >= 0) && (n2 <= nbteams)) break;
			else cout << "Numeros non valides..." << endl;
			}
		while (true);

		if (matches[nbtours][k] != NULL) delete matches[nbtours][k];
		matches[nbtours][k]= new Partie(this, n1, n2);
		}

	done[nbtours]= true;

	return 0;	// OK
	}


// tirage des matches pour le tour t en mode elimionatoire
// retourne 0 si ok et < 0 si erreur
int Petanque::tirage_elimin(int t)
	{
	int r, passes= 0;
	unsigned j= 0, mem= 0;
	
	if (t > nbtours) return -1;

	if ((t > 1) && (! done[t-2])) 
		{
		cout << "Erreur de tour" << endl;

		return -1;
		}

	if (done[t-1])	// tirage deja fait => affichage
		{
		cout << "Attention, tirage " << t << " deja fait !" << endl;
		for (int k= 0 ; k <= (nbteams-1)/2 ; k++)
			matches[t-1][k]->show();

		return -2;
		}

	int nbtms= nbteams / power2(t-1);		// nb d'equipes restant en lice

	passes= 0; j= 0 ; mem= 0;

	int * used= new int[nbteams+1];
	for (int i= 0 ; i <= nbteams ; i++)
		{
		used[i]= 0;
		if (liste[i]->elimin) used[i]= 1;
		}

	if (t == 1) srand(time(NULL));

	for (int a= nbtms ; a > 0  ; a--)
		{
		int val= 0;

		r= rand() % a + 1;		// r= valeur entre 1 et a qui diminue

		for (j= 1 ; j <= nbteams ; j++)	
			{
			if (! used[j]) val++;		// recherche la r ieme case non eliminee et non utilisee
			if (val == r) break;
			}
		used[j]= 1;

		passes++;		
		if (passes % 2)			// toujours attendre 2 tirages pour creer une partie
			mem= j;
		else 
			{
			matches[t-1][a/2]= new Partie(this, j, mem);
			//	matches[t-1][a/2]->show();
			}
		}

	delete[] used;

	done[t-1]= true;
	return 0;	// OK
	}


// enregistrement d'un score tour t equipe n
// score de l'equipe n = s1, score de l'equipe adverse= s2
// retourne le numero du match >= 0 si trouve et < 0 si erreur
int Petanque::setscore(int t, unsigned n, unsigned s1, unsigned s2)
	{
	unsigned n1, n2, sco1, sco2;

	if ((t > nbtours+1) || (n > nbteams)) return -1;

	if (! done[t-1])
		{
		cout << "Tirage " << t << " non fait !" << endl;
		return -2;
		}

	for (int i= 0 ; i <= nbteams/2 ; i++)
		{
		if (matches[t-1][i] == NULL) continue;

		n1= matches[t-1][i]->num1;
		n2= matches[t-1][i]->num2;	

		if ((n1 == n) || (n2 == n))
			{
			sco1= s1;
			sco2= s2;

			if (n2 == n)		// remettre dans l'ordre pour que n1 = n et n2 = autre car plus clair
				{
				int m= n1;
				n1= n2;
				n2= m;

				sco1= s2;
				sco2= s1;
				}

			if (n2 == 0)		// l'equipe ne joue pas ce tour !
				{
				if ((mode == 'F') && (t == nbtours + 1))		// tour complementaire => on peut lui mettre des pts quand meme
					{
					matches[t - 1][i]->score1 = sco1;
					matches[t - 1][i]->score2 = 0;

					return i;
					}
				else
					{
					cout << "Cette equipe ne joue pas ce tour !" << endl;
					return -3;
					}
				}

			matches[t-1][i]->score1= sco1;
			matches[t-1][i]->score2= sco2;
			
			if (mode == 'M')
				{
				// affectation des points equipes aux joueurs si mode Melee
				for (int j= 1 ; j <= nbplayers ; j++)
					{
					for (int k= 0 ; k < 3 ; k++)
						{
						if (strcmp(liste[n1]->joueurs[k], personnes[j]->nom) == 0) 
							{
							personnes[j]->points[t-1] = s1;
							personnes[j]->contre[t-1] = s2;
							}
						if (strcmp(liste[n2]->joueurs[k], personnes[j]->nom) == 0) 
							{
							personnes[j]->points[t-1] = s2;
							personnes[j]->contre[t-1] = s1;
							}
						}
					}
				}

			if (mode == 'E')
				{
				// marquage des equipes eliminees
				if (s1 < s2) liste[n1]->elimin= true;
				if (s2 < s1) liste[n2]->elimin= true;
				if (s1 == s2)		// en particulier si nuls
					{
					liste[n1]->elimin= false;
					liste[n2]->elimin= false;
					}
				}

			return i;		// numero du match
			}
		}

	return -4;		// match non trouve !
	}


// affichage du bilan en equipes formees
void Petanque::bilan_forme()
	{
	for (int k= 1 ; k <= nbteams ; k++)
		{
		unsigned total= 0, contre= 0, parties= 0, gagnees= 0;		
				
		if (nbteams < 100)
			printf("E %2.2u : ", liste[k]->numero);
		else
			printf("E %3.3u : ", liste[k]->numero);
							
		for (int t= 1 ; t <= nbtours+1 ; t++)
			{
			if (! done[t-1]) break;

			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				int s1= -1, s2= -1;

				if (matches[t-1][j] == NULL) 
					continue;

				if (matches[t-1][j]->num1 == k) 
					{
					s1= matches[t-1][j]->score1;
					s2= matches[t-1][j]->score2;
					}

				if (matches[t-1][j]->num2 == k)
					{
					s1= matches[t-1][j]->score2;
					s2= matches[t-1][j]->score1;
					}

				// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

				if (s1 >= 0)
					{
					if ((s1 == 0) && (s2 == 0)) printf(" #/#   ");
					else printf("%2.2d/%2.2d  ", s1, s2);

					total += s1;
					contre += s2;
					if (s1 + s2 > 0) parties ++;		
					if (s1 > s2) gagnees ++;							
					}
				}
			}
			cout << " pts = " << total << "  pdu = -" << contre << " (" << parties << ") [" << gagnees << "] : ";
			liste[k]->afficher(false, true);
		}
		cout << endl;
	}


// recherche progressive des meilleures equipes en mode forme et eliminatoire
// retourne le numero de l'equipe trouvee
// ou 0 lors de l'initialition ou de l'epuisement de la liste
int Petanque::getnext_classement_forme(bool init)
	{
	static int total= 0, perdu= 0, parties= 0, gagnees= 0;		
	static int totmax= -1, permax= -1, partmax= 0, gagmax= 0;
	static int best= 0;
	static int * used= NULL;

	if (init)
		{
		total= 0, perdu= 0, parties= 0, gagnees= 0;	
		totmax= -1, permax= -1, partmax= 0, gagmax= 0;
		best= 0;

		if (used != NULL) delete[] used;

		used= new int[nbteams+1];		
		for (int i= 0 ; i <= nbteams ; i++)
			used[i]= 0;

		return 0;
		}
	
	totmax= -1; permax= -1; partmax= 0; gagmax= 0;

	for (int k= 1 ; k <= nbteams ; k++)
		{
		if (used[k]) continue;

		total= 0; perdu= 0; parties= 0; gagnees= 0;
		for (int t= 1 ; t <= nbtours+1 ; t++)
			{
			if (! done[t-1]) break;

			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				int s1= -1, s2= -1;

				if (matches[t-1][j] == NULL) 
					continue;

				if (matches[t-1][j]->num1 == k) 
					{
					s1= matches[t-1][j]->score1;
					s2= matches[t-1][j]->score2;
					}

				if (matches[t-1][j]->num2 == k)
					{
					s1= matches[t-1][j]->score2;
					s2= matches[t-1][j]->score1;
					}

				// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

				if (s1 >= 0)
					{
					total += s1;
					perdu += s2;
					if (s1 + s2 > 0) parties ++;		
					if (s1 > s2) gagnees ++;	

					if ((mode == 'E') && (t == nbtours) && (j == 0))
						{
						// en mode eliminatoire, il s'agit de la finale 
						// augmenter artificiellement le nb de parties gagn�es des finalistes
						// pour distinguer le 2e du 3e qui ont le m�me nb si petite finale
						gagnees ++;
						}
					}
				}
			}

		if ((gagnees > gagmax) || ((gagnees == gagmax) && (total > totmax))
			|| ((gagnees == gagmax) && (total == totmax) && (perdu <= permax)))
			{
			best= k;
			totmax= total;
			permax= perdu;
			partmax= parties;
			gagmax= gagnees;
			}
		}

	used[best]= 1;

	return best;
	}


// affichage du classement en utilisant la methode precedente
void Petanque::classement_forme()
	{
	int total= 0, perdu= 0, parties= 0, gagnees= 0;	
	int best= 0;

	// initialisation du moteur de classement
	getnext_classement_forme(true);

	cout << "Classement actuel du tournoi:" << endl;

	for (int i= 1 ; i <= nbteams ; i++)
		{
		total= 0; perdu= 0; parties= 0; gagnees= 0;

		// recherche de la meilleure equipe non encore classee
		best= getnext_classement_forme();

		// recalcul de ses scores et affichage
		if (nbteams < 100)
			printf("E %2.2u : ", liste[best]->numero);
		else
			printf("E %3.3u : ", liste[best]->numero);
			
		for (int t= 1 ; t <= nbtours+1 ; t++)
			{
			if (! done[t-1]) break;

			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				int s1= -1, s2= -1;

				if (matches[t-1][j] == NULL) 
					continue;

				if (matches[t-1][j]->num1 == best) 
					{
					s1= matches[t-1][j]->score1;
					s2= matches[t-1][j]->score2;
					}

				if (matches[t-1][j]->num2 == best)
					{
					s1= matches[t-1][j]->score2;
					s2= matches[t-1][j]->score1;
					}

				// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)
				if (s1 >= 0)
					{
					total += s1;
					perdu += s2;
					if (s1 + s2 > 0) parties ++;		
					if (s1 > s2) gagnees ++;	

					if ((s1 == 0) && (s2 == 0)) printf(" #/#   ");
					else printf("%2.2d/%2.2d  ", s1, s2);
					}
				}
			}

		cout << " pts = " << total << "  pdu = -" << perdu << " (" << parties << ") [" << gagnees << "] : ";
		liste[best]->afficher(false, true);
		}

	cout << endl;
	}


// sauvegarde des fichiers en equipes formees
// retourne 0 si OK
// retourne < 0 si erreur
int Petanque::sauvegarde_forme(int tour)
	{
	char fname[100]= "";
	FILE * fout;
	int error= 0;

	// sauvegarder liste des equipes			
	fout= fopen("P_equipes.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier equipes..." << endl;
		error= -1;
		}
	else
		{
		fprintf(fout, "F;%u;%d;\n", nbteams, nbtours); 

		for (int k= 1 ; k <= nbteams ; k++)
			{
			fprintf(fout, "%u;", liste[k]->numero);
			for (int i= 0 ; i < 3 ; i++)
				{
				fprintf(fout,  "%s;", liste[k]->joueurs[i]);
				}
			fprintf(fout, "\n");
			}
		fclose(fout);
		}
						
	// sauvegarder des tours avec matches + scores
	unsigned tr= nbtours;
	if (nbteams %2) tr++;

	for (int t= 1 ; t <= tr ; t++)
		{
		if (! done[t-1]) break;;

		sprintf(fname, "P_tour%d.csv", t);
		fout= fopen(fname, "w+t");
		if (fout == NULL) 
			{
			cout << "Erreur fichier tour..." << endl;
			error= -3;
			}
		else
			{
			fprintf(fout, "Tour %d\n", t);
			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				if (matches[t-1][j] == NULL) continue;

				int n1= matches[t-1][j]->num1;
				int n2= matches[t-1][j]->num2;

				fprintf(fout, "%u;", n1);
				fprintf(fout, "%u;=;", n2);
				fprintf(fout, "%u;", matches[t-1][j]->score1);
				fprintf(fout, "%u;", matches[t-1][j]->score2);	

				fprintf(fout, "(%s-%s-%s vs %s-%s-%s)", 
					liste[n1]->joueurs[0], liste[n1]->joueurs[1], liste[n1]->joueurs[2],
					liste[n2]->joueurs[0], liste[n2]->joueurs[1], liste[n2]->joueurs[2]);

				fprintf(fout, "\n");
				}
			fclose(fout);
			}
		}

	// sauvegarde du bilan
	fout= fopen("P_bilan.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier bilan..." << endl;
		error= -4;
		}
	else
		{
		fprintf(fout, "No;Noms;");
		for (int  t= 1 ; t < tr ; t++) fprintf(fout, "Tour %d;", t);
		if (nbteams % 2) fprintf(fout, "Tour comp;");
		else fprintf(fout, "Tour %d;", tr);										
		for (int  t= 1 ; t < tr ; t++) fprintf(fout, "Tour %d;", t);
		if (nbteams % 2) fprintf(fout, "Tour comp;");
		else fprintf(fout, "Tour %d;", tr);										
		fprintf(fout, "Total;Contre;Parties;Gagn�es\n");

		for (int k= 1 ; k <= nbteams ; k++)
			{
			fprintf(fout, "%u;", liste[k]->numero);
			for (int i= 0 ; i < 3 ; i++)
				{
				fprintf(fout,  "%s ", liste[k]->joueurs[i]);
				}
			fprintf(fout, ";");					
							
			unsigned total= 0, contre= 0, parties= 0, gagnees= 0;		
											
			for (int t= 1 ; t <= tr ; t++)
				{
				int comp= 0;

				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				for (int j= 0 ; j < (nbteams+1)/2 ; j++)
					{						
					int s1= -1, s2= -1;

					if (matches[t-1][j] == NULL) 
						{
						if (t < tr) fprintf(fout, "#;");
						continue;
						}

					if (matches[t-1][j]->num1 == k) 
						{
						s1= matches[t-1][j]->score1;
						s2= matches[t-1][j]->score2;
						}

					if (matches[t-1][j]->num2 == k)
						{
						s1= matches[t-1][j]->score2;
						s2= matches[t-1][j]->score1;
						}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s1 >= 0)
						{
						if ((s1 == 0) && (s2 == 0)) fprintf(fout, "#;");
						else fprintf(fout, "%d;", s1);

						total += s1;
						if (s1 + s2 > 0) parties ++;		
						if (s1 > s2) gagnees ++;	
						comp= 1;
						}
					}

				if ((t == tr) && (comp == 0)) fprintf(fout, "#;");		// equipe sans tour complementaire
				}

			for (int t= 1 ; t <= tr ; t++)
				{
				int comp= 0;

				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				for (int j= 0 ; j < (nbteams+1)/2 ; j++)
					{						
					int s1= -1, s2= -1;

					if (matches[t-1][j] == NULL) 
						{
						if (t < tr) fprintf(fout, "#;");
						continue;
						}

					if (matches[t-1][j]->num1 == k) 
						{
						s1= matches[t-1][j]->score1;
						s2= matches[t-1][j]->score2;
						}

					if (matches[t-1][j]->num2 == k)
						{
						s1= matches[t-1][j]->score2;
						s2= matches[t-1][j]->score1;
						}

					// s1 = s2 = 0 si equipe ne joue pas ce tour (nb impair d'equipes)

					if (s2 >= 0)
						{
						if ((s1 == 0) && (s2 == 0)) fprintf(fout, "#;");
						else fprintf(fout, "%d;", -s2);

						contre += s2;
						comp= 1;
						}
					}

				if ((t == tr) && (comp == 0)) fprintf(fout, "#;");		// equipe sans tour complementaire
				}
						
			fprintf(fout, "%u;-%u;%u;%u;\n", total, contre, parties, gagnees);
			}
		fclose(fout);				
		}

	return error;
	}


// pre-restauration en equipes formees
// retourne 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_test_forme()
	{
	FILE * fin;
	char buffer[1000];
	unsigned nb=1, nbtr=1, nbjr= 1;
	char mod= ' ';

	// test fichier des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier Equipes..." << endl;
		return -1;
		}
	else
		{
		// verification infos fondamentales : F ; nb equipes ; nb joueurs ; nbtours
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%d;", &mod, &nb, &nbtr);

		if ((mod != 'F') || (nb != nbteams) || (nbtr != nbtours))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
			return -2;
			}
		
		fclose(fin);
		}

	return 0;
	}


// restauration a partir des fichiers en equipes formees
// retourne tour >= 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_forme(int tr)
	{
	FILE * fin;
	char fname[100]= "";
	char buffer[1000];
	int nb= 0, nbtr= 0, tour= 0;
	unsigned n1= 0, n2= 0, s1= 0, s2= 0;
	char mod= ' ';

	// restaurer liste des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier equipes..." << endl;
		return -1;
		}				
	else
		{
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%d", &mod, &nb, &nbtr);		// recuperation infos fondamentales

		if ((mod != 'F') || (nb != nbteams) || (nbtr != nbtours))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
			fclose(fin);
			return -2;
			}

		// le tournoi doit avoir ete detruit et recree avant de poursuivre !

		for (int k= 1 ; k <= nb ; k++)
			{
			fgets(buffer, sizeof(buffer)-1, fin);			
			sscanf(buffer, "%u;", &liste[k]->numero);

			char * pvptr1= strchr(buffer, ';')+1;							

			for (int i= 0 ; i < 3 ; i++)
				{
				strcpy(liste[k]->joueurs[i], "");		// a titre pr�ventif

				char * pvptr2= strchr(pvptr1, ';');
				if (pvptr2 != NULL) 
					{
					if (pvptr2 == pvptr1)	// joueur vide
						{
						strcpy(liste[k]->joueurs[i], "");
						}
					else
						{						
						*pvptr2= 0;
						strcpy(liste[k]->joueurs[i], pvptr1);
						pvptr1= pvptr2+1;										
						}
					}				
				}

			liste[k]->afficher(true, true);
			}
		cout << endl;

		fclose(fin);
		}

	// restaurer tirages avec matches + scores
	for (int t= 1 ; t <= nbtr+1 ; t++)
		{
		sprintf(fname, "P_tour%d.csv", t);
		fin= fopen(fname, "rt");
		if (fin == NULL) done[t-1]= false;
		else
			{
			tour= t;			// tour augmente progressivement en ft des infos recuperees

			fgets(buffer, sizeof(buffer)-1, fin);	// ligne intro tour %d
			cout << buffer;
			for (int j= 0 ; j < (nb+1)/2 ; j++)
				{
				fgets(buffer, sizeof(buffer)-1, fin);
						
				char * pvptr1= buffer;
				char * pvptr2= NULL;
						
				for (int i= 1 ; i <= 5 ; i++)
					{
					pvptr2= strchr(pvptr1+1, ';');

					if (pvptr2 == NULL)		// cas du tour complementaire incomplet
						break;

					*pvptr2= 0;
					if (i == 1) sscanf(pvptr1, "%u", &n1);
					if (i == 2) sscanf(pvptr1, "%u", &n2);
					if (i == 4) sscanf(pvptr1, "%u", &s1);
					if (i == 5) sscanf(pvptr1, "%u", &s2);
					pvptr1= pvptr2+1;							
					}

				if (pvptr2 != NULL)
					{
					matches[t-1][j]= new Partie(this, n1, n2);
					matches[t-1][j]->score1= s1;
					matches[t-1][j]->score2= s2;							
					matches[t-1][j]->show();
					}
				}

			fclose(fin);

			done[t-1]= true;
			}
			cout << endl;
		}	
			
	return tour;
	}


// affichage du bilan en equipes melees
void Petanque::bilan_melee()
	{
	for (int k= 1 ; k <= nbplayers ; k++)
		{
		unsigned total= 0, perdu= 0, parties= 0, gagnees= 0;		
				
		if (nbplayers < 100)
			printf("J %2.2u : ", personnes[k]->numero);
		else
			printf("J %3.3u : ", personnes[k]->numero);
						
		for (int t= 1 ; t <= nbtours ; t++)
			{
			if (! done[t-1]) break;

			if (personnes[k]->points[t-1] != -1)
				{
				printf("%2.2d/%2.2d  ", personnes[k]->points[t-1], personnes[k]->contre[t-1]);
				total += personnes[k]->points[t-1];
				perdu += personnes[k]->contre[t-1];
				parties++;
				if (personnes[k]->points[t-1] > personnes[k]->contre[t-1]) gagnees++;
				}
			else
				{
				printf(" #/#   ");
				}
			}
					
		cout << " pts = " << total << "  pdu = -" << perdu << " (" << parties << ") [" << gagnees << "] : ";
		cout << personnes[k]->nom << endl;
		}
		cout << endl;
	}


// recherche progressive des meilleurs joueurs
// retourne le numero du joueur trouve
// ou 0 lors de l'initialition ou de l'epuisement de la liste
int Petanque::getnext_classement_melee(bool init)
	{
	static int total= 0, perdu= 0, parties= 0, gagnees= 0;		
	static int totmax= -1, permax= -1, partmax= 0, gagmax= 0;
	static int best= 0;
	static int * used= NULL;

	if (init)
		{
		total= 0, perdu= 0, parties= 0, gagnees= 0;	
		totmax= -1, permax= -1, partmax= 0, gagmax= 0;
		best= 0;

		if (used != NULL) delete[] used;

		used= new int[nbplayers+1];		
		for (int i= 0 ; i <= nbplayers ; i++)
			used[i]= 0;

		return 0;
		}

	totmax= -1; permax= -1;	partmax= 0;	gagmax= 0;
	
	for (int k= 1 ; k <= nbplayers ; k++)
		{
		if (used[k]) continue;

		total= 0; perdu= 0; parties= 0; gagnees= 0;
		for (int t= 1 ; t <= nbtours ; t++)
			{
			if (! done[t-1]) break;

			if (personnes[k]->points[t-1] != -1)
				{						
				total += personnes[k]->points[t-1];
				perdu += personnes[k]->contre[t-1];
				parties ++;
				if (personnes[k]->points[t-1] > personnes[k]->contre[t-1]) gagnees ++;
				}
			}

		if ((gagnees > gagmax) || ((gagnees == gagmax) && (total > totmax))
			|| ((gagnees == gagmax) && (total == totmax) && (perdu <= permax)))
			{
			best= k;
			totmax= total;
			permax= perdu;
			partmax= parties;
			gagmax= gagnees;
			}
		}

	used[best]= 1;

	return best;
	}


// affichage du classement en utilisant la methode precedente
void Petanque::classement_melee()
	{
	int total= 0, perdu= 0, parties= 0, gagnees= 0;		
	int best= 0;

	// initialisation du moteur de classement
	getnext_classement_melee(true);

	cout << "Classement actuel du tournoi:" << endl;

	for (int i= 1 ; i <= nbplayers ; i++)
		{
		total= 0; perdu= 0; parties= 0; gagnees= 0;

		// recherche du meilleur joueur non encore classe
		best= getnext_classement_melee();

		// recalcul de ses scores et affichage
		for (int t= 1 ; t <= nbtours ; t++)
			{
			if (! done[t-1]) break;

			if (personnes[best]->points[t-1] != -1)
				{						
				total += personnes[best]->points[t-1];
				perdu += personnes[best]->contre[t-1];
				parties ++;
				if (personnes[best]->points[t-1] > personnes[best]->contre[t-1]) gagnees ++;
				}
			}
	
		// affichage
		if (nbplayers < 100)
			printf("J %2.2u : ", personnes[best]->numero);
		else
			printf("J %3.3u : ", personnes[best]->numero);
			
		for (int t= 1 ; t <= nbtours ; t++)
			{
			if (! done[t-1]) break;

			if (personnes[best]->points[t-1] != -1)
				printf("%2.2d/%2.2d  ", personnes[best]->points[t-1], personnes[best]->contre[t-1]);
			}

		cout << " pts = " << total << "  pdu = -" << perdu << " (" << parties << ") [" << gagnees << "] : ";
		cout << personnes[best]->nom << endl;
		}

	cout << endl;
	}


// recuperation des equipes d'un ancien tour
// recoit un tableau de pointeurs de taille suffisante
// retourne 0 si OK et < 0 si erreur
int Petanque::get_equipes_melee(int tour, Equipe ** oldequipes)
	{
	FILE * fin;
	char fname[100]= "";
	char buffer[1000];
	unsigned n1= 0, n2= 0, s1= 0, s2= 0;
	char equipe1[200], equipe2[200];

	sprintf(fname, "P_tour%d.csv", tour);
	fin= fopen(fname, "rt");
	if (fin == NULL) 
		{
		return -1;
		}
	else
		{
		// ligne intro tour %d
		fgets(buffer, sizeof(buffer)-1, fin);	
		cout << buffer;
		for (int j= 0 ; j < (nbteams+1)/2 ; j++)
			{
			fgets(buffer, sizeof(buffer)-1, fin);
						
			char * pvptr1= buffer;
			char * pvptr2= NULL;
						
			for (int i= 1 ; i <= 5 ; i++)
				{
				pvptr2= strchr(pvptr1+1, ';');
				*pvptr2= 0;
				if (i == 1) sscanf(pvptr1, "%u", &n1);
				if (i == 2) sscanf(pvptr1, "%u", &n2);
				if (i == 4) sscanf(pvptr1, "%u", &s1);
				if (i == 5) sscanf(pvptr1, "%u", &s2);
				pvptr1= pvptr2+1;							
				}

			// equipe 1 entre ( et espace
			sscanf(pvptr1+1, "%s", equipe1);
			// equipe 2 entre espace et )
			sscanf(pvptr1+strlen(equipe1)+5, "%s", equipe2);
			char * parptr= strchr(equipe2, ')');
			if (parptr != NULL) *parptr= 0;

			oldequipes[n1]= new Equipe;
			oldequipes[n1]->definir(n1, equipe1);
			oldequipes[n2]= new Equipe;
			oldequipes[n2]->definir(n2, equipe2);
			}

		fclose(fin);
		}

	return 0;
	}


// sauvegarde des fichiers en equipes melees
int Petanque::sauvegarde_melee(int tour)
	{
	FILE * fout;
	char fname[100]= "";
	char buffer[1000];
	int error= 0;

	// sauvegarder liste des equipes actuelles
	fout= fopen("P_equipes.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier equipes..." << endl;
		error= -1;
		}
	else
		{
		// M => equipes melees
		fprintf(fout, "M;%u;%u;%d;%c;\n", nbteams, nbplayers, nbtours, pref);	

		for (int k= 1 ; k <= nbteams ; k++)
			{
			fprintf(fout, "%u;", liste[k]->numero);
			for (int i= 0 ; i < 3 ; i++)
				{
				fprintf(fout,  "%s;", liste[k]->joueurs[i]);
				}
			fprintf(fout, "\n");
			}
		fclose(fout);
		}

	// sauvegarder liste des joueurs + points (Utilisee si jeu a la melee)	
	fout= fopen("P_joueurs.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier joueurs..." << endl;
		error= -2;
		}
	else
		{
		fprintf(fout, "M;%u;%u;\n", nbplayers, nbtours);
				
		for (int k= 1 ; k <= nbplayers ; k++)
			{
			fprintf(fout, "%u;", personnes[k]->numero);
			fprintf(fout,  "%s;", personnes[k]->nom);	

			for (int t= 1 ; t <= nbtours ; t++)
				{
				fprintf(fout, "%d~%d;", personnes[k]->points[t-1], personnes[k]->contre[t-1]);
				}

			fprintf(fout, "\n");
			}
		fclose(fout);
		}
						
	// sauvegarder du tour actuel avec matches + scores + equipes	
	int t= tour;
	if (t >= 1)
		{
		sprintf(fname, "P_tour%d.csv", t);
		fout= fopen(fname, "w+t");
		if (fout == NULL) 
			{
			cout << "Erreur fichier tour..." << endl;
			error= -3;
			}
		else
			{
			fprintf(fout, "Tour %d\n", t);
			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				if (matches[t-1][j] == NULL) continue;

				unsigned n1= matches[t-1][j]->num1;
				unsigned n2= matches[t-1][j]->num2;

				fprintf(fout, "%u;", n1);
				fprintf(fout, "%u;=;", n2);
				fprintf(fout, "%u;", matches[t-1][j]->score1);
				fprintf(fout, "%u;", matches[t-1][j]->score2);	
				fprintf(fout, "(%s_%s_%s vs %s_%s_%s)", 
					liste[n1]->joueurs[0], liste[n1]->joueurs[1], liste[n1]->joueurs[2],
					liste[n2]->joueurs[0], liste[n2]->joueurs[1], liste[n2]->joueurs[2]);

				fprintf(fout, "\n");
				}
			fclose(fout);
			}		
		}

	// sauvegarde du bilan
	fout= fopen("P_bilan.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier bilan..." << endl;
		error= -4;
		}
	else
		{
		fprintf(fout, "No;Nom;");
		for (int  t= 1 ; t <= nbtours ; t++) fprintf(fout, "Tour %d;", t);
		for (int  t= 1 ; t <= nbtours ; t++) fprintf(fout, "Tour %d;", t);
		fprintf(fout, "Total;Contre;Parties;Gagn�es\n");

		for (int k= 1 ; k <= nbplayers ; k++)
			{
			unsigned total= 0, perdu= 0, parties= 0, gagnees= 0;		
				
			fprintf(fout, "%u;%s;", personnes[k]->numero, personnes[k]->nom);
						
			for (int t= 1 ; t <= nbtours ; t++)
				{
				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				if (personnes[k]->points[t-1] != -1)
					{
					fprintf(fout, "%d;", personnes[k]->points[t-1]);
					total += personnes[k]->points[t-1];
					parties++;
					if (personnes[k]->points[t-1] > personnes[k]->contre[t-1]) gagnees++;
					}
				else
					fprintf(fout, "#;");
				}
				
			for (int t= 1 ; t <= nbtours ; t++)
				{
				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				if (personnes[k]->points[t-1] != -1)
					{
					fprintf(fout, "%d;", -personnes[k]->contre[t-1]);
					perdu += personnes[k]->contre[t-1];
					}
				else
					fprintf(fout, "#;");
				}

			fprintf(fout, "%u;%d;%u;%u;\n", total, -perdu, parties, gagnees);
			}

		fclose(fout);
		}

	return error;
	}


// pre-restauration en equipes melees
// retourne 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_test_melee()
	{
	FILE * fin;
	char buffer[1000];
	unsigned nb=1, nbtr=1, nbjr= 1;
	char mod= ' ', prefce= 'D';

	// test fichier des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier Equipes..." << endl;
		return -1;
		}
	else
		{
		// verification infos fondamentales : F ; nb equipes ; nb joueurs ; nbtours
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%u;%d;%c;", &mod, &nb, &nbjr, &nbtr, &prefce);

		if ((mod != 'M') || (nb != nbteams) || (nbjr != nbplayers) || (nbtr != nbtours) || (prefce != pref))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
			return -2;
			}
		
		fclose(fin);
		}

	fin= fopen("P_joueurs.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier joueurs..." << endl;
		return -3;
		}
	else
		{				
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%u;", &mod, &nbjr, &nbtr);		// recuperation infos fondamentales

		if ((mod != 'M') || (nbjr != nbplayers) || (nbtr != nbtours))
			{
			cout << "Erreur fichier joueurs (mode ou parametres incorrects)" << endl;
			return -4;
			}

		fclose(fin);
		}

	return 0;
	}

// restauration des fichiers en equipes melees
// retourne tour >= 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_melee(int tr)
	{
	FILE * fin;
	char fname[100]= "";
	char buffer[1000];

	unsigned nb=1, nbtr=1, nbjr=1;
	int nbt= 0, tour= 0;

	unsigned n1= 0, n2= 0, s1= 0, s2= 0;
	char mod= ' ', prefce= 'D';

	// restaurer la derniere liste des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier Equipes..." << endl;
		return -1;
		}
	else
		{
		// recuperation infos fondamentales : M ; nb equipes ; nb joueurs ; nbtours
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%u;%d;%c;", &mod, &nb, &nbjr, &nbtr, &prefce);

		if ((mod != 'M') || (nb != nbteams) || (nbjr != nbplayers) || (nbtr != nbtours) || (prefce != pref))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;	
			fclose(fin);
			return -2;		
			}

		// le tournoi doit avoir ete detruit et recree avant de poursuivre !

		for (int k= 1 ; k <= nb ; k++)
			{
			fgets(buffer, sizeof(buffer)-1, fin);			
			sscanf(buffer, "%u;", &liste[k]->numero);

			char * pvptr1= strchr(buffer, ';')+1;
						
			for (int i= 0 ; i < 3 ; i++)
				{
				strcpy(liste[k]->joueurs[i], "");		// a titre pr�ventif

				char * pvptr2= strchr(pvptr1, ';');
				if (pvptr2 != NULL) 
					{
					if (pvptr2 == pvptr1)	// joueur vide
						{
						strcpy(liste[k]->joueurs[i], "");
						}
					else
						{						
						*pvptr2= 0;
						strcpy(liste[k]->joueurs[i], pvptr1);
						pvptr1= pvptr2+1;										
						}
					}				
				}

			liste[k]->afficher(true, true);
			}
		cout << endl;

		fclose(fin);
		}

	// restaurer tirages avec matches + scores (mais pas les equipes associees)
	for (int t= 1 ; t <= nbtr+1 ; t++)
		done[t-1]= false;

	for (int t= 1 ; t <= nbtr ; t++)
		{
		sprintf(fname, "P_tour%d.csv", t);
		fin= fopen(fname, "rt");
		if (fin == NULL) 
			{
			break;
			}
		else
			{
			tour= t;			// tour augmente progressivement en ft des infos recuperees

			// ligne intro tour %d
			fgets(buffer, sizeof(buffer)-1, fin);	
			cout << buffer;
			for (int j= 0 ; j < (nb+1)/2 ; j++)
				{
				fgets(buffer, sizeof(buffer)-1, fin);
						
				char * pvptr1= buffer;
				char * pvptr2= NULL;
						
				for (int i= 1 ; i <= 5 ; i++)
					{
					pvptr2= strchr(pvptr1+1, ';');
					*pvptr2= 0;
					if (i == 1) sscanf(pvptr1, "%u", &n1);
					if (i == 2) sscanf(pvptr1, "%u", &n2);
					if (i == 4) sscanf(pvptr1, "%u", &s1);
					if (i == 5) sscanf(pvptr1, "%u", &s2);
					pvptr1= pvptr2+1;							
					}

				if (pvptr2 != NULL)
					{
					matches[t-1][j]= new Partie(this, n1, n2);
					matches[t-1][j]->score1= s1;
					matches[t-1][j]->score2= s2;							
					matches[t-1][j]->show();
					}
				}

			fclose(fin);

			done[t-1]= true;
			}
			cout << endl;
		}

	// restaurer liste des joueurs + points (utilisee si melee)
	// utilise la variable tour provenant de ce qui precede
	fin= fopen("P_joueurs.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier joueurs..." << endl;
		return -3;
		}
	else
		{				
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%u;", &mod, &nbjr, &nbt);		// recuperation infos fondamentales

		if (mod != 'M')
			{
			cout << "Erreur fichier joueurs (mode != melee)" << endl;
			fclose(fin);
			tour= 0;
			return tour;
			}

		if (nbt != nbtours)
			{
			cout << "Erreur fichier joueurs (nb de tours different)" << endl;
					
			if (nbt > nbtours) nbt= nbtours;
			}

		// infos suivantes : n� ; nom ; scores 
		for (int k= 1 ; k <= nbjr ; k++)
			{
			unsigned num= 0;

			fgets(buffer, sizeof(buffer)-1, fin);			
			sscanf(buffer, "%u;", &num);

			personnes[k]->numero= num;
			strcpy(personnes[k]->nom, "");		// a titre pr�ventif
					
			char * pvptr1= strchr(buffer, ';')+1;

			char * pvptr2= strchr(pvptr1, ';');
			if (pvptr2 != NULL) 
				{
				if (pvptr2 == pvptr1)	// joueur vide
					{
					strcpy(personnes[k]->nom, "");
					}
				else
					{						
					*pvptr2= 0;
					strcpy(personnes[k]->nom, pvptr1);				
					}
				}		

			for (int t= 1 ; t <= nbt ; t++)
				{
				if (t <= tour)
					{
					sscanf(pvptr2+1, "%d~%d;", &personnes[k]->points[t-1], &personnes[k]->contre[t-1]);
					pvptr2= strchr(pvptr2+1, ';');
					if (pvptr2 == NULL) break;
					}
				else
					{
					personnes[k]->points[t-1]= -1;
					personnes[k]->contre[t-1]= -1;
					}
				}

			personnes[k]->afficher(true);
			}
		cout << endl;

		fclose(fin);
		}

	return tour;
	}


// sauvegarde des fichiers en mode eliminatoire
// retourne 0 si OK
// retourne < 0 si erreur
int Petanque::sauvegarde_elimin(int tour)
	{
	char fname[100]= "";
	FILE * fout;
	int error= 0;

	// sauvegarder liste des equipes			
	fout= fopen("P_equipes.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier equipes..." << endl;
		error= -1;
		}
	else
		{
		fprintf(fout, "E;%u;%d;\n", nbteams, nbtours); 

		for (int k= 1 ; k <= nbteams ; k++)
			{
			fprintf(fout, "%u;", liste[k]->numero);
			for (int i= 0 ; i < 3 ; i++)
				{
				fprintf(fout,  "%s;", liste[k]->joueurs[i]);
				}
			fprintf(fout, "\n");
			}
		fclose(fout);
		}
						
	// sauvegarder des tours avec matches + scores
	unsigned tr= nbtours;

	for (int t= 1 ; t <= tr ; t++)
		{
		if (! done[t-1]) break;;

		sprintf(fname, "P_tour%d.csv", t);
		fout= fopen(fname, "w+t");
		if (fout == NULL) 
			{
			cout << "Erreur fichier tour..." << endl;
			error= -3;
			}
		else
			{
			fprintf(fout, "Tour %d\n", t);
			for (int j= 0 ; j < (nbteams+1)/2 ; j++)
				{						
				if (matches[t-1][j] == NULL) continue;

				int n1= matches[t-1][j]->num1;
				int n2= matches[t-1][j]->num2;

				fprintf(fout, "%u;", n1);
				fprintf(fout, "%u;=;", n2);
				fprintf(fout, "%u;", matches[t-1][j]->score1);
				fprintf(fout, "%u;", matches[t-1][j]->score2);	

				fprintf(fout, "(%s-%s-%s vs %s-%s-%s)", 
					liste[n1]->joueurs[0], liste[n1]->joueurs[1], liste[n1]->joueurs[2],
					liste[n2]->joueurs[0], liste[n2]->joueurs[1], liste[n2]->joueurs[2]);

				fprintf(fout, "\n");
				}
			fclose(fout);
			}
		}

	// sauvegarde du bilan
	fout= fopen("P_bilan.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier bilan..." << endl;
		error= -4;
		}
	else
		{
		fprintf(fout, "No;Noms;");
		for (int  t= 1 ; t < tr ; t++) fprintf(fout, "Tour %d;", t);
		if (nbteams % 2) fprintf(fout, "Tour comp;");
		else fprintf(fout, "Tour %d;", tr);										
		for (int  t= 1 ; t < tr ; t++) fprintf(fout, "Tour %d;", t);
		if (nbteams % 2) fprintf(fout, "Tour comp;");
		else fprintf(fout, "Tour %d;", tr);										
		fprintf(fout, "Total;Contre;Parties;Gagn�es\n");

		for (int k= 1 ; k <= nbteams ; k++)
			{
			fprintf(fout, "%u;", liste[k]->numero);
			for (int i= 0 ; i < 3 ; i++)
				{
				fprintf(fout,  "%s ", liste[k]->joueurs[i]);
				}
			fprintf(fout, ";");					
							
			unsigned total= 0, contre= 0, parties= 0, gagnees= 0;		
											
			for (int t= 1 ; t <= tr ; t++)
				{
				int vue= 0;

				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				for (int j= 0 ; j < nbteams/2 ; j++)
					{						
					int s1= -1, s2= -1;

					if (matches[t-1][j] == NULL) 
						{
						continue;
						}

					if (matches[t-1][j]->num1 == k) 
						{
						s1= matches[t-1][j]->score1;
						s2= matches[t-1][j]->score2;
						}

					if (matches[t-1][j]->num2 == k)
						{
						s1= matches[t-1][j]->score2;
						s2= matches[t-1][j]->score1;
						}

					if (s1 >= 0)
						{
						if ((s1 == 0) && (s2 == 0)) fprintf(fout, "#;");
						else fprintf(fout, "%d;", s1);

						total += s1;
						if (s1 + s2 > 0) parties ++;		
						if (s1 > s2) gagnees ++;	
						vue= 1;
						}
					}

					if (vue == 0) fprintf(fout, "#;");		// �quipe �limin�e n'apparaissant pas
				}

			for (int t= 1 ; t <= tr ; t++)
				{
				int vue= 0;

				if (! done[t-1]) 
					{
					fprintf(fout, "#;");
					continue;
					}

				for (int j= 0 ; j < nbteams/2 ; j++)
					{						
					int s1= -1, s2= -1;

					if (matches[t-1][j] == NULL) 
						{
						continue;
						}

					if (matches[t-1][j]->num1 == k) 
						{
						s1= matches[t-1][j]->score1;
						s2= matches[t-1][j]->score2;
						}

					if (matches[t-1][j]->num2 == k)
						{
						s1= matches[t-1][j]->score2;
						s2= matches[t-1][j]->score1;
						}

					if (s2 >= 0)
						{
						if ((s1 == 0) && (s2 == 0)) fprintf(fout, "#;");
						else fprintf(fout, "%d;", -s2);

						contre += s2;
						vue= 1;
						}
					}

				if (vue == 0) fprintf(fout, "#;");		// �quipe �limin�e n'apparaissant pas
				}
						
			fprintf(fout, "%u;-%u;%u;%u;\n", total, contre, parties, gagnees);
			}
		fclose(fout);				
		}

	return error;
	}


// pre-restauration en mode eliminatoire
// retourne 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_test_elimin()
	{
	FILE * fin;
	char buffer[1000];
	unsigned nb=1, nbtr=1, nbjr= 1;
	char mod= ' ';

	// test fichier des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier Equipes..." << endl;
		return -1;
		}
	else
		{
		// verification infos fondamentales : F ; nb equipes ; nb joueurs ; nbtours
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%d;", &mod, &nb, &nbtr);

		if ((mod != 'E') || (nb != nbteams) || (nbtr != nbtours))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
			return -2;
			}
		
		fclose(fin);
		}

	return 0;
	}


// restauration a partir des fichiers en mode eliminatoire
// retourne tour >= 0 si OK
// retourne < 0 si erreur
int Petanque::restauration_elimin(int tr)
	{
	FILE * fin;
	char fname[100]= "";
	char buffer[1000];
	int nb= 0, nbtr= 0, tour= 0;
	unsigned n1= 0, n2= 0, s1= 0, s2= 0;
	char mod= ' ';

	// restaurer liste des equipes
	fin= fopen("P_equipes.csv", "rt");
	if (fin == NULL) 
		{
		cout << "Pas de fichier equipes..." << endl;
		return -1;
		}				
	else
		{
		fgets(buffer, sizeof(buffer)-1, fin);
		sscanf(buffer, "%c;%u;%d", &mod, &nb, &nbtr);		// recuperation infos fondamentales

		if ((mod != 'E') || (nb != nbteams) || (nbtr != nbtours))
			{
			cout << "Erreur fichier equipes (mode ou parametres incorrects)" << endl;
			fclose(fin);
			return -2;
			}

		// le tournoi doit avoir ete detruit et recree avant de poursuivre !

		for (int k= 1 ; k <= nb ; k++)
			{
			fgets(buffer, sizeof(buffer)-1, fin);			
			sscanf(buffer, "%u;", &liste[k]->numero);

			char * pvptr1= strchr(buffer, ';')+1;
						
			for (int i= 0 ; i < 3 ; i++)
				{
				strcpy(liste[k]->joueurs[i], "");		// a titre pr�ventif

				char * pvptr2= strchr(pvptr1, ';');
				if (pvptr2 != NULL) 
					{
					if (pvptr2 == pvptr1)	// joueur vide
						{
						strcpy(liste[k]->joueurs[i], "");
						}
					else
						{						
						*pvptr2= 0;
						strcpy(liste[k]->joueurs[i], pvptr1);
						pvptr1= pvptr2+1;										
						}
					}				
				}

			liste[k]->afficher(true, true);
			}
		cout << endl;

		fclose(fin);
		}

	// restaurer tirages avec matches + scores
	for (int t= 1 ; t <= nbtr ; t++)
		{
		sprintf(fname, "P_tour%d.csv", t);
		fin= fopen(fname, "rt");
		if (fin == NULL) done[t-1]= false;
		else
			{
			tour= t;			// tour augmente progressivement en ft des infos recuperees

			fgets(buffer, sizeof(buffer)-1, fin);	// ligne intro tour %d
			cout << buffer;
			for (int j= 0 ; j < (nb+1)/2 ; j++)
				{
				fgets(buffer, sizeof(buffer)-1, fin);
						
				char * pvptr1= buffer;
				char * pvptr2= NULL;
						
				for (int i= 1 ; i <= 5 ; i++)
					{
					pvptr2= strchr(pvptr1+1, ';');

					if (pvptr2 == NULL)		// cas du tour complementaire incomplet
						break;

					*pvptr2= 0;
					if (i == 1) sscanf(pvptr1, "%u", &n1);
					if (i == 2) sscanf(pvptr1, "%u", &n2);
					if (i == 4) sscanf(pvptr1, "%u", &s1);
					if (i == 5) sscanf(pvptr1, "%u", &s2);
					pvptr1= pvptr2+1;							
					}

				if (pvptr2 != NULL)
					{
					matches[t-1][j]= new Partie(this, n1, n2);
					matches[t-1][j]->score1= s1;
					matches[t-1][j]->score2= s2;							
					matches[t-1][j]->show();

					if (s1 > s2) liste[n2]->elimin= TRUE;
					if (s2 > s1) liste[n1]->elimin= TRUE;
					}
				}

			fclose(fin);

			done[t-1]= true;
			}
			cout << endl;
		}	
			
	return tour;
	}


// suppression des fichiers anterieurs
void remove_files()
	{
	char fname[1000]= "";
	char pathname[1000]= "";

	GetCurrentDirectory(sizeof(pathname), (LPTSTR) pathname);

	sprintf(fname, "%s/%s.csv", pathname, "P_bilan");
	DeleteFile(_T(fname));		// ft API Windows
	
	sprintf(fname, "%s/%s.csv", pathname, "P_joueurs");
	DeleteFile(_T(fname));		// ft API Windows
	
	sprintf(fname, "%s/%s.csv", pathname, "P_equipes");
	DeleteFile(_T(fname));		// ft API Windows
	
	sprintf(fname, "%s/%s.csv", pathname, "P_bilan");
	DeleteFile(_T(fname));		// ft API Windows
	
	sprintf(fname, "%s/%s.csv", pathname, "P_equipes_conso");
	DeleteFile(_T(fname));		// ft API Windows

	for (int i= 1 ; i <= 11; i++)		// maximum 10 tours + 1
		{
		sprintf(fname, "%s/%s%d.csv", pathname, "P_tour", i);
		DeleteFile(_T(fname));		// ft API Windows
		}
	}


// creation d'une liste d'equipes en consolante (Mode Eliminatoire uniquement)
int create_conso(Petanque * tournoi, int t)
	{
	char fname[100]= "";
	FILE * fout;
	int error= 0;

	fout= fopen("P_equipes_conso.csv", "w+t");
	if (fout == NULL) 
		{
		cout << "Erreur fichier conso..." << endl;
		error= -1;
		}
	else
		{
		int nbtr= tournoi->nbtours - t;		// nb de tours restant

		fprintf(fout, "E;%u;%d;\n", power2(nbtr), nbtr); 

			unsigned cpt= 0;
			int n= 0;

			for (int j= 0 ; j < tournoi->nbteams / 2 ; j++)
			{
				if (tournoi->matches[t-1][j] == NULL) continue;

				// l'un des 2 seulement devrait �tre nul
				int n1= tournoi->matches[t-1][j]->num1;
				int n2= tournoi->matches[t-1][j]->num2;

				n= 0;

				if (tournoi->liste[n1]->elimin) n= n1; 
				else if (tournoi->liste[n2]->elimin) n= n2;

				if (n != 0)
				{
					fprintf(fout, "%u;", cpt+1);
					for (int i= 0 ; i < 3 ; i++)
						{
						fprintf(fout,  "%s;", tournoi->liste[n]->joueurs[i]);
						}
					fprintf(fout, "\n");

					cpt++;
				}				
			}

		if (cpt != power2(nbtr))	// inconsistance qui ne devrait pas arriver
			error= -2;

		fclose(fout);
		}	

	return error;
	}


// calcul de 2^n
unsigned power2(unsigned n)
	{
	unsigned p= 1;

	for (int i= 1 ; i <= n ; i++)
		p *= 2;

	return p;
	}