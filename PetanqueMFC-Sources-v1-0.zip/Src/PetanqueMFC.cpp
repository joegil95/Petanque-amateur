/*
@(#) JG 2026

A compiler en VC++ avec MFC

Attention: d�sactiver unicode pour les noms de fichiers

Le code de base est le m�me que celui de la version ligne de commande
*/


#include "PetanqueMFC.rh"
#include "PetanqueMFC.h"

#include "DialoguesMFC.h"

Petanque * tournoi= NULL;
bool start= false;
int tour = 0;
int conso = 0;


// pour compatibilit� avec la version en ligne de commande
void gets(char * stg) {}


static UINT indicators[] =
{
	ID_SEPARATOR,           // indicateur de la statusbar
	ID_INDICATOR_CAPS,		// etat des touches Maj et Num 
	ID_INDICATOR_NUM		// qui apparait en bas � droite de la fen�tre
};

// Cree et lance l'application
CTheApp NEAR theApp;

// constructeur CMainWindow
CMainWindow::CMainWindow()
	{
  	Create(NULL, _T("P�tanque Amateur"), WS_OVERLAPPEDWINDOW, rectDefault);

	// chargement du menu
	menu = new CMenu();
	menu->LoadMenu(IDM_MENU);  	
	SetMenu(menu);

	HICON monIcone = AfxGetApp()->LoadIcon(IDR_ICON); 
    SetIcon(monIcone, TRUE);

	toolbar = new CToolBar;
	toolbar->CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC);
	toolbar->LoadToolBar(IDT_TOOLBAR);

	// ajouter ces 3 lignes pour que la barre d'outils soit amovible
	// toolbar->EnableDocking(CBRS_ALIGN_ANY);
	// EnableDocking(CBRS_ALIGN_ANY);
	// DockControlBar(toolbar);	

	statusbar= new CStatusBar;
	statusbar->Create(this);
	statusbar->SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	Grid_Equipesptr= NULL;
	Grid_Joueursptr= NULL;
	Grid_Scoresptr= NULL;
	Grid_Bilanptr= NULL;
	Grid_Classementptr= NULL;

	Equipes_edit= TRUE;
	Joueurs_edit= TRUE;	
	}

CMainWindow::~CMainWindow()
	{
	delete statusbar;
	delete toolbar;

	delete menu;

	if (tournoi != NULL) delete tournoi;
	}


/*
Menu Fichier
*/

void CMainWindow::OnNew()
{
	char msg[1000];
	unsigned nb = 1, nbtr = 1, nbjr = 1;

	if (tournoi != NULL)
	{
		MessageBox(_T("Un tournoi est d�j� en cours.\n\nFermer le programme et le relancer pour en cr�er un nouveau."),
			_T("Attention"), MB_OK);
		return;
	}

	int answer = MessageBox(_T("Voulez-vous supprimer tous les fichiers ant�rieurs\n\n"\
		"avant de d�marrer un nouveau tournoi ?"), _T("Nouveau tournoi"), MB_YESNO);
	if (answer == IDYES) remove_files();

	CInitDlg modedlg(INIT_DLG);
	modedlg.contexte = 0;
	int res = modedlg.DoModal();
	if (res != IDOK) return;

	if (modedlg.choix == 1)			// tournoi en �quipes form�es
	{
		name= modedlg.field3.GetString();		// nom du tournoi

		nb = atoi(modedlg.field1.GetString());			// nb d'equipes saisi
		nbtr= atoi(modedlg.field2.GetString());			// nb de tours saisi

		if ((nb < 4) || (nbtr >= nb))
		{
			MessageBox(_T("Nombre d'�quipes insuffisant ou nombre de tours trop �lev� !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}
		if (nbtr > 10)
		{
			MessageBox(_T("Nombre de tours trop �lev� (maximum 10) !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}

		if (nb % 2)		// nb impair d'equipes 
		{
			if (nbtr % 2)		// et de tours
			{
				int go= MessageBox(_T("Avec un nombre impair d'�quipes et de tours il est tr�s difficile d'avoir le m�me nombre de matches pour tous !\n\n"\
					"Vous pourrez faire un tour compl�mentaire au besoin pour rattraper au mieux...\n\n"\
					"Voulez-vous continuer ?"),
					_T("Attention !"), MB_YESNO | MB_ICONWARNING);

				if (go != IDYES) return;
			}
			else
			{
				MessageBox(_T("Avec un nombre impair d'�quipes il y aura une �quipe passive � chaque tour.\n\n"\
					"Vous pourrez faire un tour compl�mentaire pour �quilibrer le nombre de matches..."),
					_T("Attention !"), MB_OK | MB_ICONWARNING);				
			}
		}

		tournoi = new Petanque(nbtr, nb);
		if (tournoi != NULL)
		{
			wsprintf(msg, "Tournoi form� cr�� pour %u �quipes form�es, sur %u tours\n\nVous pouvez saisir la liste des �quipes.", nb, nbtr);
			MessageBox(_T(msg), _T("Cr�ation du tournoi"), MB_OK);

			SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);
		}
		else
			MessageBox(_T("Erreur d'allocation !"), _T("Cr�ation du tournoi"), MB_OK);
	}
	else if (modedlg.choix == 2)		// tournoi � la m�l�e	
	{			
		name= modedlg.field3.GetString();		// nom du tournoi

		nbjr = atoi(modedlg.field1.GetString());	// nb de joueurs saisi
		nbtr = atoi(modedlg.field2.GetString());	// nb de tours saisi

		if (nbjr < 8)
		{
			MessageBox(_T("Nombre de joueurs insuffisant !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}

		if (nbtr > 10)
		{
			MessageBox(_T("Nombre de tours trop �lev� (maximum 10) !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}

		int choice = MessageBox(_T("Voulez-vous un maximum de doublettes (Oui) \n\n"\
			"ou sinon un maximum de triplettes (Non) ?"),
			_T("Type d'�quipes"), MB_YESNO);

		char prefce = 'D';
		if (choice == IDNO) prefce = 'T';

		// calcul du nb d'equipes
		nb = nb_equipes(nbjr, prefce);

		if (nbtr >= nb)
		{
			wsprintf(msg, "Nombre de tours trop �lev� (%u) pour le nombre d'�quipes obtenu (%u) !", nbtr, nb);
			MessageBox(_T(msg), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}
		else
		{
			wsprintf(msg, "Le nombre d'�quipes ainsi obtenu est : %u", nb);
			MessageBox(_T(msg), _T("Nombre d'�quipes"), MB_OK);
		}

		MessageBox(_T("Attention:\n\nDeux joueurs ne doivent pas avoir exactement le m�me nom\n\n"\
			"car cela entra�nerait un risque d'erreurs !"), _T("Noms des joueurs"), MB_OK | MB_ICONWARNING);

		tournoi = new Petanque(nbtr, nb, nbjr, prefce);
		if (tournoi != NULL)
		{
			wsprintf(msg, "Tournoi � la m�l�e cr�� pour %u joueurs (%u �quipes), sur %u tours\n\nVous pouvez saisir la liste des joueurs.", nbjr, nb, nbtr);
			MessageBox(_T(msg), _T("Cr�ation du tournoi"), MB_OK);

			SendMessage(WM_COMMAND, IDM_JOUEURS_LISTE, 0);
		}
		else
			MessageBox(_T("Erreur d'allocation !"), _T("Cr�ation du tournoi"), MB_OK);
	}
	else if (modedlg.choix == 3)		// tournoi �liminatoire
	{
		name= modedlg.field3.GetString();		// nom du tournoi

		nb = atoi(modedlg.field1.GetString());			// nb d'equipes saisi
		nbtr= atoi(modedlg.field2.GetString());			// nb de tours saisi

		if (nbtr > 9)
		{
			MessageBox(_T("Nombre de tours trop �lev� (maximum 9) !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}

		if (nb != power2(nbtr))
		{
			MessageBox(_T("Le nombre d'�quipes doit �tre une puissance de 2\n\n"\
				"(2 ^ nb de tours) !"), _T("Erreur !"), MB_OK | MB_ICONERROR);
			return;
		}
		
		tournoi = new Petanque(nbtr);
		if (tournoi != NULL)
		{
			wsprintf(msg, "Tournoi �liminatoire cr�� pour %u �quipes, sur %u tours\n\nVous pouvez saisir la liste des �quipes.", nb, nbtr);
			MessageBox(_T(msg), _T("Cr�ation du tournoi"), MB_OK);

			SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);
		}
		else
			MessageBox(_T("Erreur d'allocation !"), _T("Cr�ation du tournoi"), MB_OK);
	}

	CString wname= "P�tanque Amateur";
	wname += " - ";
	wname += name;
	SetWindowText(_T(wname.GetString()));

}

// sauvegarde des donn�es dans les fichiers csv
void CMainWindow::OnSave()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	if (tournoi->mode == 'F')
	{
		int res= tournoi->sauvegarde_forme(tour);
		if (res == 0)
			MessageBox(_T("Fichiers enregistr�s avec succ�s !"), _T("Sauvegarde"), MB_OK);
		else
			MessageBox(_T("Erreur d'enregistrement des fichiers !"), _T("Sauvegarde"), MB_OK | MB_ICONWARNING);
	}

	if (tournoi->mode == 'M')
	{
		int res = tournoi->sauvegarde_melee(tour);
		if (res == 0)
			MessageBox(_T("Fichiers enregistr�s avec succ�s !"), _T("Sauvegarde"), MB_OK);
		else
			MessageBox(_T("Erreur d'enregistrement des fichiers !"), _T("Sauvegarde"), MB_OK | MB_ICONWARNING);
	}

	if (tournoi->mode == 'E')
	{
		int res = tournoi->sauvegarde_elimin(tour);
		if (res == 0)
			MessageBox(_T("Fichiers enregistr�s avec succ�s !"), _T("Sauvegarde"), MB_OK);
		else
			MessageBox(_T("Erreur d'enregistrement des fichiers !"), _T("Sauvegarde"), MB_OK | MB_ICONWARNING);
	}
}

// restauration des donn�es depuis les fichiers csv
void CMainWindow::OnRestore()
{
	unsigned nb, nbtr, nbjr;
	char prefce;
	char msg[1000];

	if (tournoi == NULL) return;		// creer un tournoi d'abord

	if (start)
	{
		int tag= MessageBox(_T("Etes-vous s�r de vouloir �craser le tournoi en cours ?"), _T("Attention !"), MB_OKCANCEL | MB_ICONWARNING);
		if (tag != IDOK) return;
	}

	if (tournoi->mode == 'F')
	{
		int res = tournoi->restauration_test_forme();
		if (res != 0)
			MessageBox(_T("Restauration des fichiers impossible !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
		else
		{
			nb = tournoi->nbteams;
			nbtr = tournoi->nbtours;

			delete tournoi;		// tout d�truire
			
			tournoi = new Petanque(nbtr, nb);		// recreer un tournoi complet equipes form�es

			int tmp = tournoi->restauration_forme(tour);	// le nouveau tour sera fonction de ce qui a ete trouv�
			if (tmp >= 0)
			{
				tour = tmp;

				wsprintf(msg, "Fichiers restaur�s avec succ�s !\n\nTour %d", tour);
				MessageBox(_T(msg), _T("Restauration"), MB_OK);

				if (tour != 0) start = true;
				else start = false;
			}
			else
			{
				MessageBox(_T("Erreur de restauration des fichiers !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
			}
		}
	}

	if (tournoi->mode == 'M')
	{
		int res = tournoi->restauration_test_melee();
		if (res != 0)
			MessageBox(_T("Restauration des fichiers impossible !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
		else
		{
			nbjr = tournoi->nbplayers;
			nb = tournoi->nbteams;
			nbtr = tournoi->nbtours;
			prefce = tournoi->pref;

			delete tournoi;		// tout d�truire

			tournoi = new Petanque(nbtr, nb, nbjr, prefce);		// recreer un tournoi complet equipes mel�es

			int tmp = tournoi->restauration_melee(tour);	// le nouveau tour sera fonction de ce qui a ete trouv�
			if (tmp >= 0)
			{
				tour = tmp;

				wsprintf(msg, "Fichiers restaur�s avec succ�s !\n\nTour %d", tour);
				MessageBox(_T(msg), _T("Restauration"), MB_OK);

				if (tour != 0) start = true;
				else start = false;
			}
			else
			{
				MessageBox(_T("Erreur de restauration des fichiers !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
			}
		}
	}

	if (tournoi->mode == 'E')
	{
		int res = tournoi->restauration_test_elimin();
		if (res != 0)
			MessageBox(_T("Restauration des fichiers impossible !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
		else
		{
			nb = tournoi->nbteams;
			nbtr = tournoi->nbtours;

			delete tournoi;		// tout d�truire
			
			tournoi = new Petanque(nbtr);		// recreer un tournoi complet en mode eliminatoire

			int tmp = tournoi->restauration_elimin(tour);	// le nouveau tour sera fonction de ce qui a ete trouv�
			if (tmp >= 0)
			{
				tour = tmp;

				wsprintf(msg, "Fichiers restaur�s avec succ�s !\n\nTour %d", tour);
				MessageBox(_T(msg), _T("Restauration"), MB_OK);

				if (tour != 0) start = true;
				else start = false;
			}
			else
			{
				MessageBox(_T("Erreur de restauration des fichiers !"), _T("Restauration"), MB_OK | MB_ICONWARNING);
			}
		}
	}
}


/*
Menu Joueurs
*/

void CMainWindow::OnJoueurs_Liste()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	// Grille des joueurs
	CJoueursDlg * playerbox = new CJoueursDlg(IDD_JOUEURS_DLG, this);
	playerbox->DoModal();

	delete playerbox;
}

void CMainWindow::OnJoueurs_Ajout()
{
	char msg[1000];

	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	if (start)
	{
		MessageBox(_T("Le tournoi est commenc�\n\nVous ne pouvez plus ajouter de joueur !"), _T("Ajout de joueur"), MB_OK | MB_ICONWARNING);
		return;
	}

	wsprintf(msg, "Voulez-vous vraiment ajouter un joueur suppl�mentaire N� %u ?", tournoi->nbplayers + 1);
	int answer= MessageBox(_T(msg), _T("Ajout de joueur"), MB_YESNO);			
	if (answer == IDYES)
	{
		// recreer un tournoi modifie
		tournoi = ajout_joueur(tournoi);

		OnJoueurs_Unlock();

		// saisir nouveau joueur
		MessageBox(_T("Veuillez saisir le nouveau joueur dans la liste..."), _T("Ajout de joueur"), MB_OK);

		// appel de la liste via menu
		SendMessage(WM_COMMAND, IDM_JOUEURS_LISTE, 0);
	}
}

void CMainWindow::OnJoueurs_Retrait()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	if (start)
	{
		MessageBox(_T("Le tournoi est commenc�\n\nVous ne pouvez plus supprimer de joueur !"), _T("Retrait de joueur"), MB_OK | MB_ICONWARNING);
		return;
	}
	
	if (tournoi->nbplayers <= 8)
	{
		MessageBox(_T("Impossible de supprimer un joueur (nombre insuffisant) !"), _T("Retrait de joueur"), MB_OK | MB_ICONWARNING);
		return;
	}

	int answer = MessageBox(_T("Voulez-vous vraiment supprimer un joueur ?"), _T("Retrait de joueur"), MB_YESNO);
	if (answer == IDYES)
	{
		CDlg modedlg(INPUT_DLG);
		modedlg.contexte = 2;

		int res = modedlg.DoModal();
		if (res != IDOK) return;
		
		int n = atoi(modedlg.field1.GetString());	// n� du joueur � supprimer
		
		if ((n > 0) && (n <= tournoi->nbplayers))
		{
			// recreer un tournoi modifie
			tournoi = retrait_joueur(tournoi, n);
		}
		else
		{
			MessageBox(_T("Num�ro non valide !"), _T("Retrait de joueur"), MB_OK | MB_ICONWARNING);
		}

		// appel de la liste modifi�e via menu
		SendMessage(WM_COMMAND, IDM_JOUEURS_LISTE, 0);
	}
}

void CMainWindow::OnJoueurs_Lock()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	Joueurs_edit= FALSE;
}

void CMainWindow::OnJoueurs_Unlock()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	Joueurs_edit= TRUE;
}

/*
Menu Equipes
*/

void CMainWindow::OnEquipes_Liste()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	// Grille des equipes
	CEquipesDlg * teambox = new CEquipesDlg(IDD_EQUIPES_DLG, this);
	teambox->DoModal();

	delete teambox;
}

void CMainWindow::OnEquipes_Ajout()
{
	char msg[1000];

	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'F') return;

	if (start)
	{
		MessageBox(_T("Le tournoi est commenc�\n\nVous ne pouvez plus ajouter d'�quipe !"), _T("Ajout d'�quipe"), MB_OK | MB_ICONWARNING);
		return;
	}

	wsprintf(msg, "Voulez-vous vraiment ajouter une �quipe suppl�mentaire N� %u ?", tournoi->nbteams + 1);
	int answer = MessageBox(_T(msg), _T("Ajout d'�quipe"), MB_YESNO);
	if (answer == IDYES)
	{
		// recreer un tournoi modifie
		tournoi = ajout_equipe(tournoi);

		OnEquipes_Unlock();

		// saisir nouvelle �quipe
		MessageBox(_T("Veuillez saisir la nouvelle �quipe dans la liste..."), _T("Ajout d'�quipe"), MB_OK);

		// appel de la liste via menu
		SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);
	}
}

void CMainWindow::OnEquipes_Retrait()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'F') return;

	if (start)
	{
		MessageBox(_T("Le tournoi est commenc�\n\nVous ne pouvez plus supprimer d'�quipe !"), _T("Retrait d'�quipe"), MB_OK | MB_ICONWARNING);
		return;
	}

	if ((tournoi->nbteams <= 4) || (tournoi->nbtours >= tournoi->nbteams - 1))
	{
		MessageBox(_T("Impossible de supprimer une �quipe (nombre insuffisant) !"), _T("Retrait d'�quipe"), MB_OK | MB_ICONWARNING);
		return;
	}

	int answer = MessageBox(_T("Voulez-vous vraiment supprimer une �quipe ?"), _T("Retrait d'�quipe"), MB_YESNO);
	if (answer == IDYES)
	{
		CDlg modedlg(INPUT_DLG);
		modedlg.contexte = 3;

		int res = modedlg.DoModal();
		if (res != IDOK) return;

		int n = atoi(modedlg.field1.GetString());	// n� de l'�quipe � supprimer

		if ((n > 0) && (n <= tournoi->nbteams))
		{
			// recreer un tournoi modifie
			tournoi = retrait_equipe(tournoi, n);
		}
		else
		{
			MessageBox(_T("Num�ro non valide !"), _T("Retrait d'�quipe"), MB_OK | MB_ICONWARNING);
		}

		// appel de la liste via menu
		SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);
	}
}

void CMainWindow::OnEquipes_Lock()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	Equipes_edit= FALSE;
}

void CMainWindow::OnEquipes_Unlock()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	Equipes_edit= TRUE;	
}


// Melange des �quipes (en mode m�l�e uniquement)
void CMainWindow::OnEquipes_Melange()	
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tournoi->mode != 'M') return;

	int answer = MessageBox(_T("Voulez-vous vraiment (re)m�langer les �quipes ?\n\nLe m�lange est fait automatiquement � chaque tour..."), _T("M�lange des �quipes / joueurs"), MB_YESNO);
	if (answer == IDYES)
	{
		tournoi->melange();

		// appel de la liste via menu
		SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);
	}
}


/*
Menu Tours
*/

void CMainWindow::OnTours_Next()
{
	char msg[1000];
	int answer;

	if (tournoi == NULL) return;		// creer un tournoi d'abord

	if (tournoi->mode == 'F')
	{
		// tournoi form� termin�
		if ((tour > tournoi->nbtours) || ((tour == tournoi->nbtours) && (tournoi->nbteams % 2 == 0)))
		{
			wsprintf(msg, "Le tournoi en %d tours est termin� !", tour);
			MessageBox(_T(msg), _T("Attention"), MB_OK | MB_ICONWARNING);
			return;
		}

		// tour complementaire si nb impair d'�quipes ?
		if ((tour == tournoi->nbtours) && (tournoi->nbteams % 2))
		{
			int answer = MessageBox(_T("Voulez-vous organiser un tour compl�mentaire ?"), _T("Tour compl�mentaire"), MB_YESNO);
			if (answer != IDYES) return;

			tour++;

			// recherches des equipes passives ayant un match de retard
			unsigned * tab = new unsigned[tournoi->nbtours+1];
			int np = tournoi->get_compteams(tab);
			char passives[1000] = "Liste des �quipes passives ayant un match de retard :\n\nEquipes n� ", tmp[100]= "";

			for (int u= 0 ; u < np ; u++)		// conversion de la liste en chaine
				{ 
				wsprintf(tmp, "%u, ", tab[u]);
				strcat(passives, tmp);
				}

			strcat(passives, "\n\nVeuillez compl�ter ci-apr�s les derniers matches � jouer...");

			MessageBox(_T(passives), _T("Equipes passives"), MB_OK);

			int res = tournoi->tirage_comp();
			if (res == 0)
			{
				// sauvegarde automatique des fichiers
				OnSave();

				// appel de la liste des nouveaux matches (send est diff�r�)
				SendMessage(WM_COMMAND, IDM_TOURS_SCORES, 0);
			}
			else
			{
				// ne devrait pas arriver !!!
				MessageBox(_T("Probleme de tirage !"), _T("Nouveau tour"), MB_OK | MB_ICONWARNING);
			}
		}
		// tour normal
		else
		{
			answer = IDYES;
			if (tour > 0)
			{
				wsprintf(msg, "Le tour actuel [%d] doit de pr�f�rence �tre termin� avant de passer au tour suivant.\n\n"\
				"Etes vous s�r de vouloir continuer ? ", tour);
				answer = MessageBox(_T(msg), _T("Tirage des matches du tour"), MB_YESNO);
			}
			if (answer == IDYES)
			{
				start = true;	// tournoi demarre

				tour++;

				int res = tournoi->tirage(tour, false);
				if (res == 0)
				{
					// remettre les matches dans l'ordre 
					// important si equipe inactive a mettre en dernier
					// pas besoin de recopie en profondeur
					int nb = (tournoi->nbteams-1)/2;

					Partieptr * parties = new Partieptr[nb+1];

					for (int m = nb; m >= 0; m--)
						parties[m] = tournoi->matches[tour-1][m];
					for (int m= nb ; m >= 0 ; m--)
						tournoi->matches[tour-1][m]= parties[nb-m];

					delete[] parties;

					// sauvegarde automatique des fichiers
					OnSave();

					// appel de la liste des nouveaux matches (send est diff�r�)
					SendMessage(WM_COMMAND, IDM_TOURS_SCORES, 0);
				}
				else
				{
					// ne devrait pas arriver !!!
					MessageBox(_T("Probl�me de tirage !"), _T("Nouveau tour"), MB_OK | MB_ICONWARNING);
				}
			}
		}
	}

	if (tournoi->mode == 'M')
	{
		if (tour >= tournoi->nbtours)	// tournoi � la m�l�e termin�
		{
			wsprintf(msg, "Le tournoi en %d tours est termin� !", tour);
			MessageBox(_T(msg), _T("Attention"), MB_OK | MB_ICONWARNING);
			return;
		}

		answer = IDYES;
		if (tour > 0)
		{			
			wsprintf(msg, "Le tour actuel [%d] doit de pr�f�rence �tre termin� avant de passer au tour suivant.\n\n"\
				"Etes vous s�r de vouloir continuer ? ", tour);
			answer= MessageBox(_T(msg), _T("Tirage des matches du tour"), MB_YESNO);
		}
		if (answer == IDYES)
		{
			start = true;	// tournoi demarre

			// sauvegarde forc�e du tour actuel pour m�moriser les anciennes �quipes
			OnSave();

			tour++;

			wsprintf(msg, "Voulez-vous m�langer les �quipes pour ce nouveau tour [%d] ? ", tour);
			int rep= MessageBox(_T(msg), _T("M�lange des �quipes / joueurs"), MB_YESNO);
			if (rep == IDYES)
			{
				tournoi->melange();
			}
			
			int res = tournoi->tirage(tour, true);
			if (res == 0)
			{
				// appel de la liste des equipes via menu (send est diff�r�, post est imm�diat)
				SendMessage(WM_COMMAND, IDM_EQUIPES_LISTE, 0);

				// sauvegarde forc�e du nouveau tour (et des nouvelles �quipes si m�lange)
				OnSave();

				// appel de la liste des nouveaux matches (send est diff�r�)
				SendMessage(WM_COMMAND, IDM_TOURS_SCORES, 0);
			}
			else
			{
				// ne devrait pas arriver !!!
				MessageBox(_T("Probl�me de tirage !"), _T("Nouveau tour"), MB_OK | MB_ICONWARNING);
			}
		}

		return;
	}

	if (tournoi->mode == 'E')
	{
		if (tour >= tournoi->nbtours)	// tournoi eliminatoire termin�
		{
			wsprintf(msg, "Le tournoi en %d tours est termin� !", tour);
			MessageBox(_T(msg), _T("Attention"), MB_OK | MB_ICONWARNING);
			return;
		}

		answer = IDYES;
		if (tour > 0)
		{			
			wsprintf(msg, "Le tour actuel [%d] doit IMPERATIVEMENT �tre termin� avant de passer au tour suivant.\n\n"\
				"Etes vous s�r de vouloir continuer ? ", tour);
			answer= MessageBox(_T(msg), _T("Tirage des matches du tour"), MB_YESNO);
		}
		if (answer == IDYES)
		{
			int cpt= 0;

			for (int j= 1 ; j <= tournoi->nbteams ; j++)	
			{
				if (! tournoi->liste[j]->elimin) cpt++;		//compte les equipes encore en lice
			}

			if (cpt != power2(tournoi->nbtours - tour))
			{
				wsprintf(msg, "Le nombre d'�quipes encore en lice (%d) est incorrect !\n\n"\
				"V�rifiez les scores du tour actuel !", cpt);
				MessageBox(_T(msg), _T("Erreur"), MB_OK | MB_ICONEXCLAMATION);
				return;
			}

			if ((conso == 0) && (tour > 0) && (tour + 1 < tournoi->nbtours))
			{
				answer= MessageBox(_T("Voulez-vous cr�er un fichier des �quipes �limin�es lors du tour actuel\n\n"\
					"afin de pouvoir cr�er pour eux un tournoi consolante ?"), _T("Consolante"), MB_YESNO);

				if (answer == IDYES)
				{
					int res= create_conso(tournoi, tour);
					if (res == 0)					
					{
						conso= 1;

						MessageBox(_T("Fichier des �quipes en consolante cr��."), _T("Consolante"), MB_OK);
					}
					else
					{
						MessageBox(_T("Erreur lors de la cr�ation du fichier consolante."), _T("Erreur"), MB_OK | MB_ICONWARNING);
					}
				}
			}

			start = true;	// tournoi demarre

			tour++;
						
			if (tour < tournoi->nbtours)
			{
				answer= MessageBox(_T("Voulez-vous tirer les nouveaux matches au sort (Oui)\n\n"\
				"ou sinon, prendre les �quipes dans l'ordre du tableau (Non) ?"), _T("Tirage des matches du tour"), MB_YESNO);
			}
			else		// finale => pas le choix
			{
			answer= IDNO;
			}

			if (answer == IDYES)
			{
				int res = tournoi->tirage_elimin(tour);		// tirer les matches au hasard
				if (res != 0)
				{
					// ne devrait pas arriver !!!
					MessageBox(_T("Probl�me de tirage !"), _T("Nouveau tour"), MB_OK | MB_ICONWARNING);
					return;
				}
			}
			else		// prendre les �quipes dans l'ordre pour former les matches (arborescence)
			{
				if (tour == 1)		// matches = 1-2, 3-4, 5-6, etc
				{
					for (int k= 0 ; k < tournoi->nbteams/2 ; k++)
					{
					tournoi->matches[tour-1][k]= new Partie(tournoi, 2*k+1, 2*k+2);
					}
				}
				else			// recup�rer les equipes gagnantes du tour pr�c�dent, 2 par 2 dans le m�me ordre
				{
					int n1= -1, n2= 0, m= 0;

					for (int k= 0 ; k < tournoi->nbteams/2 ; k++)
					{
						if (tournoi->matches[tour-2][k] != NULL)
						{
							if (n1 == -1)
							{
								if (tournoi->matches[tour-2][k]->score1 > tournoi->matches[tour-2][k]->score2)
									n1= tournoi->matches[tour-2][k]->num1;
								else
									n1= tournoi->matches[tour-2][k]->num2;
							}
							else
							{
								if (tournoi->matches[tour-2][k]->score1 > tournoi->matches[tour-2][k]->score2)
									n2= tournoi->matches[tour-2][k]->num1;
								else
									n2= tournoi->matches[tour-2][k]->num2;

								tournoi->matches[tour-1][m]= new Partie(tournoi, n1, n2);
								m++;

								n1= -1;								
							}					
						}
					}
				}

				tournoi->done[tour-1]= true;
			}

			if (tour == tournoi->nbtours)
			{
				answer= MessageBox(_T("Voulez-vous organiser une petite finale pour la 3e place ?"),
					_T("Tirage des matches du tour"), MB_YESNO);

				if (answer == IDYES)		// recherche des perdants du tour pr�c�dent
				{
					int p1= 0, p2= 0;

					if (tournoi->matches[tour-2][0] != NULL)
					{
						if (tournoi->matches[tour-2][0]->score1 > tournoi->matches[tour-2][0]->score2)
							p1= tournoi->matches[tour-2][0]->num2;
						else
							p1= tournoi->matches[tour-2][0]->num1;
				
						if (tournoi->matches[tour-2][1]->score1 > tournoi->matches[tour-2][1]->score2)
							p2= tournoi->matches[tour-2][1]->num2;
						else
							p2= tournoi->matches[tour-2][1]->num1;
				
						tournoi->matches[tour-1][1]= new Partie(tournoi, p1, p2);
					}
				}
			}

			// sauvegarde forc�e du nouveau tour
			OnSave();

			// appel de la liste des nouveaux matches (send est diff�r�)
			SendMessage(WM_COMMAND, IDM_TOURS_SCORES, 0);
		}

		return;
	}

}


void CMainWindow::OnTours_Scores()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tour == 0) return;			// pas de scores � ce stade

	// Grille des scores
	CScoresDlg * scorebox = new CScoresDlg(IDD_SCORES_DLG, this, tour);
	scorebox->DoModal();

	// sauvegarde automatique des fichiers
	OnSave();

	delete scorebox;
}

void CMainWindow::OnTours_ScoresOld()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord
	if (tour <= 1) return;			// pas de scores anterieurs � ce stade

	// choix du tour � visualiser
	CDlg modedlg(INPUT_DLG);
	modedlg.contexte = 1;

	int res = modedlg.DoModal();
	if (res != IDOK) return;

	int oldtr = atoi(modedlg.field1.GetString());		// tour choisi
	if ((oldtr <= 0) || (oldtr >= tour))
		return;

	if (tournoi->mode == 'M')
	{
		Equipeptr * oldteams= new Equipeptr[tournoi->nbteams+1];
		Equipeptr * actualteams= new Equipeptr[tournoi->nbteams+1];

		// recuperation des anciennes equipes du tour dans le fichier
		int res= tournoi->get_equipes_melee(oldtr, oldteams);

		if (res != 0)
		{
			MessageBox(_T("Erreur de r�cup�ration des informations !"), _T("Attention"), MB_OK | MB_ICONWARNING);
			return;
		}

		// remplacement temporaire des equipes actuelles par les anciennes
		for (int i= 0 ; i < tournoi->nbteams+1 ; i++)
			{
			actualteams[i]= tournoi->liste[i];
			tournoi->liste[i]= oldteams[i];
			}

		// Grille des scores
		CScoresDlg * scorebox = new CScoresDlg(IDD_SCORES_DLG, this, oldtr);
		scorebox->DoModal();

		delete scorebox;

		// retour aux equipes actuelles
		for (int i= 0 ; i < tournoi->nbteams+1 ; i++)
			{
			tournoi->liste[i]= actualteams[i];
			}

		delete[] oldteams;
		delete[] actualteams;
	}

	if (tournoi->mode == 'F')
	{
		// Grille des scores
		CScoresDlg * scorebox = new CScoresDlg(IDD_SCORES_DLG, this, oldtr);
		scorebox->DoModal();

		delete scorebox;
	}

	if (tournoi->mode == 'E')
	{
		// Grille des scores
		CScoresDlg * scorebox = new CScoresDlg(IDD_SCORES_DLG, this, oldtr);
		scorebox->DoModal();

		delete scorebox;
	}

}


void CMainWindow::OnResults_Bilan()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	// Grille du bilan
	CBilanDlg * bilanbox = new CBilanDlg(IDD_BILAN_DLG, this);
	bilanbox->DoModal();

	delete bilanbox;
}


void CMainWindow::OnResults_Classement()
{
	if (tournoi == NULL) return;		// creer un tournoi d'abord

	// Grille du classement
	CClassementDlg * sortbox = new CClassementDlg(IDD_BILAN_DLG, this);
	sortbox->DoModal();

	delete sortbox;
}


void CMainWindow::OnAbout()
{
	MessageBox(_T("Gestion de tournois de P�tanque Amateurs, version 1.0\n\n@(#) J. GILLES 2026"), _T("A propos"), MB_OK);
}


void CMainWindow::OnDoc()
{
	CString docfile = _T(".\\Petanque-Amateur.pdf");

	// Utilisation de ShellExecute pour ouvrir le document avec l'application par defaut
	HINSTANCE hInst = ::ShellExecute(NULL, _T("open"), docfile, NULL, NULL, SW_SHOWNORMAL);

	// V�rification du succ�s de l'op�ration
	if ((int) hInst <= 32) 
		MessageBox(_T("Impossible d'ouvrir le fichier documentation"), "Attention", MB_OK |MB_ICONEXCLAMATION);
}

// OnPaint() is called on WM-PAINT message
void CMainWindow::OnPaint()
	{
	CRect rect;
	GetClientRect(rect);

	CPaintDC dc(this);
	dc.SetTextAlign(TA_BASELINE | TA_CENTER);
	dc.SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));
	dc.SetBkMode(TRANSPARENT);

	dc.MoveTo(rect.left, 25);  
	dc.LineTo(rect.right, 25); 

	CString s= "Gestionnaire de tournois de p�tanque en doublettes / triplettes";
		dc.TextOut((rect.right / 2), (rect.bottom / 8), s);

		CString tab[50] = {
			"                                                                  .  .dxO00Oxx,...                  ",
			"                                                              ..xMMMMMMMMWWWMMMMMMM0'...            ",
			"                                                          ..'NMMMMKc::d0KMMKc.....dNMMMc..          ",
			"                                                         .oMMMMc .       ...'kMMo.....kMMK..        ",
			"                                                        :MMMK.....     ...'oooo:kMN.  ...NMO.       ",
			"                                                      .XMMK.......lXMMMMMxdl::codkMMMXl...'MM..     ",
			"                                                     .MMMc..    cMMW'..0Mk.     .. .kMXWMO..OM:     ",
			"                                                   ..MMM'   ..OMK....    'MX. .     .:MM.'XW,dM'.   ",
			"                                                   .xMM,. ..dMx.           :Md.       'MK. .kMKN.   ",
			"                        ..  ...                    .MMX  ..NM.             . MX..     .lMc.  .NMo   ",
			"                ....',XNWWMMWWNX:,.....           .cMM:  .Md.                .M0.       MX.  ..00.  ",
			"             ..,KMMNMWc.   ..0X..'lXMK:...         xMM'..Xd..                .:M'..'''..oM..   ,W . ",
			"         ...xMMK,'MW..     .0W.      .'0Mk..       dMM'.oK.              ...xMMMMXollllxWMMWd..,N . ",
			"       ..:MMW'..WM.       .,Mc.          .XM:.     'MM:.W:             .lMMN,. K0       lM:..oMMd   ",
			"      .:MMX...oMx....:XWMMMMMMMMMMMWN:..  ..OM:.   .KMX.N..          .OMk..    Xx.      dM'  ..M.   ",
			"      WMM'.  OMc.kMMMXo,...Mk.. ....'lXMMO'...WW.. .,MMcN.          xMd..    .'M'     ..M0.. .Kx.   ",
			"    ,MMX.  .OMMMM0'..     lMl         ....OMX..kM,...lMMN..       .NW...     .0O.     .OM'...xX..   ",
			"  .:WMX..  cMMK. .        lMo             ...KM,dMl  .:MMl.       XN..       k0..     lM,. .0O.     ",
			"  'MMX....NMM.            .M0  . ..         . .dWKM,....NMW. .  .lM.      . No.     .dM'..:M:..     ",
			" .MMM  .lMMMK         .....WMxkkkx,'....       ..XMW.    :MMN.  .c,.     .xX.     ..XO..:Wk.        ",
			".cMMO..OMldMo     ....oWMMWOMO... :d0MMWl...      oMx    .. ..  ..........      ..kW''KMd.          ",
			".NMM:.kM: kMl    ..kMMo.   .0Ml        ..kMo..     ....:XWMM0kxdddxk0MMMMWk,....lMOWMl..            ",
			".MMM,:Ml..oMO  ..KMo .     ..KMl.         ..KK.....xMWo...      ...'::dxxkXMMMNc..                  ",
			".MMM'NM   cMW..xMl..         .kMK..           ..XMO.      ...'KMMMWo,.........oMMMl.                ",
			".MMMoM'    NMcWK..           ..,MM:..        ,WM0.     ...0MMK:...             ..OMMO.              ",
			".XMMMM.    ,MMO..              ..:MMo .   .'MK..Md.  ..OMMd..                     .oMMO.            ",
			"..MMMM.    .KMX.                 ...KMM...0M'.  :Mx..WMM'..                         .KMMc.          ",
			"..kMMM.    .MoMW                     ....MN.   ..'MMMW'..            .lKMMNxl:''',cl0K0MMO..        ",
			"  .KMMM..  oK.'MM:..                  .,MMx.   ..cMMMo..        ..,NM0,.  ..      .  .. MM0 .       ",
			"  ..XMMM' .kd  .kMN...               ..MNMo.  ..xMN.,MMc...   ..KMK.. .               ..WMM0.       ",
			"    .kMMMx.ld     OMM'..             .NM Mx.  .XMK.  .:MMK'...XMx.                ...'WM.:MMo       ",
			"     .'MMMMoK..   ..cWMK,...         oM0 W0.  xMN.      .OMMXMK...             ...'0MK.   XMM..     ",
			"       .cMMMMO..      ..xWMNo .   .  MM. NW. .MM..       . OMMMMMOo. ... .. .,dXMMK'      :MMd.     ",
			"         .,WMMMMK,..      ...'d0KK..,MM. .Mk.0MX..       .xMl....o0MMMMMMMMMM0o...        .MM0.     ",
			"            .:NMMMMMWXo''......'lK..:MM. .OMlWM.         ,Mx.                             .MMM.     ",
			"               ...XMMMMMMMMMMMMMMM..:MM.  .MMMM.         KM.                              .MMM.     ",
			"                    ........... .  .,MMc  ..WMM         'Mk.                              .MM0      ",
			"                                     MMW    :MMN..      :Md                             .:MMMd.     ",
			"                     .',:''.         oMMo.  .NMMMc.     'Md                            .NdMMM..     ",
			"                ..kMMMMWWKWWMW:..    .NMM'...dMdKMM:... .Mk..                       ..KX XMMl       ",
			"               .NMMMMc .... .,MMc .  .'MMM'.. WM..0MMN...kM..                    . cWK..0MW0.       ",
			"             ..MMMMM..       ..WMN.    'MMMl...M0.  :WMMN:WO..              ....dMMl...WMM0.        ",
			"             .WMMMM0         ..kMMl     .MMMX..,Mk.    'OMMMMKd,'.  .....':kNMMX,.  .'MMMk..        ",
			"             'MMMMMM..       ..NMM0..    .0MMM0.'MK..      .WNNWMMMMMMMMMWd:...   ..WMMM,.          ",
			"             .MMMMMMM'..    .'MMMMO       ..MMMMX.OM,        ON.               ..'WMMMO.            ",
			"             .XMMMMMMMMNOdONMMMMMM.          'WMMMMOMW..     ..0O.           ..OMMMMk.              ",
			"              .NMMMMMMMMMMMMMMMMM..           ..OMMMMMMM,..   ...xM'.  ...'xWMMMMW:.                ",
			"               .,MMMMMMMMMMMMMMO.               ...lMMMMMMMMMMK00O0OMMMMMMMMMMWc..                  ",
			"                  .KMMMMMMMMM.                      ....'XMMMMMMMMMMMMMMMMo..                       ",
			"                      ....                                 ............                             " };

		dc.SetTextAlign(TA_BASELINE | TA_CENTER);
		
		CFont newFont;
		newFont.CreatePointFont(40, _T("Courier New")); 
		dc.SelectObject(&newFont);
		
		int ScreenX= ::GetSystemMetrics(SM_CXSCREEN);
		int ScreenY= ::GetSystemMetrics(SM_CYSCREEN);

		float ratio= 5 * ((float) ScreenX / (float) ScreenY);
		int r= (int) ratio;

		for (int i= 0 ; i < 50 ; i++ )
			dc.TextOut((rect.right / 2), (rect.bottom / 4 + r*i), tab[i]);
	}


// fermeture via [x]
void CMainWindow::OnClose()
{
	OnQuit();
}


// fermeture via menu
void CMainWindow::OnQuit()
{
	if (tournoi != NULL)
	{
		int answer = MessageBox(_T("Un tournoi est en cours !\n\nEtes-vous s�r de vouloir terminer ?"), _T("Quitter"), MB_OKCANCEL | MB_ICONWARNING);
		if (answer == IDOK)
		{
			int sav = MessageBox(_T("Voulez-vous enregistrer les donn�es avant de quitter ?"), _T("Quitter"), MB_YESNO);
			if (sav == IDYES)
			{
				OnSave();
			}

			// destruction de la fenetre principale => fin de l'application via exitInstance()
			DestroyWindow();
		}		
	}
	else
	{
		DestroyWindow();
	}
}


// CMainWindow message map:
// Associate messages with member functions.
BEGIN_MESSAGE_MAP(CMainWindow, CFrameWnd )
	ON_WM_PAINT()
	ON_WM_CLOSE()

	ON_COMMAND(IDM_JEU_NOUVEAU, OnNew)
	ON_COMMAND(IDM_JEU_SAUVER, OnSave)
	ON_COMMAND(IDM_JEU_RESTAURER, OnRestore)

	ON_COMMAND(IDM_JEU_NOUVEAU, OnNew)
	ON_COMMAND(IDM_JEU_SAUVER, OnSave)

	ON_COMMAND(IDM_JOUEURS_LISTE, OnJoueurs_Liste)
	ON_COMMAND(IDM_JOUEURS_AJOUT, OnJoueurs_Ajout)
	ON_COMMAND(IDM_JOUEURS_RETRAIT, OnJoueurs_Retrait)
	ON_COMMAND(IDM_JOUEURS_LOCK, OnJoueurs_Lock)
	ON_COMMAND(IDM_JOUEURS_UNLOCK, OnJoueurs_Unlock)

	ON_COMMAND(IDM_EQUIPES_LISTE, OnEquipes_Liste)
	ON_COMMAND(IDM_EQUIPES_AJOUT, OnEquipes_Ajout)
	ON_COMMAND(IDM_EQUIPES_RETRAIT, OnEquipes_Retrait)
	ON_COMMAND(IDM_EQUIPES_LOCK, OnEquipes_Lock)
	ON_COMMAND(IDM_EQUIPES_UNLOCK, OnEquipes_Unlock)

	ON_COMMAND(IDM_EQUIPES_MIX, OnEquipes_Melange)

	ON_COMMAND(IDM_TOURS_NEXT, OnTours_Next)
	ON_COMMAND(IDM_TOURS_SCORES, OnTours_Scores)
	ON_COMMAND(IDM_TOURS_OLD, OnTours_ScoresOld)

	ON_COMMAND(IDM_RESULTS_BILAN, OnResults_Bilan)
	ON_COMMAND(IDM_RESULTS_CLASSEMENT, OnResults_Classement)

	ON_COMMAND(IDM_AIDE_ABOUT, OnAbout)
	ON_COMMAND(IDM_AIDE_DOC, OnDoc)
	ON_COMMAND(IDM_JEU_QUIT, OnQuit)	
END_MESSAGE_MAP()

// InitInstance is called when CTheApp object is created
BOOL CTheApp::InitInstance()
	{
	Enable3dControls(); // use 3d controls in dialogs

	m_pMainWnd = new CMainWindow;
	m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();

	return TRUE;
	}

int CTheApp::ExitInstance()		// surcharge
	{
	delete m_pMainWnd;	// destruction de la fen�tre

	return 0;	// code de retour du programme
	}
